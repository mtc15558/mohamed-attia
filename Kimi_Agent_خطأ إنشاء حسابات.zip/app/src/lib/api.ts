import {
  mockUsers,
  mockCrops,
  mockProjects,
  mockStatistics,
  mockArticles,
  mockFeedback,
  mockNotifications,
  mockInitiatives,
  mockRegions,
} from './mockData';
import type { User, Crop, Project, Notification, Initiative } from '@/types';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// In-memory storage for modifications
let users: any[] = [...mockUsers];
let crops: any[] = [...mockCrops];
let projects: any[] = [...mockProjects];
let statistics: any[] = [...mockStatistics];
let articles: any[] = [...mockArticles];
let feedback: any[] = [...mockFeedback];
let notifications: any[] = [...mockNotifications];
let initiatives: any[] = [...mockInitiatives];
let regions: any[] = [...mockRegions];

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

export const api = {
  async get<T>(endpoint: string): Promise<T> {
    await delay(300);
    
    const path = endpoint.split('?')[0];
    const query = endpoint.includes('?') ? endpoint.split('?')[1] : '';
    
    switch (path) {
      case '/users':
        return users as T;
      case '/crops':
        return crops as T;
      case '/projects':
        return projects as T;
      case '/statistics':
        return statistics as T;
      case '/articles':
        return articles as T;
      case '/feedback':
        return feedback as T;
      case '/notifications':
        if (query && query.includes('userId=')) {
          const userId = parseInt(query.split('userId=')[1]);
          return notifications.filter(n => n.userId === userId) as T;
        }
        return notifications as T;
      case '/initiatives':
        return initiatives as T;
      case '/regions':
        return regions as T;
      default:
        if (path.startsWith('/users/')) {
          const id = parseInt(path.split('/')[2]);
          const user = users.find(u => u.id === id);
          if (!user) throw new ApiError(404, 'User not found');
          return user as T;
        }
        throw new ApiError(404, 'Not found');
    }
  },

  async post<T>(endpoint: string, data: unknown): Promise<T> {
    await delay(300);
    
    const newId = Math.floor(Math.random() * 10000) + 100;
    const newItem = { ...(data as object), id: newId };
    
    switch (endpoint) {
      case '/users':
        users.push(newItem);
        return newItem as T;
      case '/crops':
        crops.push(newItem);
        return newItem as T;
      case '/projects':
        projects.push(newItem);
        return newItem as T;
      case '/feedback':
        feedback.unshift(newItem);
        return newItem as T;
      case '/notifications':
        notifications.unshift(newItem);
        return newItem as T;
      case '/initiatives':
        initiatives.push(newItem);
        return newItem as T;
      default:
        throw new ApiError(404, 'Not found');
    }
  },

  async put<T>(endpoint: string, data: unknown): Promise<T> {
    await delay(300);
    
    const path = endpoint.split('/');
    const id = parseInt(path[2]);
    
    switch (`/${path[1]}`) {
      case '/users':
        const userIndex = users.findIndex((u: any) => u.id === id);
        if (userIndex === -1) throw new ApiError(404, 'User not found');
        users[userIndex] = { ...users[userIndex], ...(data as object) };
        return users[userIndex] as T;
      case '/crops':
        const cropIndex = crops.findIndex((c: any) => c.id === id);
        if (cropIndex === -1) throw new ApiError(404, 'Crop not found');
        crops[cropIndex] = { ...crops[cropIndex], ...(data as object) };
        return crops[cropIndex] as T;
      case '/projects':
        const projectIndex = projects.findIndex((p: any) => p.id === id);
        if (projectIndex === -1) throw new ApiError(404, 'Project not found');
        projects[projectIndex] = { ...projects[projectIndex], ...(data as object) };
        return projects[projectIndex] as T;
      case '/feedback':
        const feedbackIndex = feedback.findIndex((f: any) => f.id === id);
        if (feedbackIndex === -1) throw new ApiError(404, 'Feedback not found');
        feedback[feedbackIndex] = { ...feedback[feedbackIndex], ...(data as object) };
        return feedback[feedbackIndex] as T;
      case '/initiatives':
        const initiativeIndex = initiatives.findIndex((i: any) => i.id === id);
        if (initiativeIndex === -1) throw new ApiError(404, 'Initiative not found');
        initiatives[initiativeIndex] = { ...initiatives[initiativeIndex], ...(data as object) };
        return initiatives[initiativeIndex] as T;
      default:
        throw new ApiError(404, 'Not found');
    }
  },

  async patch<T>(endpoint: string, data: unknown): Promise<T> {
    await delay(300);
    
    const path = endpoint.split('/');
    const id = parseInt(path[2]);
    
    switch (`/${path[1]}`) {
      case '/notifications':
        const notifIndex = notifications.findIndex((n: any) => n.id === id);
        if (notifIndex === -1) throw new ApiError(404, 'Notification not found');
        notifications[notifIndex] = { ...notifications[notifIndex], ...(data as object) };
        return notifications[notifIndex] as T;
      default:
        throw new ApiError(404, 'Not found');
    }
  },

  async delete<T>(endpoint: string): Promise<T> {
    await delay(300);
    
    const path = endpoint.split('/');
    const id = parseInt(path[2]);
    
    switch (`/${path[1]}`) {
      case '/users':
        users = users.filter((u: any) => u.id !== id);
        return undefined as T;
      case '/crops':
        crops = crops.filter((c: any) => c.id !== id);
        return undefined as T;
      case '/projects':
        projects = projects.filter((p: any) => p.id !== id);
        return undefined as T;
      case '/notifications':
        notifications = notifications.filter((n: any) => n.id !== id);
        return undefined as T;
      case '/initiatives':
        initiatives = initiatives.filter((i: any) => i.id !== id);
        return undefined as T;
      default:
        throw new ApiError(404, 'Not found');
    }
  },
};

// Helper functions for specific endpoints
export const usersApi = {
  getAll: () => api.get<User[]>('/users'),
  getById: (id: number) => api.get<User>(`/users/${id}`),
  create: (user: Partial<User>) => api.post<User>('/users', user),
  update: (id: number, user: Partial<User>) => api.put<User>(`/users/${id}`, user),
  delete: (id: number) => api.delete<void>(`/users/${id}`),
};

export const cropsApi = {
  getAll: () => api.get<Crop[]>('/crops'),
  getById: (id: number) => api.get<Crop>(`/crops/${id}`),
  create: (crop: Partial<Crop>) => api.post<Crop>('/crops', crop),
  update: (id: number, crop: Partial<Crop>) => api.put<Crop>(`/crops/${id}`, crop),
  delete: (id: number) => api.delete<void>(`/crops/${id}`),
};

export const projectsApi = {
  getAll: () => api.get<Project[]>('/projects'),
  getById: (id: number) => api.get<Project>(`/projects/${id}`),
  create: (project: Partial<Project>) => api.post<Project>('/projects', project),
  update: (id: number, project: Partial<Project>) => api.put<Project>(`/projects/${id}`, project),
  delete: (id: number) => api.delete<void>(`/projects/${id}`),
};

export const notificationsApi = {
  getAll: () => api.get<Notification[]>('/notifications'),
  getByUserId: (userId: number) => api.get<Notification[]>(`/notifications?userId=${userId}`),
  create: (notification: Partial<Notification>) => api.post<Notification>('/notifications', notification),
  markAsRead: (id: number) => api.patch<Notification>(`/notifications/${id}`, { read: true }),
  delete: (id: number) => api.delete<void>(`/notifications/${id}`),
};

export const initiativesApi = {
  getAll: () => api.get<Initiative[]>('/initiatives'),
  create: (initiative: Partial<Initiative>) => api.post<Initiative>('/initiatives', initiative),
  update: (id: number, initiative: Partial<Initiative>) => api.put<Initiative>(`/initiatives/${id}`, initiative),
  delete: (id: number) => api.delete<void>(`/initiatives/${id}`),
};
