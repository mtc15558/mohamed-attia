// Mock data for the application - used when JSON Server is not available

export const mockUsers = [
  {
    id: 1,
    name: "أحمد محمد",
    email: "admin@agri.eg",
    password: "admin123",
    role: "admin" as const,
    phone: "01001234567",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400",
    createdAt: "2024-01-01",
    isActive: true
  },
  {
    id: 2,
    name: "محمد عبدالله",
    email: "farmer@agri.eg",
    password: "farmer123",
    role: "farmer" as const,
    phone: "01012345678",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
    createdAt: "2024-01-15",
    isActive: true,
    location: "المنيا",
    farmSize: 50
  },
  {
    id: 3,
    name: "خالد محمود",
    email: "investor@agri.eg",
    password: "investor123",
    role: "investor" as const,
    phone: "01023456789",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
    createdAt: "2024-02-01",
    isActive: true,
    company: "شركة الاستثمار الزراعي"
  },
  {
    id: 4,
    name: "سارة أحمد",
    email: "student@agri.eg",
    password: "student123",
    role: "student" as const,
    phone: "01034567890",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400",
    createdAt: "2024-02-15",
    isActive: true,
    university: "جامعة القاهرة"
  }
];

export const mockCrops = [
  {
    id: 1,
    name: "القمح",
    scientificName: "Triticum aestivum",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600",
    soilType: "طيني رملي",
    waterNeeds: "متوسطة",
    season: "الشتاء",
    avgYield: 7.5,
    yieldUnit: "طن/فدان",
    commonProblems: ["الصدأ", "السوسة", "العفن"],
    description: "أهم محصول غذائي في مصر، يزرع في موسم الشتاء",
    region: "الدلتا",
    price: 12000,
    currency: "جنيه/طن"
  },
  {
    id: 2,
    name: "الأرز",
    scientificName: "Oryza sativa",
    image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600",
    soilType: "طيني",
    waterNeeds: "عالية",
    season: "الصيف",
    avgYield: 9.2,
    yieldUnit: "طن/فدان",
    commonProblems: ["الحفار", "الذبابة البيضاء", "اللفحة"],
    description: "المحصول الرئيسي في الدلتا، يحتاج لمياه غزيرة",
    region: "الدلتا",
    price: 15000,
    currency: "جنيه/طن"
  },
  {
    id: 3,
    name: "الذرة",
    scientificName: "Zea mays",
    image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=600",
    soilType: "رملي طيني",
    waterNeeds: "متوسطة",
    season: "الصيف",
    avgYield: 8.0,
    yieldUnit: "طن/فدان",
    commonProblems: ["الدودة القارضة", "المن", "العفن"],
    description: "محصول صيفي مهم للأعلاف والغذاء",
    region: "الوجه البحري",
    price: 8000,
    currency: "جنيه/طن"
  },
  {
    id: 4,
    name: "القطن",
    scientificName: "Gossypium barbadense",
    image: "https://images.unsplash.com/photo-1595152772835-219674b2a8a6?w=600",
    soilType: "طيني",
    waterNeeds: "متوسطة",
    season: "الصيف",
    avgYield: 2.5,
    yieldUnit: "قنطار/فدان",
    commonProblems: ["دودة القطن", "المن", "البياض الدقيقي"],
    description: "الذهب الأبيض، من أهم المحاصيل التصديرية",
    region: "الدلتا",
    price: 3500,
    currency: "جنيه/قنطار"
  },
  {
    id: 5,
    name: "قصب السكر",
    scientificName: "Saccharum officinarum",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600",
    soilType: "طيني غني",
    waterNeeds: "عالية",
    season: "الصيف",
    avgYield: 45,
    yieldUnit: "طن/فدان",
    commonProblems: ["السوسة القصبية", "الصدأ", "اللفحة"],
    description: "محصول استوائي مهم لإنتاج السكر",
    region: "صعيد مصر",
    price: 900,
    currency: "جنيه/طن"
  },
  {
    id: 6,
    name: "البطاطس",
    scientificName: "Solanum tuberosum",
    image: "https://images.unsplash.com/photo-1518977676601-b53f82a6b696?w=600",
    soilType: "رملي خفيف",
    waterNeeds: "متوسطة",
    season: "الشتاء",
    avgYield: 20,
    yieldUnit: "طن/فدان",
    commonProblems: ["اللفحة المتأخرة", "النيماتودا", "العفن"],
    description: "محصول شتوي مهم، يحتاج لتربة خفيفة",
    region: "المنيا",
    price: 6000,
    currency: "جنيه/طن"
  },
  {
    id: 7,
    name: "الطماطم",
    scientificName: "Solanum lycopersicum",
    image: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600",
    soilType: "طيني رملي",
    waterNeeds: "متوسطة",
    season: "طوال العام",
    avgYield: 25,
    yieldUnit: "طن/فدان",
    commonProblems: ["البياض الدقيقي", "العفن", "المن"],
    description: "محصول استراتيجي للتصدير",
    region: "الإسماعيلية",
    price: 4000,
    currency: "جنيه/طن"
  },
  {
    id: 8,
    name: "الفول السوداني",
    scientificName: "Arachis hypogaea",
    image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=600",
    soilType: "رملي",
    waterNeeds: "منخفضة",
    season: "الصيف",
    avgYield: 1.8,
    yieldUnit: "طن/فدان",
    commonProblems: ["اللفحة", "الصدأ", "السوسة"],
    description: "محصول زيتي مهم، يتحمل الجفاف",
    region: "المنيا",
    price: 25000,
    currency: "جنيه/طن"
  }
];

export const mockProjects = [
  {
    id: 1,
    title: "مشروع استصلاح 1000 فدان",
    location: "توشكى",
    governorate: "أسوان",
    cropType: "القمح",
    investmentCost: 5000000,
    expectedReturn: 7500000,
    duration: "3 سنوات",
    status: "active" as const,
    description: "مشروع استصلاح أراضي صحراوية لزراعة القمح",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600",
    ownerId: 3,
    rating: 4.5,
    reviews: 12,
    coordinates: [23.5, 30.8] as [number, number]
  },
  {
    id: 2,
    title: "مزرعة نخيل للتمور",
    location: "الوادي الجديد",
    governorate: "الوادي الجديد",
    cropType: "نخيل",
    investmentCost: 3000000,
    expectedReturn: 6000000,
    duration: "5 سنوات",
    status: "active" as const,
    description: "مزرعة نخيل لإنتاج التمور الممتازة للتصدير",
    image: "https://images.unsplash.com/photo-1599639668312-394777276d50?w=600",
    ownerId: 3,
    rating: 4.8,
    reviews: 8,
    coordinates: [25.5, 28.9] as [number, number]
  },
  {
    id: 3,
    title: "مشروع زراعة الزيتون",
    location: "سيوة",
    governorate: "مطروح",
    cropType: "زيتون",
    investmentCost: 2000000,
    expectedReturn: 4000000,
    duration: "4 سنوات",
    status: "pending" as const,
    description: "مشروع زراعة الزيتون لإنتاج زيت الزيتون البكر",
    image: "https://images.unsplash.com/photo-1518843875459-f738682238a6?w=600",
    ownerId: 2,
    rating: 0,
    reviews: 0,
    coordinates: [29.2, 25.5] as [number, number]
  },
  {
    id: 4,
    title: "مزرعة خضروات عضوية",
    location: "الفيوم",
    governorate: "الفيوم",
    cropType: "خضروات",
    investmentCost: 1500000,
    expectedReturn: 2500000,
    duration: "2 سنوات",
    status: "active" as const,
    description: "مزرعة خضروات عضوية للتصدير",
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=600",
    ownerId: 3,
    rating: 4.2,
    reviews: 15,
    coordinates: [30.8, 29.3] as [number, number]
  },
  {
    id: 5,
    title: "مشروع تربية الأبقار",
    location: "البحيرة",
    governorate: "البحيرة",
    cropType: "ألبان",
    investmentCost: 4000000,
    expectedReturn: 5500000,
    duration: "3 سنوات",
    status: "active" as const,
    description: "مشروع تربية أبقار لإنتاج الألبان والأجبان",
    image: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=600",
    ownerId: 3,
    rating: 4.6,
    reviews: 10,
    coordinates: [30.4, 30.9] as [number, number]
  }
];

export const mockStatistics = [
  { id: 1, year: 2020, cropId: 1, production: 9.0, unit: "مليون طن", export: 0.5, selfSufficiency: 62 },
  { id: 2, year: 2021, cropId: 1, production: 9.5, unit: "مليون طن", export: 0.8, selfSufficiency: 65 },
  { id: 3, year: 2022, cropId: 1, production: 10.2, unit: "مليون طن", export: 1.2, selfSufficiency: 70 },
  { id: 4, year: 2023, cropId: 1, production: 11.0, unit: "مليون طن", export: 1.5, selfSufficiency: 75 },
  { id: 5, year: 2024, cropId: 1, production: 12.5, unit: "مليون طن", export: 2.0, selfSufficiency: 82 },
  { id: 6, year: 2020, cropId: 2, production: 4.5, unit: "مليون طن", export: 0.2, selfSufficiency: 95 },
  { id: 7, year: 2021, cropId: 2, production: 4.8, unit: "مليون طن", export: 0.3, selfSufficiency: 98 },
  { id: 8, year: 2022, cropId: 2, production: 5.0, unit: "مليون طن", export: 0.5, selfSufficiency: 100 },
  { id: 9, year: 2023, cropId: 2, production: 5.2, unit: "مليون طن", export: 0.8, selfSufficiency: 102 },
  { id: 10, year: 2024, cropId: 2, production: 5.5, unit: "مليون طن", export: 1.0, selfSufficiency: 105 }
];

export const mockArticles = [
  {
    id: 1,
    title: "أفضل طرق زراعة القمح في مصر",
    content: "تعتبر زراعة القمح من أهم المحاصيل الاستراتيجية في مصر...",
    category: "محاصيل",
    author: "د. أحمد محمود",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600",
    createdAt: "2024-01-15",
    views: 1250,
    type: "article" as const
  },
  {
    id: 2,
    title: "دليل الري الحديث وتوفير المياه",
    content: "يواجه القطاع الزراعي تحديات كبيرة في توفير المياه...",
    category: "ري",
    author: "د. سارة أحمد",
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=600",
    createdAt: "2024-02-01",
    views: 980,
    type: "video" as const
  },
  {
    id: 3,
    title: "كيفية تحسين خصوبة التربة",
    content: "التربة هي أساس الزراعة الناجحة...",
    category: "تربة",
    author: "د. خالد عبدالله",
    image: "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=600",
    createdAt: "2024-02-20",
    views: 750,
    type: "pdf" as const
  },
  {
    id: 4,
    title: "فرص الاستثمار في الزراعة المصرية",
    content: "تقدم مصر فرصاً استثمارية واعدة في القطاع الزراعي...",
    category: "استثمار",
    author: "م. محمد علي",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600",
    createdAt: "2024-03-01",
    views: 1500,
    type: "article" as const
  }
];

export const mockFeedback = [
  {
    id: 1,
    userId: 2,
    title: "مشكلة في تسجيل الدخول",
    content: "أواجه مشكلة في تسجيل الدخول إلى حسابي",
    status: "resolved" as const,
    createdAt: "2024-03-01",
    response: "تم حل المشكلة، يرجى المحاولة مرة أخرى"
  },
  {
    id: 2,
    userId: 3,
    title: "اقتراح إضافة محصول جديد",
    content: "أقترح إضافة محصول الكتان إلى قائمة المحاصيل",
    status: "pending" as const,
    createdAt: "2024-03-05",
    response: null
  }
];

export const mockNotifications = [
  {
    id: 1,
    userId: 1,
    title: "مشروع جديد",
    message: "تم إضافة مشروع جديد في توشكى",
    type: "project" as const,
    read: false,
    createdAt: "2024-03-10T10:00:00"
  },
  {
    id: 2,
    userId: 1,
    title: "تعليق جديد",
    message: "قام محمد بإضافة تعليق على مشروعك",
    type: "comment" as const,
    read: false,
    createdAt: "2024-03-09T15:30:00"
  },
  {
    id: 3,
    userId: 1,
    title: "تحديث إحصائي",
    message: "تم تحديث إحصائيات محصول القمح لعام 2024",
    type: "update" as const,
    read: true,
    createdAt: "2024-03-08T09:00:00"
  }
];

export const mockInitiatives = [
  {
    id: 1,
    title: "مبادرة الـ 100 مليون صحة",
    description: "مبادرة لدعم صحة المزارعين وأسرهم",
    startDate: "2024-01-01",
    endDate: "2024-12-31",
    status: "active" as const,
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600",
    participants: 50000
  },
  {
    id: 2,
    title: "مشروع مستقبل مصر",
    description: "استصلاح 2 مليون فدان لدعم الأمن الغذائي",
    startDate: "2024-02-01",
    endDate: "2026-02-01",
    status: "active" as const,
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600",
    participants: 25000
  }
];

export const mockRegions = [
  {
    id: 1,
    name: "الدلتا",
    governorates: ["الدقهلية", "الغربية", "الشرقية", "المنوفية", "كفر الشيخ"],
    mainCrops: ["الأرز", "القمح", "القطن"],
    coordinates: [31.0, 30.8] as [number, number]
  },
  {
    id: 2,
    name: "الوجه البحري",
    governorates: ["البحيرة", "الإسكندرية", "مطروح"],
    mainCrops: ["الذرة", "القمح", "الفاكهة"],
    coordinates: [29.9, 31.2] as [number, number]
  },
  {
    id: 3,
    name: "صعيد مصر",
    governorates: ["المنيا", "أسيوط", "سوهاج", "قنا", "أسوان"],
    mainCrops: ["قصب السكر", "القمح", "الطماطم"],
    coordinates: [31.7, 26.5] as [number, number]
  }
];
