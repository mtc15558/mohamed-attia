import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { NotificationProvider } from '@/contexts/NotificationContext';
import { LoginForm } from '@/components/auth/LoginForm';
import { RegisterForm } from '@/components/auth/RegisterForm';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar } from '@/components/layout/Sidebar';
import { Dashboard } from '@/components/dashboard/Dashboard';
import { UserManagement } from '@/components/dashboard/UserManagement';
import { Initiatives } from '@/components/dashboard/Initiatives';
import { SettingsPage } from '@/components/dashboard/Settings';
import { Help } from '@/components/dashboard/Help';
import { CropsList } from '@/components/crops/CropsList';
import { Statistics } from '@/components/statistics/Statistics';
import { AgriculturalMap } from '@/components/map/AgriculturalMap';
import { Projects } from '@/components/projects/Projects';
import { DecisionSupport } from '@/components/decision/DecisionSupport';
import { Library } from '@/components/library/Library';
import { Feedback } from '@/components/feedback/Feedback';
import { Toaster } from '@/components/ui/sonner';
import { Sprout, Loader2 } from 'lucide-react';
import './App.css';

// Main App Content Component
function AppContent() {
  const { isAuthenticated, isLoading } = useAuth();
  const [showLogin, setShowLogin] = useState(true);
  const [currentView, setCurrentView] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Close sidebar when view changes (on mobile)
  useEffect(() => {
    setIsSidebarOpen(false);
  }, [currentView]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-green-600 mx-auto mb-4" />
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-700 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Sprout className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">منصة مصر الزراعية</h1>
            <p className="text-gray-600">المنصة الذكية للتنمية الزراعية</p>
          </div>

          {showLogin ? (
            <LoginForm onToggleForm={() => setShowLogin(false)} />
          ) : (
            <RegisterForm onToggleForm={() => setShowLogin(true)} />
          )}

          {/* Features */}
          <div className="mt-8 grid grid-cols-3 gap-4 text-center">
            <div className="bg-white/50 rounded-lg p-3">
              <p className="text-2xl font-bold text-green-600">+1000</p>
              <p className="text-xs text-gray-600">مشروع زراعي</p>
            </div>
            <div className="bg-white/50 rounded-lg p-3">
              <p className="text-2xl font-bold text-green-600">+50K</p>
              <p className="text-xs text-gray-600">مستخدم نشط</p>
            </div>
            <div className="bg-white/50 rounded-lg p-3">
              <p className="text-2xl font-bold text-green-600">+100</p>
              <p className="text-xs text-gray-600">محصول مسجل</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'users':
        return <UserManagement />;
      case 'initiatives':
        return <Initiatives />;
      case 'crops':
        return <CropsList />;
      case 'statistics':
        return <Statistics />;
      case 'map':
        return <AgriculturalMap />;
      case 'projects':
        return <Projects />;
      case 'decision':
        return <DecisionSupport />;
      case 'library':
        return <Library />;
      case 'feedback':
        return <Feedback />;
      case 'settings':
        return <SettingsPage />;
      case 'help':
        return <Help />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      <Navbar onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} isSidebarOpen={isSidebarOpen} />
      
      <div className="flex">
        <Sidebar
          isOpen={isSidebarOpen}
          currentView={currentView}
          onViewChange={setCurrentView}
        />
        
        {/* Overlay for mobile */}
        {isSidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
        
        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8 overflow-auto">
          <div className="max-w-7xl mx-auto">
            {renderView()}
          </div>
        </main>
      </div>
    </div>
  );
}

// Main App Component
function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppContent />
        <Toaster position="top-center" />
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;
