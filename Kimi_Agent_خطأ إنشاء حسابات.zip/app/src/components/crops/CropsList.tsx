import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sprout,
  Search,
  Droplets,
  AlertTriangle,
  MapPin,
  Info,
  Plus,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Crop } from '@/types';
import { useAuth } from '@/contexts/AuthContext';

export function CropsList() {
  const { user } = useAuth();
  const [crops, setCrops] = useState<Crop[]>([]);
  const [filteredCrops, setFilteredCrops] = useState<Crop[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [selectedSoil, setSelectedSoil] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCrops();
  }, []);

  useEffect(() => {
    filterCrops();
  }, [searchTerm, selectedSeason, selectedSoil, crops]);

  const fetchCrops = async () => {
    try {
      const data = await api.get<Crop[]>('/crops');
      setCrops(data);
      setFilteredCrops(data);
    } catch (error) {
      console.error('Error fetching crops:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterCrops = () => {
    let filtered = crops;

    if (searchTerm) {
      filtered = filtered.filter(
        crop =>
          crop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          crop.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedSeason !== 'all') {
      filtered = filtered.filter(crop => crop.season === selectedSeason);
    }

    if (selectedSoil !== 'all') {
      filtered = filtered.filter(crop => crop.soilType.includes(selectedSoil));
    }

    setFilteredCrops(filtered);
  };

  const getWaterNeedsColor = (needs: string) => {
    switch (needs) {
      case 'عالية':
        return 'bg-blue-100 text-blue-700';
      case 'متوسطة':
        return 'bg-cyan-100 text-cyan-700';
      case 'منخفضة':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getSeasonColor = (season: string) => {
    switch (season) {
      case 'الصيف':
        return 'bg-orange-100 text-orange-700';
      case 'الشتاء':
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-green-100 text-green-700';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">المحاصيل الزراعية</h2>
          <p className="text-gray-500">استكشف المحاصيل المختلفة ومتطلباتها</p>
        </div>
        {user?.role === 'admin' && (
          <Button className="bg-green-600 hover:bg-green-700">
            <Plus className="h-4 w-4 ml-2" />
            إضافة محصول
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث عن محصول..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
                dir="rtl"
              />
            </div>
            <Select value={selectedSeason} onValueChange={setSelectedSeason}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="الموسم" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المواسم</SelectItem>
                <SelectItem value="الصيف">الصيف</SelectItem>
                <SelectItem value="الشتاء">الشتاء</SelectItem>
                <SelectItem value="طوال العام">طوال العام</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedSoil} onValueChange={setSelectedSoil}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="نوع التربة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع أنواع التربة</SelectItem>
                <SelectItem value="طيني">طيني</SelectItem>
                <SelectItem value="رملي">رملي</SelectItem>
                <SelectItem value="طيني رملي">طيني رملي</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Crops Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredCrops.map((crop) => (
          <Dialog key={crop.id}>
            <DialogTrigger asChild>
              <Card className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden group">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={crop.image}
                    alt={crop.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge className={getSeasonColor(crop.season)}>
                      {crop.season}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="text-lg font-bold mb-2">{crop.name}</h3>
                  <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                    {crop.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-xs">
                      <Droplets className="h-3 w-3 ml-1" />
                      {crop.waterNeeds}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <MapPin className="h-3 w-3 ml-1" />
                      {crop.region}
                    </Badge>
                  </div>
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">متوسط الإنتاج:</span>
                      <span className="font-semibold text-green-600">
                        {crop.avgYield} {crop.yieldUnit}
                      </span>
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-sm text-gray-500">السعر:</span>
                      <span className="font-semibold">
                        {crop.price.toLocaleString()} {crop.currency}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-2xl">{crop.name}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <img
                  src={crop.image}
                  alt={crop.name}
                  className="w-full h-64 object-cover rounded-lg"
                />
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-500">الاسم العلمي</p>
                    <p className="font-medium">{crop.scientificName}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-500">الموسم</p>
                    <Badge className={getSeasonColor(crop.season)}>{crop.season}</Badge>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-500">نوع التربة</p>
                    <p className="font-medium">{crop.soilType}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-500">احتياجات المياه</p>
                    <Badge className={getWaterNeedsColor(crop.waterNeeds)}>
                      {crop.waterNeeds}
                    </Badge>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Info className="h-4 w-4" />
                    الوصف
                  </h4>
                  <p className="text-gray-600">{crop.description}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-orange-500" />
                    المشاكل الشائعة
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {crop.commonProblems.map((problem, index) => (
                      <Badge key={index} variant="secondary">
                        {problem}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">متوسط الإنتاج</p>
                    <p className="text-2xl font-bold text-green-600">
                      {crop.avgYield} {crop.yieldUnit}
                    </p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">السعر الحالي</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {crop.price.toLocaleString()} {crop.currency}
                    </p>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        ))}
      </div>

      {filteredCrops.length === 0 && (
        <div className="text-center py-12">
          <Sprout className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            لا توجد محاصيل مطابقة
          </h3>
          <p className="text-gray-500">
            جرب تغيير معايير البحث أو الفلاتر
          </p>
        </div>
      )}
    </div>
  );
}
