import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BookOpen,
  Search,
  FileText,
  Video,
  FileDown,
  Eye,
  User,
  Calendar,
  Play,
  Download,
  ExternalLink,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Article } from '@/types';

const categories = [
  { id: 'all', name: 'الكل', icon: BookOpen },
  { id: 'محاصيل', name: 'المحاصيل', icon: FileText },
  { id: 'ري', name: 'الري', icon: BookOpen },
  { id: 'تربة', name: 'التربة', icon: FileText },
  { id: 'استثمار', name: 'الاستثمار', icon: BookOpen },
];

export function Library() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<Article[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchArticles();
  }, []);

  useEffect(() => {
    filterArticles();
  }, [searchTerm, selectedCategory, selectedType, articles]);

  const fetchArticles = async () => {
    try {
      const data = await api.get<Article[]>('/articles');
      setArticles(data);
      setFilteredArticles(data);
    } catch (error) {
      console.error('Error fetching articles:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterArticles = () => {
    let filtered = articles;

    if (searchTerm) {
      filtered = filtered.filter(
        (a) =>
          a.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          a.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
          a.author.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((a) => a.category === selectedCategory);
    }

    if (selectedType !== 'all') {
      filtered = filtered.filter((a) => a.type === selectedType);
    }

    setFilteredArticles(filtered);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'pdf':
        return <FileDown className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'video':
        return 'فيديو';
      case 'pdf':
        return 'PDF';
      default:
        return 'مقال';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">المكتبة التعليمية</h2>
          <p className="text-gray-500">مصادر تعليمية وإرشادية في المجال الزراعي</p>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث في المكتبة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
                dir="rtl"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="التصنيف" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع التصنيفات</SelectItem>
                <SelectItem value="محاصيل">المحاصيل</SelectItem>
                <SelectItem value="ري">الري</SelectItem>
                <SelectItem value="تربة">التربة</SelectItem>
                <SelectItem value="استثمار">الاستثمار</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="نوع المحتوى" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأنواع</SelectItem>
                <SelectItem value="article">مقالات</SelectItem>
                <SelectItem value="video">فيديوهات</SelectItem>
                <SelectItem value="pdf">ملفات PDF</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-5 w-full">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <TabsTrigger
                key={cat.id}
                value={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className="gap-2"
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{cat.name}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {categories.map((cat) => (
          <TabsContent key={cat.id} value={cat.id} className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredArticles.map((article) => (
                <Dialog key={article.id}>
                  <DialogTrigger asChild>
                    <Card className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden group">
                      <div className="relative h-48 overflow-hidden">
                        <img
                          src={article.image}
                          alt={article.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-2 left-2">
                          <Badge className="bg-white/90 text-gray-700">
                            {getTypeIcon(article.type)}
                            <span className="mr-1">{getTypeLabel(article.type)}</span>
                          </Badge>
                        </div>
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary">{article.category}</Badge>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-bold text-lg mb-2 line-clamp-2">
                          {article.title}
                        </h3>
                        <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                          {article.content.substring(0, 100)}...
                        </p>
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            {article.author}
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              {article.views}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              {new Date(article.createdAt).toLocaleDateString('ar-EG')}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-2xl">{article.title}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <img
                        src={article.image}
                        alt={article.title}
                        className="w-full h-64 object-cover rounded-lg"
                      />
                      <div className="flex items-center gap-2">
                        <Badge>{article.category}</Badge>
                        <Badge variant="outline">{getTypeLabel(article.type)}</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {article.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(article.createdAt).toLocaleDateString('ar-EG')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {article.views} مشاهدة
                        </span>
                      </div>
                      <div className="prose max-w-none">
                        <p className="text-gray-700 leading-relaxed">{article.content}</p>
                      </div>
                      <div className="flex gap-2">
                        {article.type === 'video' && (
                          <Button className="flex-1 bg-red-600 hover:bg-red-700">
                            <Play className="h-4 w-4 ml-2" />
                            مشاهدة الفيديو
                          </Button>
                        )}
                        {article.type === 'pdf' && (
                          <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                            <Download className="h-4 w-4 ml-2" />
                            تحميل PDF
                          </Button>
                        )}
                        <Button variant="outline" className="flex-1">
                          <ExternalLink className="h-4 w-4 ml-2" />
                          مشاركة
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              ))}
            </div>

            {filteredArticles.length === 0 && (
              <div className="text-center py-12">
                <BookOpen className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  لا توجد مقالات مطابقة
                </h3>
                <p className="text-gray-500">
                  جرب تغيير معايير البحث أو الفلاتر
                </p>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Featured Resources */}
      <Card>
        <CardHeader>
          <CardTitle>مصادر موصى بها</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                title: 'دليل المزارع المصري',
                description: 'دليل شامل للممارسات الزراعية السليمة',
                icon: BookOpen,
                color: 'bg-green-100 text-green-600',
              },
              {
                title: 'نظم الري الحديثة',
                description: 'تعرف على أحدث تقنيات الري',
                icon: Play,
                color: 'bg-blue-100 text-blue-600',
              },
              {
                title: 'تقارير الاستثمار الزراعي',
                description: 'دراسات جدوى وفرص استثمارية',
                icon: FileDown,
                color: 'bg-purple-100 text-purple-600',
              },
              {
                title: 'الإرشاد الزراعي',
                description: 'استشارات ونصائح من الخبراء',
                icon: ExternalLink,
                color: 'bg-orange-100 text-orange-600',
              },
            ].map((resource, index) => {
              const Icon = resource.icon;
              return (
                <div
                  key={index}
                  className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                >
                  <div className={`w-12 h-12 ${resource.color} rounded-lg flex items-center justify-center mb-3`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <h4 className="font-medium mb-1">{resource.title}</h4>
                  <p className="text-sm text-gray-500">{resource.description}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
