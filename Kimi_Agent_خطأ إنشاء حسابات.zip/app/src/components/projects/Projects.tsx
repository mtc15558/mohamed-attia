import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Briefcase,
  Search,
  MapPin,
  TrendingUp,
  Clock,
  Star,
  MessageSquare,
  Plus,
  Filter,
  DollarSign,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Project, Crop } from '@/types';

export function Projects() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [crops, setCrops] = useState<Crop[]>([]);
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedCrop, setSelectedCrop] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    governorate: '',
    cropType: '',
    investmentCost: '',
    expectedReturn: '',
    duration: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    filterProjects();
  }, [searchTerm, selectedStatus, selectedCrop, projects]);

  const fetchData = async () => {
    try {
      const [projectsData, cropsData] = await Promise.all([
        api.get<Project[]>('/projects'),
        api.get<Crop[]>('/crops'),
      ]);
      setProjects(projectsData);
      setFilteredProjects(projectsData);
      setCrops(cropsData);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterProjects = () => {
    let filtered = projects;

    if (searchTerm) {
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.location.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter((p) => p.status === selectedStatus);
    }

    if (selectedCrop !== 'all') {
      filtered = filtered.filter((p) => p.cropType === selectedCrop);
    }

    setFilteredProjects(filtered);
  };

  const handleAddProject = async () => {
    try {
      const newProject = await api.post<Project>('/projects', {
        ...formData,
        investmentCost: parseInt(formData.investmentCost),
        expectedReturn: parseInt(formData.expectedReturn),
        status: 'pending',
        rating: 0,
        reviews: 0,
        ownerId: user?.id,
        coordinates: [30.0, 31.0],
        image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600',
      });
      setProjects([...projects, newProject]);
      setShowAddDialog(false);
      setFormData({
        title: '',
        description: '',
        location: '',
        governorate: '',
        cropType: '',
        investmentCost: '',
        expectedReturn: '',
        duration: '',
      });
    } catch (error) {
      console.error('Error adding project:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-700">نشط</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-700">معلق</Badge>;
      case 'completed':
        return <Badge className="bg-blue-100 text-blue-700">مكتمل</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-700">مرفوض</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getROI = (project: Project) => {
    return ((project.expectedReturn - project.investmentCost) / project.investmentCost * 100).toFixed(1);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">المشروعات الزراعية</h2>
          <p className="text-gray-500">استكشف وشارك في المشروعات الزراعية</p>
        </div>
        {(user?.role === 'admin' || user?.role === 'investor') && (
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 ml-2" />
                إضافة مشروع
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>إضافة مشروع جديد</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>عنوان المشروع</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="مثال: مشروع استصلاح 1000 فدان"
                    className="text-right"
                    dir="rtl"
                  />
                </div>
                <div>
                  <Label>الوصف</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="وصف تفصيلي للمشروع"
                    className="text-right"
                    dir="rtl"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>الموقع</Label>
                    <Input
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="الموقع"
                      className="text-right"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <Label>المحافظة</Label>
                    <Input
                      value={formData.governorate}
                      onChange={(e) => setFormData({ ...formData, governorate: e.target.value })}
                      placeholder="المحافظة"
                      className="text-right"
                      dir="rtl"
                    />
                  </div>
                </div>
                <div>
                  <Label>نوع المحصول</Label>
                  <Select
                    value={formData.cropType}
                    onValueChange={(value) => setFormData({ ...formData, cropType: value })}
                  >
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر المحصول" />
                    </SelectTrigger>
                    <SelectContent>
                      {crops.map((crop) => (
                        <SelectItem key={crop.id} value={crop.name}>
                          {crop.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>التكلفة الاستثمارية</Label>
                    <Input
                      type="number"
                      value={formData.investmentCost}
                      onChange={(e) => setFormData({ ...formData, investmentCost: e.target.value })}
                      placeholder="بالجنيه المصري"
                    />
                  </div>
                  <div>
                    <Label>العائد المتوقع</Label>
                    <Input
                      type="number"
                      value={formData.expectedReturn}
                      onChange={(e) => setFormData({ ...formData, expectedReturn: e.target.value })}
                      placeholder="بالجنيه المصري"
                    />
                  </div>
                </div>
                <div>
                  <Label>المدة</Label>
                  <Input
                    value={formData.duration}
                    onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                    placeholder="مثال: 3 سنوات"
                    className="text-right"
                    dir="rtl"
                  />
                </div>
                <Button onClick={handleAddProject} className="w-full bg-green-600 hover:bg-green-700">
                  إضافة المشروع
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث عن مشروع..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
                dir="rtl"
              />
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الحالات</SelectItem>
                <SelectItem value="active">نشط</SelectItem>
                <SelectItem value="pending">معلق</SelectItem>
                <SelectItem value="completed">مكتمل</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedCrop} onValueChange={setSelectedCrop}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="نوع المحصول" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المحاصيل</SelectItem>
                {crops.map((crop) => (
                  <SelectItem key={crop.id} value={crop.name}>
                    {crop.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              تصفية متقدمة
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProjects.map((project) => (
          <Card key={project.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative h-48">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 right-2">
                {getStatusBadge(project.status)}
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg mb-2">{project.title}</h3>
              <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                {project.description}
              </p>
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                <MapPin className="h-4 w-4" />
                {project.location}، {project.governorate}
              </div>
              <div className="flex items-center gap-4 mb-3">
                <div className="flex items-center gap-1">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <span className="font-semibold">
                    {project.investmentCost.toLocaleString()} ج.م
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <TrendingUp className="h-4 w-4 text-blue-600" />
                  <span className="font-semibold">{getROI(project)}% عائد</span>
                </div>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm">{project.rating}</span>
                  <span className="text-xs text-gray-400">({project.reviews})</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Clock className="h-4 w-4" />
                  {project.duration}
                </div>
              </div>
              <Button
                variant="outline"
                className="w-full mt-3"
                onClick={() => setSelectedProject(project)}
              >
                عرض التفاصيل
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProjects.length === 0 && (
        <div className="text-center py-12">
          <Briefcase className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            لا توجد مشروعات مطابقة
          </h3>
          <p className="text-gray-500">
            جرب تغيير معايير البحث أو الفلاتر
          </p>
        </div>
      )}

      {/* Project Details Dialog */}
      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedProject && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedProject.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-64 object-cover rounded-lg"
                />
                <div className="flex items-center gap-2">
                  {getStatusBadge(selectedProject.status)}
                  <Badge variant="outline">{selectedProject.cropType}</Badge>
                </div>
                <p className="text-gray-600">{selectedProject.description}</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">التكلفة الاستثمارية</p>
                    <p className="text-xl font-bold text-green-600">
                      {selectedProject.investmentCost.toLocaleString()} ج.م
                    </p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">العائد المتوقع</p>
                    <p className="text-xl font-bold text-blue-600">
                      {selectedProject.expectedReturn.toLocaleString()} ج.م
                    </p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">نسبة العائد</p>
                    <p className="text-xl font-bold text-purple-600">
                      {getROI(selectedProject)}%
                    </p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">المدة</p>
                    <p className="text-xl font-bold">{selectedProject.duration}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-gray-400" />
                    <span>{selectedProject.location}، {selectedProject.governorate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    <span>{selectedProject.rating} ({selectedProject.reviews} تقييم)</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1 bg-green-600 hover:bg-green-700">
                    الاستثمار في المشروع
                  </Button>
                  <Button variant="outline" className="flex-1 gap-2">
                    <MessageSquare className="h-4 w-4" />
                    تواصل
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
