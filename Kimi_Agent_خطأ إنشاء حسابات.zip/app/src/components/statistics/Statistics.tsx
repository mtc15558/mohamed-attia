import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  FileText,
  Table,
  BarChart3,
  PieChart as PieChartIcon,
  ArrowUpRight,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Crop, Statistic } from '@/types';

const COLORS = ['#16a34a', '#22c55e', '#4ade80', '#86efac', '#bbf7d0', '#15803d'];

export function Statistics() {
  const [crops, setCrops] = useState<Crop[]>([]);
  const [statistics, setStatistics] = useState<Statistic[]>([]);
  const [selectedCrop, setSelectedCrop] = useState<string>('all');
  const [selectedYear, setSelectedYear] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [cropsData, statsData] = await Promise.all([
        api.get<Crop[]>('/crops'),
        api.get<Statistic[]>('/statistics'),
      ]);
      setCrops(cropsData);
      setStatistics(statsData);
    } catch (error) {
      console.error('Error fetching statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredStats = () => {
    let filtered = statistics;
    if (selectedCrop !== 'all') {
      filtered = filtered.filter(s => s.cropId === parseInt(selectedCrop));
    }
    if (selectedYear !== 'all') {
      filtered = filtered.filter(s => s.year === parseInt(selectedYear));
    }
    return filtered;
  };

  const getProductionData = () => {
    const filtered = getFilteredStats();
    const groupedByYear = filtered.reduce((acc, stat) => {
      if (!acc[stat.year]) {
        acc[stat.year] = { year: stat.year, production: 0, export: 0 };
      }
      acc[stat.year].production += stat.production;
      acc[stat.year].export += stat.export;
      return acc;
    }, {} as Record<number, { year: number; production: number; export: number }>);

    return Object.values(groupedByYear).sort((a, b) => a.year - b.year);
  };

  const getSelfSufficiencyData = () => {
    const filtered = getFilteredStats();
    return filtered.map(stat => ({
      year: stat.year,
      selfSufficiency: stat.selfSufficiency,
      cropName: crops.find(c => c.id === stat.cropId)?.name || '',
    }));
  };

  const getCropDistribution = () => {
    const filtered = getFilteredStats();
    const groupedByCrop = filtered.reduce((acc, stat) => {
      const cropName = crops.find(c => c.id === stat.cropId)?.name || 'Unknown';
      if (!acc[cropName]) {
        acc[cropName] = 0;
      }
      acc[cropName] += stat.production;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(groupedByCrop).map(([name, value]) => ({
      name,
      value,
    }));
  };

  const getLatestStats = () => {
    const latestYear = Math.max(...statistics.map(s => s.year));
    return statistics.filter(s => s.year === latestYear);
  };

  const getGrowthRate = () => {
    const productionData = getProductionData();
    if (productionData.length < 2) return 0;
    const current = productionData[productionData.length - 1].production;
    const previous = productionData[productionData.length - 2].production;
    return ((current - previous) / previous) * 100;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">الإحصائيات الزراعية</h2>
          <p className="text-gray-500">تحليل البيانات الزراعية والتقارير</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <FileText className="h-4 w-4" />
            تصدير PDF
          </Button>
          <Button variant="outline" className="gap-2">
            <Table className="h-4 w-4" />
            تصدير Excel
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select value={selectedCrop} onValueChange={setSelectedCrop}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="اختر المحصول" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المحاصيل</SelectItem>
                {crops.map(crop => (
                  <SelectItem key={crop.id} value={crop.id.toString()}>
                    {crop.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="اختر السنة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع السنوات</SelectItem>
                {[2020, 2021, 2022, 2023, 2024].map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">إجمالي الإنتاج</p>
                <p className="text-2xl font-bold">
                  {getProductionData()
                    .reduce((sum, d) => sum + d.production, 0)
                    .toFixed(1)} مليون طن
                </p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <ArrowUpRight className="h-4 w-4" />
                  <span>+{getGrowthRate().toFixed(1)}%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">إجمالي الصادرات</p>
                <p className="text-2xl font-bold">
                  {getProductionData()
                    .reduce((sum, d) => sum + d.export, 0)
                    .toFixed(1)} مليون طن
                </p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <ArrowUpRight className="h-4 w-4" />
                  <span>+18%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">متوسط الاكتفاء الذاتي</p>
                <p className="text-2xl font-bold">
                  {getSelfSufficiencyData().length > 0
                    ? (
                        getSelfSufficiencyData().reduce((sum, d) => sum + d.selfSufficiency, 0) /
                        getSelfSufficiencyData().length
                      ).toFixed(1)
                    : 0}%
                </p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <ArrowUpRight className="h-4 w-4" />
                  <span>+5%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <PieChartIcon className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">عدد المحاصيل</p>
                <p className="text-2xl font-bold">{crops.length}</p>
                <div className="flex items-center gap-1 text-gray-500 text-sm mt-1">
                  <span>محصول مسجل</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <TrendingDown className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Production Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              تطور الإنتاج والصادرات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={getProductionData()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="production" fill="#16a34a" name="الإنتاج" />
                <Bar dataKey="export" fill="#22c55e" name="الصادرات" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Self Sufficiency Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              نسبة الاكتفاء الذاتي
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={getSelfSufficiencyData()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis domain={[0, 150]} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="selfSufficiency"
                  stroke="#16a34a"
                  fill="#16a34a"
                  fillOpacity={0.3}
                  name="% الاكتفاء الذاتي"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Crop Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChartIcon className="h-5 w-5" />
            توزيع الإنتاج حسب المحصول
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={getCropDistribution()}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                  label={({ name, percent }) =>
                    `${name} ${(percent * 100).toFixed(0)}%`
                  }
                >
                  {getCropDistribution().map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-4">
              <h4 className="font-semibold">تفاصيل الإنتاج</h4>
              <div className="space-y-2">
                {getCropDistribution().map((crop, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      <span>{crop.name}</span>
                    </div>
                    <span className="font-semibold">
                      {crop.value.toFixed(1)} مليون طن
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Latest Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>أحدث البيانات ({Math.max(...statistics.map(s => s.year))})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-right py-3 px-4">المحصول</th>
                  <th className="text-right py-3 px-4">الإنتاج</th>
                  <th className="text-right py-3 px-4">الصادرات</th>
                  <th className="text-right py-3 px-4">الاكتفاء الذاتي</th>
                  <th className="text-right py-3 px-4">التوجه</th>
                </tr>
              </thead>
              <tbody>
                {getLatestStats().map((stat) => {
                  const crop = crops.find(c => c.id === stat.cropId);
                  return (
                    <tr key={stat.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium">{crop?.name}</td>
                      <td className="py-3 px-4">
                        {stat.production} {stat.unit}
                      </td>
                      <td className="py-3 px-4">{stat.export} مليون طن</td>
                      <td className="py-3 px-4">
                        <Badge
                          className={
                            stat.selfSufficiency >= 100
                              ? 'bg-green-100 text-green-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }
                        >
                          {stat.selfSufficiency}%
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        {stat.selfSufficiency >= 100 ? (
                          <span className="text-green-600 flex items-center gap-1">
                            <ArrowUpRight className="h-4 w-4" />
                            مكتف
                          </span>
                        ) : (
                          <span className="text-yellow-600 flex items-center gap-1">
                            <TrendingDown className="h-4 w-4" />
                            غير مكتف
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
