import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  MapPin,
  Search,
  Layers,
  Sprout,
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { api } from '@/lib/api';
import type { Project, Region, Crop } from '@/types';

// Fix Leaflet default icons
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

// Custom icons
const projectIcon = L.divIcon({
  className: 'custom-div-icon',
  html: `<div style="background-color: #16a34a; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path></svg></div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 30],
});

const regionIcon = L.divIcon({
  className: 'custom-div-icon',
  html: `<div style="background-color: #2563eb; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"></polygon></svg></div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 30],
});

function MapController({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

export function AgriculturalMap() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [crops, setCrops] = useState<Crop[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedCrop, setSelectedCrop] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [mapCenter, setMapCenter] = useState<[number, number]>([26.8, 30.8]);
  const [mapZoom, setMapZoom] = useState(6);
  const [showProjects, setShowProjects] = useState(true);
  const [showRegions, setShowRegions] = useState(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [projectsData, regionsData, cropsData] = await Promise.all([
        api.get<Project[]>('/projects'),
        api.get<Region[]>('/regions'),
        api.get<Crop[]>('/crops'),
      ]);
      setProjects(projectsData);
      setRegions(regionsData);
      setCrops(cropsData);
    } catch (error) {
      console.error('Error fetching map data:', error);
    }
  };

  const filteredProjects = projects.filter((project) => {
    const matchesRegion = selectedRegion === 'all' || project.governorate === selectedRegion;
    const matchesCrop = selectedCrop === 'all' || project.cropType === selectedCrop;
    const matchesSearch =
      searchTerm === '' ||
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesRegion && matchesCrop && matchesSearch;
  });

  const handleRegionClick = (region: Region) => {
    setMapCenter(region.coordinates);
    setMapZoom(8);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">الخريطة الزراعية الذكية</h2>
          <p className="text-gray-500">استكشف المشروعات والمناطق الزراعية في مصر</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث عن مشروع..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
                dir="rtl"
              />
            </div>
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="المحافظة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المحافظات</SelectItem>
                {regions.map((region) =>
                  region.governorates.map((gov) => (
                    <SelectItem key={gov} value={gov}>
                      {gov}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
            <Select value={selectedCrop} onValueChange={setSelectedCrop}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="نوع المحصول" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المحاصيل</SelectItem>
                {crops.map((crop) => (
                  <SelectItem key={crop.id} value={crop.name}>
                    {crop.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button
                variant={showProjects ? 'default' : 'outline'}
                onClick={() => setShowProjects(!showProjects)}
                className="flex-1"
              >
                <Layers className="h-4 w-4 ml-2" />
                المشروعات
              </Button>
              <Button
                variant={showRegions ? 'default' : 'outline'}
                onClick={() => setShowRegions(!showRegions)}
                className="flex-1"
              >
                <MapPin className="h-4 w-4 ml-2" />
                المناطق
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map and Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map */}
        <Card className="lg:col-span-2">
          <CardContent className="p-0">
            <div className="h-[500px] rounded-lg overflow-hidden">
              <MapContainer
                center={mapCenter}
                zoom={mapZoom}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <MapController center={mapCenter} zoom={mapZoom} />

                {showProjects &&
                  filteredProjects.map((project) => (
                    <Marker
                      key={project.id}
                      position={project.coordinates}
                      icon={projectIcon}
                      eventHandlers={{
                        click: () => setSelectedProject(project),
                      }}
                    >
                      <Popup>
                        <div className="text-right p-2">
                          <h3 className="font-bold text-lg">{project.title}</h3>
                          <p className="text-sm text-gray-600">{project.location}</p>
                          <Badge className="mt-2" variant={project.status === 'active' ? 'default' : 'secondary'}>
                            {project.status === 'active' ? 'نشط' : 'معلق'}
                          </Badge>
                          <p className="mt-2 text-sm">
                            <strong>التكلفة:</strong>{' '}
                            {project.investmentCost.toLocaleString()} ج.م
                          </p>
                          <p className="text-sm">
                            <strong>العائد المتوقع:</strong>{' '}
                            {project.expectedReturn.toLocaleString()} ج.م
                          </p>
                        </div>
                      </Popup>
                    </Marker>
                  ))}

                {showRegions &&
                  regions.map((region) => (
                    <Marker
                      key={region.id}
                      position={region.coordinates}
                      icon={regionIcon}
                      eventHandlers={{
                        click: () => handleRegionClick(region),
                      }}
                    >
                      <Popup>
                        <div className="text-right p-2">
                          <h3 className="font-bold text-lg">{region.name}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            <strong>المحافظات:</strong>{' '}
                            {region.governorates.join('، ')}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">
                            <strong>المحاصيل الرئيسية:</strong>{' '}
                            {region.mainCrops.join('، ')}
                          </p>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
              </MapContainer>
            </div>
          </CardContent>
        </Card>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Project Details */}
          {selectedProject && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">تفاصيل المشروع</CardTitle>
              </CardHeader>
              <CardContent>
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-40 object-cover rounded-lg mb-4"
                />
                <h3 className="font-bold text-lg mb-2">{selectedProject.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{selectedProject.description}</p>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500">الموقع:</span>
                    <span>{selectedProject.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">نوع المحصول:</span>
                    <Badge variant="outline">{selectedProject.cropType}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">التكلفة:</span>
                    <span className="font-semibold text-green-600">
                      {selectedProject.investmentCost.toLocaleString()} ج.م
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">العائد المتوقع:</span>
                    <span className="font-semibold text-blue-600">
                      {selectedProject.expectedReturn.toLocaleString()} ج.م
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">المدة:</span>
                    <span>{selectedProject.duration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">التقييم:</span>
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-500">★</span>
                      <span>{selectedProject.rating}</span>
                      <span className="text-gray-400">({selectedProject.reviews})</span>
                    </div>
                  </div>
                </div>
                <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">
                  عرض التفاصيل الكاملة
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Regions List */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">المناطق الزراعية</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-[300px] overflow-y-auto">
                {regions.map((region) => (
                  <button
                    key={region.id}
                    onClick={() => handleRegionClick(region)}
                    className="w-full text-right p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <h4 className="font-medium">{region.name}</h4>
                    <p className="text-sm text-gray-500">
                      {region.governorates.length} محافظة
                    </p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {region.mainCrops.slice(0, 3).map((crop, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {crop}
                        </Badge>
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">إحصائيات سريعة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 p-3 rounded-lg text-center">
                  <Sprout className="h-6 w-6 mx-auto text-green-600 mb-1" />
                  <p className="text-2xl font-bold">{filteredProjects.length}</p>
                  <p className="text-sm text-gray-500">مشروع</p>
                </div>
                <div className="bg-blue-50 p-3 rounded-lg text-center">
                  <MapPin className="h-6 w-6 mx-auto text-blue-600 mb-1" />
                  <p className="text-2xl font-bold">{regions.length}</p>
                  <p className="text-sm text-gray-500">منطقة</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
