import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import {
  MessageSquare,
  Plus,
  Search,
  CheckCircle,
  Clock,
  AlertCircle,
  Send,
  User as UserIcon,
  Calendar,
  Reply,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Feedback as FeedbackType, User } from '@/types';

export function Feedback() {
  const { user } = useAuth();
  const [feedbacks, setFeedbacks] = useState<FeedbackType[]>([]);
  const [filteredFeedbacks, setFilteredFeedbacks] = useState<FeedbackType[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState<FeedbackType | null>(null);
  const [replyText, setReplyText] = useState('');

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    content: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    filterFeedbacks();
  }, [searchTerm, selectedStatus, feedbacks]);

  const fetchData = async () => {
    try {
      const [feedbacksData, usersData] = await Promise.all([
        api.get<FeedbackType[]>('/feedback'),
        api.get<User[]>('/users'),
      ]);
      setFeedbacks(feedbacksData);
      setFilteredFeedbacks(feedbacksData);
      setUsers(usersData);
    } catch (error) {
      console.error('Error fetching feedback:', error);
    }
  };

  const filterFeedbacks = () => {
    let filtered = feedbacks;

    if (searchTerm) {
      filtered = filtered.filter(
        (f) =>
          f.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          f.content.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter((f) => f.status === selectedStatus);
    }

    setFilteredFeedbacks(filtered);
  };

  const handleSubmitFeedback = async () => {
    try {
      const newFeedback = await api.post<FeedbackType>('/feedback', {
        ...formData,
        userId: user?.id,
        status: 'pending',
        createdAt: new Date().toISOString().split('T')[0],
      });
      setFeedbacks([newFeedback, ...feedbacks]);
      setShowAddDialog(false);
      setFormData({ title: '', content: '' });
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  };

  const handleReply = async () => {
    if (!selectedFeedback || !replyText) return;

    try {
      const updated = await api.put<FeedbackType>(`/feedback/${selectedFeedback.id}`, {
        ...selectedFeedback,
        status: 'resolved',
        response: replyText,
      });
      setFeedbacks(feedbacks.map((f) => (f.id === updated.id ? updated : f)));
      setSelectedFeedback(null);
      setReplyText('');
    } catch (error) {
      console.error('Error replying to feedback:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'resolved':
        return (
          <Badge className="bg-green-100 text-green-700">
            <CheckCircle className="h-3 w-3 ml-1" />
            تم الحل
          </Badge>
        );
      case 'in-progress':
        return (
          <Badge className="bg-blue-100 text-blue-700">
            <Clock className="h-3 w-3 ml-1" />
            قيد المعالجة
          </Badge>
        );
      default:
        return (
          <Badge className="bg-yellow-100 text-yellow-700">
            <AlertCircle className="h-3 w-3 ml-1" />
            معلق
          </Badge>
        );
    }
  };

  const getUserName = (userId: number) => {
    const u = users.find((u) => u.id === userId);
    return u?.name || 'مستخدم غير معروف';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">الشكاوى والملاحظات</h2>
          <p className="text-gray-500">تقديم الشكاوى والمقترحات ومتابعتها</p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 ml-2" />
              شكوى جديدة
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>تقديم شكوى أو مقترح</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>العنوان</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="عنوان الشكوى أو المقترح"
                  className="text-right"
                  dir="rtl"
                />
              </div>
              <div>
                <Label>التفاصيل</Label>
                <Textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="اشرح المشكلة أو المقترح بالتفصيل"
                  className="text-right min-h-[150px]"
                  dir="rtl"
                />
              </div>
              <Button
                onClick={handleSubmitFeedback}
                disabled={!formData.title || !formData.content}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <Send className="h-4 w-4 ml-2" />
                إرسال
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">إجمالي الشكاوى</p>
              <p className="text-2xl font-bold">{feedbacks.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="h-6 w-6 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">تم الحل</p>
              <p className="text-2xl font-bold">
                {feedbacks.filter((f) => f.status === 'resolved').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">معلق</p>
              <p className="text-2xl font-bold">
                {feedbacks.filter((f) => f.status === 'pending').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث في الشكاوى..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
                dir="rtl"
              />
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الحالات</SelectItem>
                <SelectItem value="pending">معلق</SelectItem>
                <SelectItem value="in-progress">قيد المعالجة</SelectItem>
                <SelectItem value="resolved">تم الحل</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Feedback List */}
      <div className="space-y-4">
        {filteredFeedbacks.map((feedback) => (
          <Card key={feedback.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-lg">{feedback.title}</h3>
                    {getStatusBadge(feedback.status)}
                  </div>
                  <p className="text-gray-600 mb-3">{feedback.content}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <UserIcon className="h-4 w-4" />
                      {getUserName(feedback.userId)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {new Date(feedback.createdAt).toLocaleDateString('ar-EG')}
                    </span>
                  </div>
                  {feedback.response && (
                    <div className="mt-3 p-3 bg-green-50 rounded-lg">
                      <p className="text-sm font-medium text-green-800 mb-1">الرد:</p>
                      <p className="text-sm text-green-700">{feedback.response}</p>
                    </div>
                  )}
                </div>
                {user?.role === 'admin' && feedback.status !== 'resolved' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedFeedback(feedback)}
                  >
                    <Reply className="h-4 w-4 ml-1" />
                    رد
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredFeedbacks.length === 0 && (
          <div className="text-center py-12">
            <MessageSquare className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              لا توجد شكاوى مطابقة
            </h3>
            <p className="text-gray-500">
              جرب تغيير معايير البحث أو قم بتقديم شكوى جديدة
            </p>
          </div>
        )}
      </div>

      {/* Reply Dialog */}
      <Dialog open={!!selectedFeedback} onOpenChange={() => setSelectedFeedback(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>الرد على الشكوى</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-gray-50 p-3 rounded-lg">
              <p className="font-medium">{selectedFeedback?.title}</p>
              <p className="text-sm text-gray-600">{selectedFeedback?.content}</p>
            </div>
            <div>
              <Label>الرد</Label>
              <Textarea
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="اكتب ردك هنا..."
                className="text-right min-h-[100px]"
                dir="rtl"
              />
            </div>
            <Button
              onClick={handleReply}
              disabled={!replyText}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Send className="h-4 w-4 ml-2" />
              إرسال الرد
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
