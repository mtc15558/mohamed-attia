import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Sprout,
  BarChart3,
  Map,
  Briefcase,
  BookOpen,
  MessageSquare,
  Lightbulb,
  Users,
  Settings,
  HelpCircle,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  currentView: string;
  onViewChange: (view: string) => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  roles: string[];
  badge?: string;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'crops', label: 'المحاصيل الزراعية', icon: Sprout, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'statistics', label: 'الإحصائيات', icon: BarChart3, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'map', label: 'الخريطة الزراعية', icon: Map, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'projects', label: 'المشروعات', icon: Briefcase, roles: ['admin', 'farmer', 'investor'] },
  { id: 'decision', label: 'دعم القرار', icon: Lightbulb, roles: ['admin', 'farmer'] },
  { id: 'library', label: 'المكتبة التعليمية', icon: BookOpen, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'feedback', label: 'الشكاوى والملاحظات', icon: MessageSquare, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'users', label: 'إدارة المستخدمين', icon: Users, roles: ['admin'] },
  { id: 'settings', label: 'الإعدادات', icon: Settings, roles: ['admin', 'farmer', 'investor', 'student'] },
  { id: 'help', label: 'المساعدة', icon: HelpCircle, roles: ['admin', 'farmer', 'investor', 'student'] },
];

export function Sidebar({ isOpen, currentView, onViewChange }: SidebarProps) {
  const { user } = useAuth();

  const filteredNavItems = navItems.filter(item => 
    user && item.roles.includes(user.role)
  );

  return (
    <aside
      className={cn(
        'fixed inset-y-0 right-0 z-40 w-64 bg-white border-l border-gray-200 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-auto',
        isOpen ? 'translate-x-0' : 'translate-x-full'
      )}
    >
      <div className="h-full flex flex-col">
        {/* Logo for mobile */}
        <div className="lg:hidden p-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-700 rounded-lg flex items-center justify-center">
              <Sprout className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">منصة مصر الزراعية</h1>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4">
          <ul className="space-y-1">
            {filteredNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onViewChange(item.id)}
                    className={cn(
                      'w-full flex items-center gap-3 px-4 py-3 rounded-lg text-right transition-all duration-200',
                      isActive
                        ? 'bg-green-50 text-green-700 border-r-4 border-green-600'
                        : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                    )}
                  >
                    <Icon className={cn(
                      'h-5 w-5',
                      isActive ? 'text-green-600' : 'text-gray-500'
                    )} />
                    <span className="flex-1 font-medium">{item.label}</span>
                    {item.badge && (
                      <span className="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                    {isActive && <ChevronRight className="h-4 w-4" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="bg-gradient-to-br from-green-500 to-green-700 rounded-lg p-4 text-white">
            <p className="text-sm font-medium mb-1">هل تحتاج مساعدة؟</p>
            <p className="text-xs opacity-90 mb-3">تواصل مع فريق الدعم</p>
            <button className="w-full bg-white/20 hover:bg-white/30 text-white text-sm py-2 rounded transition-colors">
              تواصل معنا
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
