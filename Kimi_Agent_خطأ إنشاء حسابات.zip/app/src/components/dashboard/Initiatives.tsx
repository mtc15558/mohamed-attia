import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import {
  Sprout,
  Plus,
  Search,
  Edit,
  Trash2,
  Calendar,
  Users,
  CheckCircle,
  Clock,
  Play,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Initiative } from '@/types';

export function Initiatives() {
  const [initiatives, setInitiatives] = useState<Initiative[]>([]);
  const [filteredInitiatives, setFilteredInitiatives] = useState<Initiative[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingInitiative, setEditingInitiative] = useState<Initiative | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    startDate: '',
    endDate: '',
    status: 'upcoming',
    image: '',
    participants: 0,
  });

  useEffect(() => {
    fetchInitiatives();
  }, []);

  useEffect(() => {
    filterInitiatives();
  }, [searchTerm, selectedStatus, initiatives]);

  const fetchInitiatives = async () => {
    try {
      const data = await api.get<Initiative[]>('/initiatives');
      setInitiatives(data);
      setFilteredInitiatives(data);
    } catch (error) {
      console.error('Error fetching initiatives:', error);
    }
  };

  const filterInitiatives = () => {
    let filtered = initiatives;

    if (searchTerm) {
      filtered = filtered.filter(
        (i) =>
          i.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          i.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter((i) => i.status === selectedStatus);
    }

    setFilteredInitiatives(filtered);
  };

  const handleAddInitiative = async () => {
    try {
      const newInitiative = await api.post<Initiative>('/initiatives', {
        ...formData,
        participants: parseInt(formData.participants.toString()) || 0,
      });
      setInitiatives([...initiatives, newInitiative]);
      setShowAddDialog(false);
      resetForm();
    } catch (error) {
      console.error('Error adding initiative:', error);
    }
  };

  const handleEditInitiative = async () => {
    if (!editingInitiative) return;

    try {
      const updated = await api.put<Initiative>(`/initiatives/${editingInitiative.id}`, {
        ...editingInitiative,
        ...formData,
        participants: parseInt(formData.participants.toString()) || 0,
      });
      setInitiatives(initiatives.map((i) => (i.id === updated.id ? updated : i)));
      setEditingInitiative(null);
      resetForm();
    } catch (error) {
      console.error('Error updating initiative:', error);
    }
  };

  const handleDeleteInitiative = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذه المبادرة؟')) return;

    try {
      await api.delete(`/initiatives/${id}`);
      setInitiatives(initiatives.filter((i) => i.id !== id));
    } catch (error) {
      console.error('Error deleting initiative:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      startDate: '',
      endDate: '',
      status: 'upcoming',
      image: '',
      participants: 0,
    });
  };

  const openEditDialog = (initiative: Initiative) => {
    setEditingInitiative(initiative);
    setFormData({
      title: initiative.title,
      description: initiative.description,
      startDate: initiative.startDate,
      endDate: initiative.endDate,
      status: initiative.status,
      image: initiative.image,
      participants: initiative.participants,
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <Badge className="bg-green-100 text-green-700">
            <Play className="h-3 w-3 ml-1" />
            نشطة
          </Badge>
        );
      case 'completed':
        return (
          <Badge className="bg-blue-100 text-blue-700">
            <CheckCircle className="h-3 w-3 ml-1" />
            مكتملة
          </Badge>
        );
      default:
        return (
          <Badge className="bg-yellow-100 text-yellow-700">
            <Clock className="h-3 w-3 ml-1" />
            قريباً
          </Badge>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">المبادرات</h2>
          <p className="text-gray-500">إدارة المبادرات والبرامج الزراعية</p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 ml-2" />
              إضافة مبادرة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>إضافة مبادرة جديدة</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>العنوان</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="عنوان المبادرة"
                  className="text-right"
                  dir="rtl"
                />
              </div>
              <div>
                <Label>الوصف</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="وصف تفصيلي للمبادرة"
                  className="text-right min-h-[100px]"
                  dir="rtl"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>تاريخ البدء</Label>
                  <Input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label>تاريخ الانتهاء</Label>
                  <Input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>الحالة</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value as Initiative['status'] })}
                  >
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الحالة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="upcoming">قريباً</SelectItem>
                      <SelectItem value="active">نشطة</SelectItem>
                      <SelectItem value="completed">مكتملة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>عدد المشاركين المتوقع</Label>
                  <Input
                    type="number"
                    value={formData.participants}
                    onChange={(e) => setFormData({ ...formData, participants: parseInt(e.target.value) })}
                    placeholder="0"
                  />
                </div>
              </div>
              <div>
                <Label>رابط الصورة</Label>
                <Input
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
              <Button
                onClick={handleAddInitiative}
                disabled={!formData.title || !formData.description}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                إضافة المبادرة
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">إجمالي المبادرات</p>
              <p className="text-2xl font-bold">{initiatives.length}</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Sprout className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">نشطة</p>
              <p className="text-2xl font-bold">
                {initiatives.filter((i) => i.status === 'active').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Play className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">مكتملة</p>
              <p className="text-2xl font-bold">
                {initiatives.filter((i) => i.status === 'completed').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">إجمالي المشاركين</p>
              <p className="text-2xl font-bold">
                {initiatives.reduce((sum, i) => sum + i.participants, 0).toLocaleString()}
              </p>
            </div>
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Users className="h-5 w-5 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث عن مبادرة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
                dir="rtl"
              />
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الحالات</SelectItem>
                <SelectItem value="upcoming">قريباً</SelectItem>
                <SelectItem value="active">نشطة</SelectItem>
                <SelectItem value="completed">مكتملة</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Initiatives Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredInitiatives.map((initiative) => (
          <Card key={initiative.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative h-48">
              <img
                src={initiative.image}
                alt={initiative.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 right-2">
                {getStatusBadge(initiative.status)}
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg mb-2">{initiative.title}</h3>
              <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                {initiative.description}
              </p>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>
                    {new Date(initiative.startDate).toLocaleDateString('ar-EG')} -{' '}
                    {new Date(initiative.endDate).toLocaleDateString('ar-EG')}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span>{initiative.participants.toLocaleString()} مشارك</span>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => openEditDialog(initiative)}
                >
                  <Edit className="h-4 w-4 ml-1" />
                  تعديل
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:text-red-700"
                  onClick={() => handleDeleteInitiative(initiative.id)}
                >
                  <Trash2 className="h-4 w-4 ml-1" />
                  حذف
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredInitiatives.length === 0 && (
        <div className="text-center py-12">
          <Sprout className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            لا توجد مبادرات مطابقة
          </h3>
          <p className="text-gray-500">
            جرب تغيير معايير البحث أو قم بإضافة مبادرة جديدة
          </p>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingInitiative} onOpenChange={() => setEditingInitiative(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>تعديل المبادرة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>العنوان</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="عنوان المبادرة"
                className="text-right"
                dir="rtl"
              />
            </div>
            <div>
              <Label>الوصف</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="وصف تفصيلي للمبادرة"
                className="text-right min-h-[100px]"
                dir="rtl"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>تاريخ البدء</Label>
                <Input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                />
              </div>
              <div>
                <Label>تاريخ الانتهاء</Label>
                <Input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>الحالة</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value as Initiative['status'] })}
                >
                  <SelectTrigger className="text-right">
                    <SelectValue placeholder="اختر الحالة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upcoming">قريباً</SelectItem>
                    <SelectItem value="active">نشطة</SelectItem>
                    <SelectItem value="completed">مكتملة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>عدد المشاركين</Label>
                <Input
                  type="number"
                  value={formData.participants}
                  onChange={(e) => setFormData({ ...formData, participants: parseInt(e.target.value) })}
                  placeholder="0"
                />
              </div>
            </div>
            <div>
              <Label>رابط الصورة</Label>
              <Input
                value={formData.image}
                onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                placeholder="https://example.com/image.jpg"
              />
            </div>
            <Button
              onClick={handleEditInitiative}
              disabled={!formData.title || !formData.description}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              حفظ التغييرات
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
