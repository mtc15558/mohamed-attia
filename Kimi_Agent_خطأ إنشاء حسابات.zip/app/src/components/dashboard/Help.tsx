import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  HelpCircle,
  Search,
  MessageCircle,
  Phone,
  Mail,
  BookOpen,
  Video,
  FileText,
  ExternalLink,
} from 'lucide-react';

const faqs = [
  {
    question: 'كيف يمكنني التسجيل في المنصة؟',
    answer:
      'يمكنك التسجيل في المنصة بالنقر على زر "تسجيل" في الصفحة الرئيسية، ثم إدخال بياناتك الشخصية واختيار نوع الحساب (مزارع، مستثمر، طالب).',
  },
  {
    question: 'ما هي أنواع الحسابات المتاحة؟',
    answer:
      'المنصة توفر أربعة أنواع من الحسابات: مدير النظام، مزارع، مستثمر، وطالب. كل نوع له صلاحيات وميزات خاصة تناسب احتياجاته.',
  },
  {
    question: 'كيف يمكنني إضافة مشروع زراعي؟',
    answer:
      'يمكنك إضافة مشروع زراعي من خلال الذهاب إلى قسم "المشروعات" والنقر على زر "إضافة مشروع"، ثم ملء البيانات المطلوبة مثل عنوان المشروع والموقع والتكلفة المتوقعة.',
  },
  {
    question: 'ما هو نظام دعم القرار الزراعي؟',
    answer:
      'نظام دعم القرار هو أداة ذكية تساعدك في اختيار أفضل المحاصيل لزراعتها بناءً على نوع التربة والمساحة وكمية المياه المتاحة لديك.',
  },
  {
    question: 'كيف يمكنني الاستفادة من الخريطة الزراعية؟',
    answer:
      'الخريطة الزراعية تتيح لك استكشاف المشروعات الزراعية في مختلف المحافظات، معرفة المناطق الزراعية الرئيسية، والاطلاع على فرص الاستثمار المتاحة.',
  },
  {
    question: 'هل يمكنني تصدير التقارير والإحصائيات؟',
    answer:
      'نعم، يمكنك تصدير التقارير والإحصائيات بصيغ PDF أو Excel من خلال الذهاب إلى قسم "الإحصائيات" واختيار نوع التصدير المطلوب.',
  },
  {
    question: 'كيف يمكنني تقديم شكوى أو مقترح؟',
    answer:
      'يمكنك تقديم شكوى أو مقترح من خلال الذهاب إلى قسم "الشكاوى والملاحظات" والنقر على زر "شكوى جديدة"، ثم كتابة تفاصيل الشكوى وإرسالها.',
  },
  {
    question: 'ما هي مصادر المعلومات في المكتبة التعليمية؟',
    answer:
      'المكتبة التعليمية تحتوي على مقالات وفيديوهات وملفات PDF في مجالات الزراعة المختلفة مثل المحاصيل والري والتربة والاستثمار الزراعي.',
  },
];

const contactMethods = [
  {
    icon: Phone,
    title: 'الهاتف',
    value: '19019',
    description: 'متاح من الساعة 8 صباحاً حتى 8 مساءً',
    color: 'bg-green-100 text-green-600',
  },
  {
    icon: Mail,
    title: 'البريد الإلكتروني',
    value: 'support@agri.eg',
    description: 'نرد على جميع الاستفسارات في خلال 24 ساعة',
    color: 'bg-blue-100 text-blue-600',
  },
  {
    icon: MessageCircle,
    title: 'الدردشة المباشرة',
    value: 'دردشة الآن',
    description: 'متاح خلال أوقات العمل الرسمية',
    color: 'bg-purple-100 text-purple-600',
  },
];

const resources = [
  {
    icon: BookOpen,
    title: 'دليل المستخدم',
    description: 'دليل شامل لاستخدام المنصة',
    link: '#',
  },
  {
    icon: Video,
    title: 'فيديوهات تعليمية',
    description: 'شروحات مصورة للميزات المختلفة',
    link: '#',
  },
  {
    icon: FileText,
    title: 'الأسئلة الشائعة',
    description: 'إجابات على أكثر الأسئلة شيوعاً',
    link: '#',
  },
  {
    icon: ExternalLink,
    title: 'المدونة',
    description: 'آخر الأخبار والمقالات الزراعية',
    link: '#',
  },
];

export function Help() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredFaqs = faqs.filter(
    (faq) =>
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">مركز المساعدة</h2>
        <p className="text-gray-500">كيف يمكننا مساعدتك اليوم؟</p>
      </div>

      {/* Search */}
      <div className="max-w-2xl mx-auto">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            placeholder="البحث في الأسئلة الشائعة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-12 py-6 text-lg text-right"
            dir="rtl"
          />
        </div>
      </div>

      {/* Contact Methods */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {contactMethods.map((method, index) => {
          const Icon = method.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6 text-center">
                <div className={`w-14 h-14 ${method.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="h-7 w-7" />
                </div>
                <h3 className="font-bold text-lg mb-1">{method.title}</h3>
                <p className="text-green-600 font-medium mb-2">{method.value}</p>
                <p className="text-sm text-gray-500">{method.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* FAQ Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5" />
            الأسئلة الشائعة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {filteredFaqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-right hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-right text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          {filteredFaqs.length === 0 && (
            <div className="text-center py-8">
              <HelpCircle className="h-12 w-12 mx-auto text-gray-300 mb-3" />
              <p className="text-gray-500">لا توجد نتائج مطابقة لبحثك</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resources */}
      <div>
        <h3 className="text-xl font-bold mb-4">مصادر مفيدة</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {resources.map((resource, index) => {
            const Icon = resource.icon;
            return (
              <a
                key={index}
                href={resource.link}
                className="flex items-start gap-3 p-4 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
              >
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-medium">{resource.title}</h4>
                  <p className="text-sm text-gray-500">{resource.description}</p>
                </div>
              </a>
            );
          })}
        </div>
      </div>

      {/* Feedback CTA */}
      <Card className="bg-gradient-to-br from-green-600 to-green-800 text-white">
        <CardContent className="p-8 text-center">
          <h3 className="text-2xl font-bold mb-2">لم تجد ما تبحث عنه؟</h3>
          <p className="text-green-100 mb-6">
            فريق الدعم جاهز لمساعدتك في أي وقت. تواصل معنا وسنرد عليك في أقرب وقت.
          </p>
          <Button variant="secondary" size="lg">
            <MessageCircle className="h-5 w-5 ml-2" />
            تواصل معنا
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
