import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

import {
  Sprout,
  Users,
  Briefcase,
  TrendingUp,
  Droplets,
  Sun,
  Wind,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Crop, Project, User, Statistic } from '@/types';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['#16a34a', '#22c55e', '#4ade80', '#86efac', '#bbf7d0'];

export function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalCrops: 0,
    totalProjects: 0,
    totalUsers: 0,
    activeProjects: 0,
  });
  const [cropStats, setCropStats] = useState<any[]>([]);
  const [productionData, setProductionData] = useState<any[]>([]);
  const [recentProjects, setRecentProjects] = useState<Project[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [crops, projects, users, statistics] = await Promise.all([
          api.get<Crop[]>('/crops'),
          api.get<Project[]>('/projects'),
          api.get<User[]>('/users'),
          api.get<Statistic[]>('/statistics'),
        ]);

        setStats({
          totalCrops: crops.length,
          totalProjects: projects.length,
          totalUsers: users.length,
          activeProjects: projects.filter(p => p.status === 'active').length,
        });

        // Crop distribution data
        const cropData = crops.slice(0, 5).map((crop, index) => ({
          name: crop.name,
          value: crop.avgYield,
          color: COLORS[index % COLORS.length],
        }));
        setCropStats(cropData);

        // Production data by year
        const prodData = statistics
          .filter(s => s.cropId === 1)
          .map(s => ({
            year: s.year,
            production: s.production,
            export: s.export,
          }));
        setProductionData(prodData);

        setRecentProjects(projects.slice(0, 3));
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      }
    };

    fetchData();
  }, []);

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin':
        return 'مدير النظام';
      case 'farmer':
        return 'مزارع';
      case 'investor':
        return 'مستثمر';
      case 'student':
        return 'طالب';
      default:
        return role;
    }
  };

  const getWelcomeMessage = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'صباح الخير';
    if (hour < 18) return 'مساء الخير';
    return 'مساء الخير';
  };

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-br from-green-600 to-green-800 rounded-2xl p-6 text-white">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold mb-2">
              {getWelcomeMessage()}، {user?.name}!
            </h2>
            <p className="text-green-100">
              مرحباً بك في منصة مصر الزراعية الذكية
            </p>
            <div className="flex items-center gap-2 mt-3">
              <Badge variant="secondary" className="bg-white/20 text-white">
                {getRoleLabel(user?.role || '')}
              </Badge>
              <span className="text-sm text-green-100">
                {new Date().toLocaleDateString('ar-EG', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="bg-white/10 rounded-lg p-3 text-center">
              <Sun className="h-6 w-6 mx-auto mb-1" />
              <p className="text-sm">28°C</p>
            </div>
            <div className="bg-white/10 rounded-lg p-3 text-center">
              <Droplets className="h-6 w-6 mx-auto mb-1" />
              <p className="text-sm">45%</p>
            </div>
            <div className="bg-white/10 rounded-lg p-3 text-center">
              <Wind className="h-6 w-6 mx-auto mb-1" />
              <p className="text-sm">12 km/h</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">إجمالي المحاصيل</p>
                <p className="text-2xl font-bold">{stats.totalCrops}</p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <ArrowUpRight className="h-4 w-4" />
                  <span>+12%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Sprout className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">المشروعات</p>
                <p className="text-2xl font-bold">{stats.totalProjects}</p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <ArrowUpRight className="h-4 w-4" />
                  <span>+8%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Briefcase className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">المستخدمين</p>
                <p className="text-2xl font-bold">{stats.totalUsers}</p>
                <div className="flex items-center gap-1 text-red-500 text-sm mt-1">
                  <ArrowDownRight className="h-4 w-4" />
                  <span>-2%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">المشروعات النشطة</p>
                <p className="text-2xl font-bold">{stats.activeProjects}</p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <ArrowUpRight className="h-4 w-4" />
                  <span>+15%</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>إنتاج القمح (مليون طن)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={productionData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="production"
                  stroke="#16a34a"
                  strokeWidth={2}
                  name="الإنتاج"
                />
                <Line
                  type="monotone"
                  dataKey="export"
                  stroke="#22c55e"
                  strokeWidth={2}
                  name="الصادرات"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توزيع المحاصيل</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={cropStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {cropStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {cropStats.map((crop, index) => (
                <div key={index} className="flex items-center gap-1">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: crop.color }}
                  />
                  <span className="text-sm">{crop.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Projects */}
      <Card>
        <CardHeader>
          <CardTitle>أحدث المشروعات</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recentProjects.map((project) => (
              <div
                key={project.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-32 object-cover rounded-lg mb-3"
                />
                <h3 className="font-semibold text-lg mb-1">{project.title}</h3>
                <p className="text-sm text-gray-500 mb-2">{project.location}</p>
                <div className="flex items-center justify-between">
                  <Badge variant={project.status === 'active' ? 'default' : 'secondary'}>
                    {project.status === 'active' ? 'نشط' : 'معلق'}
                  </Badge>
                  <span className="text-sm text-green-600 font-medium">
                    {project.investmentCost.toLocaleString()} ج.م
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'إضافة محصول', icon: Sprout, color: 'bg-green-100 text-green-600' },
          { label: 'مشروع جديد', icon: Briefcase, color: 'bg-blue-100 text-blue-600' },
          { label: 'تقرير إحصائي', icon: TrendingUp, color: 'bg-purple-100 text-purple-600' },
          { label: 'استشارة زراعية', icon: Calendar, color: 'bg-orange-100 text-orange-600' },
        ].map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              className="flex flex-col items-center gap-2 p-4 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center`}>
                <Icon className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium">{action.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
