import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Lightbulb,
  Sprout,
  Droplets,
  Sun,
  MapPin,
  TrendingUp,
  Calculator,
  CheckCircle,
  Info,
  RotateCcw,
} from 'lucide-react';
import type { CropRecommendation } from '@/types';

// Crop database for recommendations
const cropDatabase = [
  {
    id: 1,
    name: 'القمح',
    soilTypes: ['طيني', 'طيني رملي', 'رملي طيني'],
    waterNeeds: 'متوسطة',
    season: 'الشتاء',
    minArea: 1,
    avgYield: 7.5,
    yieldUnit: 'طن/فدان',
    pricePerTon: 12000,
    suitability: {
      'طيني': 95,
      'طيني رملي': 90,
      'رملي طيني': 85,
      'رملي': 60,
    },
  },
  {
    id: 2,
    name: 'الأرز',
    soilTypes: ['طيني'],
    waterNeeds: 'عالية',
    season: 'الصيف',
    minArea: 1,
    avgYield: 9.2,
    yieldUnit: 'طن/فدان',
    pricePerTon: 15000,
    suitability: {
      'طيني': 100,
      'طيني رملي': 70,
      'رملي طيني': 50,
      'رملي': 20,
    },
  },
  {
    id: 3,
    name: 'الذرة',
    soilTypes: ['رملي طيني', 'طيني رملي', 'رملي'],
    waterNeeds: 'متوسطة',
    season: 'الصيف',
    minArea: 1,
    avgYield: 8.0,
    yieldUnit: 'طن/فدان',
    pricePerTon: 8000,
    suitability: {
      'رملي طيني': 95,
      'طيني رملي': 90,
      'رملي': 85,
      'طيني': 75,
    },
  },
  {
    id: 4,
    name: 'القطن',
    soilTypes: ['طيني', 'طيني رملي'],
    waterNeeds: 'متوسطة',
    season: 'الصيف',
    minArea: 5,
    avgYield: 2.5,
    yieldUnit: 'قنطار/فدان',
    pricePerTon: 35000,
    suitability: {
      'طيني': 95,
      'طيني رملي': 90,
      'رملي طيني': 70,
      'رملي': 50,
    },
  },
  {
    id: 5,
    name: 'قصب السكر',
    soilTypes: ['طيني غني', 'طيني'],
    waterNeeds: 'عالية',
    season: 'الصيف',
    minArea: 10,
    avgYield: 45,
    yieldUnit: 'طن/فدان',
    pricePerTon: 900,
    suitability: {
      'طيني غني': 100,
      'طيني': 90,
      'طيني رملي': 70,
      'رملي طيني': 50,
    },
  },
  {
    id: 6,
    name: 'البطاطس',
    soilTypes: ['رملي خفيف', 'رملي طيني'],
    waterNeeds: 'متوسطة',
    season: 'الشتاء',
    minArea: 1,
    avgYield: 20,
    yieldUnit: 'طن/فدان',
    pricePerTon: 6000,
    suitability: {
      'رملي خفيف': 100,
      'رملي طيني': 85,
      'رملي': 80,
      'طيني رملي': 70,
    },
  },
  {
    id: 7,
    name: 'الطماطم',
    soilTypes: ['طيني رملي', 'رملي طيني', 'طيني'],
    waterNeeds: 'متوسطة',
    season: 'طوال العام',
    minArea: 1,
    avgYield: 25,
    yieldUnit: 'طن/فدان',
    pricePerTon: 4000,
    suitability: {
      'طيني رملي': 95,
      'رملي طيني': 90,
      'طيني': 85,
      'رملي': 75,
    },
  },
  {
    id: 8,
    name: 'الفول السوداني',
    soilTypes: ['رملي', 'رملي طيني'],
    waterNeeds: 'منخفضة',
    season: 'الصيف',
    minArea: 2,
    avgYield: 1.8,
    yieldUnit: 'طن/فدان',
    pricePerTon: 25000,
    suitability: {
      'رملي': 95,
      'رملي طيني': 90,
      'طيني رملي': 75,
      'طيني': 60,
    },
  },
];

export function DecisionSupport() {
  const [soilType, setSoilType] = useState('');
  const [area, setArea] = useState('');
  const [waterAmount, setWaterAmount] = useState('');
  const [location, setLocation] = useState('');
  const [season, setSeason] = useState('');
  const [recommendations, setRecommendations] = useState<CropRecommendation[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [loading, setLoading] = useState(false);

  const calculateRecommendations = () => {
    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const areaNum = parseFloat(area) || 1;
      const waterNum = parseFloat(waterAmount) || 5000;
      
      const results = cropDatabase
        .map((crop) => {
          // Calculate suitability score
          let suitability = crop.suitability[soilType as keyof typeof crop.suitability] || 50;
          
          // Adjust based on water availability
          const waterFactor = waterNum / (crop.waterNeeds === 'عالية' ? 10000 : crop.waterNeeds === 'متوسطة' ? 7000 : 4000);
          suitability *= Math.min(waterFactor, 1.2);
          
          // Adjust based on area
          if (areaNum < crop.minArea) {
            suitability *= 0.7;
          }
          
          // Adjust based on season
          if (season && crop.season !== 'طوال العام' && crop.season !== season) {
            suitability *= 0.5;
          }
          
          suitability = Math.min(Math.round(suitability), 100);
          
          const expectedYield = crop.avgYield * areaNum * (suitability / 100);
          const expectedRevenue = expectedYield * crop.pricePerTon;
          
          return {
            crop: {
              id: crop.id,
              name: crop.name,
              soilType: crop.soilTypes.join('، '),
              waterNeeds: crop.waterNeeds,
              season: crop.season,
              avgYield: crop.avgYield,
              yieldUnit: crop.yieldUnit,
              commonProblems: [],
              description: '',
              region: '',
              price: crop.pricePerTon,
              currency: 'جنيه/طن',
              scientificName: '',
              image: `https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600`,
            },
            expectedYield,
            expectedRevenue,
            suitability,
          };
        })
        .sort((a, b) => b.suitability - a.suitability)
        .slice(0, 5);
      
      setRecommendations(results);
      setShowResults(true);
      setLoading(false);
    }, 1500);
  };

  const resetForm = () => {
    setSoilType('');
    setArea('');
    setWaterAmount('');
    setLocation('');
    setSeason('');
    setShowResults(false);
    setRecommendations([]);
  };

  const getSuitabilityColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  const getSuitabilityLabel = (score: number) => {
    if (score >= 80) return 'مناسب جداً';
    if (score >= 60) return 'مناسب';
    if (score >= 40) return 'مقبول';
    return 'غير مناسب';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-green-600 to-green-800 rounded-2xl p-6 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
            <Lightbulb className="h-8 w-8" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">نظام دعم القرار الزراعي</h2>
            <p className="text-green-100">
              أدخل بيانات مزرعتك واحصل على توصيات مخصصة لأفضل المحاصيل
            </p>
          </div>
        </div>
      </div>

      {/* Input Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            بيانات المزرعة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="soil">نوع التربة</Label>
              <Select value={soilType} onValueChange={setSoilType}>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="اختر نوع التربة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="طيني">طيني</SelectItem>
                  <SelectItem value="طيني رملي">طيني رملي</SelectItem>
                  <SelectItem value="رملي طيني">رملي طيني</SelectItem>
                  <SelectItem value="رملي">رملي</SelectItem>
                  <SelectItem value="رملي خفيف">رملي خفيف</SelectItem>
                  <SelectItem value="طيني غني">طيني غني</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="area">المساحة (فدان)</Label>
              <Input
                id="area"
                type="number"
                placeholder="مثال: 10"
                value={area}
                onChange={(e) => setArea(e.target.value)}
                className="text-right"
                dir="rtl"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="water">كمية المياه المتاحة (م³/الموسم)</Label>
              <Input
                id="water"
                type="number"
                placeholder="مثال: 5000"
                value={waterAmount}
                onChange={(e) => setWaterAmount(e.target.value)}
                className="text-right"
                dir="rtl"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">الموقع / المحافظة</Label>
              <Select value={location} onValueChange={setLocation}>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="اختر المحافظة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="القاهرة">القاهرة</SelectItem>
                  <SelectItem value="الجيزة">الجيزة</SelectItem>
                  <SelectItem value="الدقهلية">الدقهلية</SelectItem>
                  <SelectItem value="الشرقية">الشرقية</SelectItem>
                  <SelectItem value="المنوفية">المنوفية</SelectItem>
                  <SelectItem value="الغربية">الغربية</SelectItem>
                  <SelectItem value="كفر الشيخ">كفر الشيخ</SelectItem>
                  <SelectItem value="البحيرة">البحيرة</SelectItem>
                  <SelectItem value="الإسماعيلية">الإسماعيلية</SelectItem>
                  <SelectItem value="المنيا">المنيا</SelectItem>
                  <SelectItem value="أسيوط">أسيوط</SelectItem>
                  <SelectItem value="سوهاج">سوهاج</SelectItem>
                  <SelectItem value="قنا">قنا</SelectItem>
                  <SelectItem value="أسوان">أسوان</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="season">الموسم الزراعي</Label>
              <Select value={season} onValueChange={setSeason}>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="اختر الموسم (اختياري)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="الصيف">الصيف</SelectItem>
                  <SelectItem value="الشتاء">الشتاء</SelectItem>
                  <SelectItem value="طوال العام">طوال العام</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <Button
              onClick={calculateRecommendations}
              disabled={!soilType || !area || loading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white ml-2" />
                  جاري التحليل...
                </>
              ) : (
                <>
                  <Lightbulb className="h-4 w-4 ml-2" />
                  احصل على التوصيات
                </>
              )}
            </Button>
            <Button variant="outline" onClick={resetForm}>
              <RotateCcw className="h-4 w-4 ml-2" />
              إعادة
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {showResults && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold">التوصيات المقترحة</h3>
            <Badge variant="outline" className="text-sm">
              {recommendations.length} محصول
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recommendations.map((rec, index) => (
              <Card
                key={rec.crop.id}
                className={`overflow-hidden ${
                  index === 0 ? 'ring-2 ring-green-500' : ''
                }`}
              >
                {index === 0 && (
                  <div className="bg-green-500 text-white text-center py-1 text-sm font-medium">
                    <CheckCircle className="h-4 w-4 inline ml-1" />
                    التوصية الأولى
                  </div>
                )}
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-bold text-lg">{rec.crop.name}</h4>
                    <Badge className={getSuitabilityColor(rec.suitability)}>
                      {rec.suitability}%
                    </Badge>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>نسبة الملاءمة</span>
                      <span>{getSuitabilityLabel(rec.suitability)}</span>
                    </div>
                    <Progress value={rec.suitability} className="h-2" />
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">الإنتاج المتوقع:</span>
                      <span className="font-semibold">
                        {rec.expectedYield.toFixed(1)} {rec.crop.yieldUnit}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">العائد المتوقع:</span>
                      <span className="font-semibold text-green-600">
                        {rec.expectedRevenue.toLocaleString()} ج.م
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">احتياجات المياه:</span>
                      <span>{rec.crop.waterNeeds}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">الموسم:</span>
                      <span>{rec.crop.season}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-100">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Info className="h-4 w-4" />
                      <span>أنسب تربة: {rec.crop.soilType}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Summary Card */}
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-2">ملخص التحليل</h4>
                  <p className="text-gray-600 mb-3">
                    بناءً على بيانات مزرعتك، نوصي بزراعة{' '}
                    <strong>{recommendations[0]?.crop.name}</strong> كأفضل خيار
                    لتحقيق أقصى عائد ممكن.
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white p-3 rounded-lg text-center">
                      <p className="text-2xl font-bold text-green-600">
                        {recommendations[0]?.expectedRevenue.toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-500">العائد المتوقع (ج.م)</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg text-center">
                      <p className="text-2xl font-bold text-blue-600">
                        {recommendations[0]?.expectedYield.toFixed(1)}
                      </p>
                      <p className="text-sm text-gray-500">الإنتاج المتوقع</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg text-center">
                      <p className="text-2xl font-bold text-purple-600">
                        {recommendations[0]?.suitability}%
                      </p>
                      <p className="text-sm text-gray-500">نسبة الملاءمة</p>
                    </div>
                    <div className="bg-white p-3 rounded-lg text-center">
                      <p className="text-2xl font-bold text-orange-600">
                        {area}
                      </p>
                      <p className="text-sm text-gray-500">المساحة (فدان)</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tips Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-5 w-5" />
            نصائح زراعية
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Droplets className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium">إدارة المياه</h4>
                <p className="text-sm text-gray-600">
                  استخدم نظم الري الحديثة لتوفير المياه وزيادة الإنتاجية
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Sun className="h-5 w-5 text-yellow-600" />
              </div>
              <div>
                <h4 className="font-medium">اختيار التوقيت</h4>
                <p className="text-sm text-gray-600">
                  اختر الوقت المناسب للزراعة حسب نوع المحصول والموسم
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Sprout className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h4 className="font-medium">نوعية البذور</h4>
                <p className="text-sm text-gray-600">
                  استخدم بذور معتمدة ومجربة لضمان أفضل نتائج
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <h4 className="font-medium">دراسة التربة</h4>
                <p className="text-sm text-gray-600">
                  قم بتحليل التربة دورياً لمعرفة احتياجاتها من الأسمدة
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
