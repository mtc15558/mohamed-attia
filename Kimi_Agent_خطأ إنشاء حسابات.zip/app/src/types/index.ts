export interface User {
  id: number;
  name: string;
  email: string;
  password?: string;
  role: 'admin' | 'farmer' | 'investor' | 'student';
  phone: string;
  avatar?: string;
  createdAt: string;
  isActive: boolean;
  location?: string;
  farmSize?: number;
  company?: string;
  university?: string;
}

export interface Crop {
  id: number;
  name: string;
  scientificName: string;
  image: string;
  soilType: string;
  waterNeeds: string;
  season: string;
  avgYield: number;
  yieldUnit: string;
  commonProblems: string[];
  description: string;
  region: string;
  price: number;
  currency: string;
}

export interface Project {
  id: number;
  title: string;
  location: string;
  governorate: string;
  cropType: string;
  investmentCost: number;
  expectedReturn: number;
  duration: string;
  status: 'active' | 'pending' | 'completed' | 'rejected';
  description: string;
  image: string;
  ownerId: number;
  rating: number;
  reviews: number;
  coordinates: [number, number];
}

export interface Statistic {
  id: number;
  year: number;
  cropId: number;
  production: number;
  unit: string;
  export: number;
  selfSufficiency: number;
}

export interface Article {
  id: number;
  title: string;
  content: string;
  category: string;
  author: string;
  image: string;
  createdAt: string;
  views: number;
  type: 'article' | 'video' | 'pdf';
}

export interface Feedback {
  id: number;
  userId: number;
  title: string;
  content: string;
  status: 'pending' | 'resolved' | 'in-progress';
  createdAt: string;
  response?: string;
}

export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  type: 'project' | 'comment' | 'update' | 'system';
  read: boolean;
  createdAt: string;
}

export interface Initiative {
  id: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'completed' | 'upcoming';
  image: string;
  participants: number;
}

export interface Region {
  id: number;
  name: string;
  governorates: string[];
  mainCrops: string[];
  coordinates: [number, number];
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface CropRecommendation {
  crop: Crop;
  expectedYield: number;
  expectedRevenue: number;
  suitability: number;
}
