// Types for Agricultural Sector Website

export interface Initiative {
  id: number;
  title: string;
  description: string;
  category: string;
  impact: string;
  image: string;
  date: string;
  location: string;
  beneficiaries: number;
  budget: string;
  status: 'active' | 'completed' | 'planned';
  rating: number;
  reviews: Review[];
}

export interface Review {
  id: number;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Article {
  id: number;
  title: string;
  content: string;
  excerpt: string;
  image: string;
  author: string;
  date: string;
  category: string;
  tags: string[];
  views: number;
}

export interface Statistic {
  id: number;
  title: string;
  value: string;
  unit: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  year: number;
  category: string;
  icon: string;
}

export interface Report {
  id: number;
  title: string;
  type: string;
  year: number;
  quarter: string;
  fileUrl: string;
  size: string;
  date: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'user';
  avatar?: string;
}

export interface Notification {
  id: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning';
  date: string;
  read: boolean;
}

export interface CropData {
  id: number;
  name: string;
  production: number;
  area: number;
  yield: number;
  year: number;
  region: string;
}

export interface AgriculturalSector {
  id: number;
  name: string;
  description: string;
  contribution: number;
  employment: number;
  growth: number;
  image: string;
}
