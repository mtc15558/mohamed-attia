import { useState } from 'react';
import { 
  LayoutDashboard, Plus, Edit2, Trash2, FileText, 
  BarChart3, Settings, LogOut, Bell, CheckCircle,
  Wheat
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { initiatives, articles, statistics, notifications, categories } from '@/data/mockData';

interface AdminProps {
  onLogout: () => void;
}

export default function Admin({ onLogout }: AdminProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [dialogType, setDialogType] = useState<'initiative' | 'article' | ''>('');

  // Stats for dashboard
  const stats = {
    totalInitiatives: initiatives.length,
    totalArticles: articles.length,
    totalStats: statistics.length,
    totalViews: articles.reduce((acc, article) => acc + article.views, 0),
    activeInitiatives: initiatives.filter(i => i.status === 'active').length,
    pendingNotifications: notifications.filter(n => !n.read).length
  };

  const handleAdd = (type: 'initiative' | 'article') => {
    setDialogType(type);
    setShowAddDialog(true);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Admin Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <LayoutDashboard className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">لوحة التحكم</span>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {stats.pendingNotifications > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500">
                    {stats.pendingNotifications}
                  </Badge>
                )}
              </Button>
              <Button variant="ghost" onClick={onLogout}>
                <LogOut className="h-5 w-5 ml-2" />
                خروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          {/* Navigation Tabs */}
          <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">الرئيسية</span>
            </TabsTrigger>
            <TabsTrigger value="initiatives" className="flex items-center gap-2">
              <Wheat className="h-4 w-4" />
              <span className="hidden sm:inline">المبادرات</span>
            </TabsTrigger>
            <TabsTrigger value="articles" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">المقالات</span>
            </TabsTrigger>
            <TabsTrigger value="statistics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">الإحصائيات</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">الإعدادات</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-500 text-sm">إجمالي المبادرات</p>
                      <p className="text-3xl font-bold">{stats.totalInitiatives}</p>
                    </div>
                    <div className="bg-green-100 p-3 rounded-xl">
                      <Wheat className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Badge className="bg-green-100 text-green-800">
                      {stats.activeInitiatives} نشطة
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-500 text-sm">إجمالي المقالات</p>
                      <p className="text-3xl font-bold">{stats.totalArticles}</p>
                    </div>
                    <div className="bg-blue-100 p-3 rounded-xl">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Badge className="bg-blue-100 text-blue-800">
                      {stats.totalViews.toLocaleString()} مشاهدة
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-500 text-sm">الإحصائيات</p>
                      <p className="text-3xl font-bold">{stats.totalStats}</p>
                    </div>
                    <div className="bg-amber-100 p-3 rounded-xl">
                      <BarChart3 className="h-6 w-6 text-amber-600" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Badge className="bg-amber-100 text-amber-800">
                      محدثة
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-500 text-sm">الإشعارات</p>
                      <p className="text-3xl font-bold">{stats.pendingNotifications}</p>
                    </div>
                    <div className="bg-red-100 p-3 rounded-xl">
                      <Bell className="h-6 w-6 text-red-600" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Badge className="bg-red-100 text-red-800">
                      غير مقروءة
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>آخر المبادرات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {initiatives.slice(0, 5).map((initiative) => (
                      <div key={initiative.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium line-clamp-1">{initiative.title}</p>
                          <p className="text-sm text-gray-500">{initiative.date}</p>
                        </div>
                        <Badge variant={initiative.status === 'active' ? 'default' : 'secondary'}>
                          {initiative.status === 'active' ? 'نشط' : initiative.status === 'completed' ? 'مكتمل' : 'مخطط'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>آخر المقالات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {articles.slice(0, 5).map((article) => (
                      <div key={article.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium line-clamp-1">{article.title}</p>
                          <p className="text-sm text-gray-500">{article.views.toLocaleString()} مشاهدة</p>
                        </div>
                        <Badge variant="outline">{article.category}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Initiatives Tab */}
          <TabsContent value="initiatives" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة المبادرات</h2>
              <Button onClick={() => handleAdd('initiative')}>
                <Plus className="h-4 w-4 ml-2" />
                إضافة مبادرة
              </Button>
            </div>

            <Card>
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-3 px-4">المبادرة</th>
                        <th className="text-right py-3 px-4">التصنيف</th>
                        <th className="text-right py-3 px-4">الحالة</th>
                        <th className="text-right py-3 px-4">المستفيدون</th>
                        <th className="text-right py-3 px-4">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {initiatives.map((initiative) => (
                        <tr key={initiative.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <img src={initiative.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                              <span className="font-medium line-clamp-1">{initiative.title}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">{initiative.category}</td>
                          <td className="py-3 px-4">
                            <Badge className={`
                              ${initiative.status === 'active' ? 'bg-green-100 text-green-800' : 
                                initiative.status === 'completed' ? 'bg-blue-100 text-blue-800' : 
                                'bg-amber-100 text-amber-800'}
                            `}>
                              {initiative.status === 'active' ? 'نشط' : 
                               initiative.status === 'completed' ? 'مكتمل' : 'مخطط'}
                            </Badge>
                          </td>
                          <td className="py-3 px-4">{initiative.beneficiaries.toLocaleString()}</td>
                          <td className="py-3 px-4">
                            <div className="flex gap-2">
                              <Button variant="ghost" size="icon">
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="text-red-600">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Articles Tab */}
          <TabsContent value="articles" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة المقالات</h2>
              <Button onClick={() => handleAdd('article')}>
                <Plus className="h-4 w-4 ml-2" />
                إضافة مقال
              </Button>
            </div>

            <Card>
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-3 px-4">المقال</th>
                        <th className="text-right py-3 px-4">الكاتب</th>
                        <th className="text-right py-3 px-4">التاريخ</th>
                        <th className="text-right py-3 px-4">المشاهدات</th>
                        <th className="text-right py-3 px-4">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {articles.map((article) => (
                        <tr key={article.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <img src={article.image} alt="" className="w-10 h-10 rounded-lg object-cover" />
                              <span className="font-medium line-clamp-1">{article.title}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">{article.author}</td>
                          <td className="py-3 px-4">{article.date}</td>
                          <td className="py-3 px-4">{article.views.toLocaleString()}</td>
                          <td className="py-3 px-4">
                            <div className="flex gap-2">
                              <Button variant="ghost" size="icon">
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="text-red-600">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Statistics Tab */}
          <TabsContent value="statistics" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة الإحصائيات</h2>
              <Button>
                <Plus className="h-4 w-4 ml-2" />
                إضافة إحصائية
              </Button>
            </div>

            <Card>
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-3 px-4">الإحصائية</th>
                        <th className="text-right py-3 px-4">القيمة</th>
                        <th className="text-right py-3 px-4">التغير</th>
                        <th className="text-right py-3 px-4">السنة</th>
                        <th className="text-right py-3 px-4">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {statistics.map((stat) => (
                        <tr key={stat.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{stat.title}</td>
                          <td className="py-3 px-4">{stat.value} {stat.unit}</td>
                          <td className="py-3 px-4">
                            <Badge className={`
                              ${stat.changeType === 'positive' ? 'bg-green-100 text-green-800' : 
                                stat.changeType === 'negative' ? 'bg-red-100 text-red-800' : 
                                'bg-gray-100 text-gray-800'}
                            `}>
                              {stat.change}
                            </Badge>
                          </td>
                          <td className="py-3 px-4">{stat.year}</td>
                          <td className="py-3 px-4">
                            <div className="flex gap-2">
                              <Button variant="ghost" size="icon">
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="text-red-600">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-2xl font-bold">إعدادات الموقع</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>معلومات الموقع</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>اسم الموقع</Label>
                    <Input defaultValue="موقع القطاع الزراعي" />
                  </div>
                  <div>
                    <Label>البريد الإلكتروني</Label>
                    <Input defaultValue="admin@agriculture.gov.eg" />
                  </div>
                  <div>
                    <Label>الوصف</Label>
                    <Textarea defaultValue="موقع إلكتروني لدور القطاع الزراعي في تدعيم التنمية الزراعية" />
                  </div>
                  <Button>حفظ التغييرات</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>إعدادات الإشعارات</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span>إشعارات المبادرات الجديدة</span>
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span>إشعارات التعليقات</span>
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span>إشعارات التحديثات</span>
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <Button variant="outline">تحديث الإعدادات</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {dialogType === 'initiative' ? 'إضافة مبادرة جديدة' : 'إضافة مقال جديد'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>العنوان</Label>
              <Input placeholder="أدخل العنوان" />
            </div>
            {dialogType === 'initiative' ? (
              <>
                <div>
                  <Label>التصنيف</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر التصنيف" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.filter(c => c !== 'الكل').map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>الحالة</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الحالة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">نشط</SelectItem>
                      <SelectItem value="planned">مخطط</SelectItem>
                      <SelectItem value="completed">مكتمل</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            ) : (
              <>
                <div>
                  <Label>الكاتب</Label>
                  <Input placeholder="اسم الكاتب" />
                </div>
                <div>
                  <Label>التصنيف</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر التصنيف" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.filter(c => c !== 'الكل').map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            <div>
              <Label>الوصف</Label>
              <Textarea placeholder="أدخل الوصف" rows={4} />
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setShowAddDialog(false)} className="flex-1">
                حفظ
              </Button>
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                إلغاء
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
