import { useState } from 'react';
import { Search, Filter, MapPin, Users, Calendar, TrendingUp, Star, MessageCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { initiatives, categories } from '@/data/mockData';
import type { Initiative, Review } from '@/types';

export default function Initiatives() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [selectedStatus, setSelectedStatus] = useState('الكل');
  const [selectedInitiative] = useState<Initiative | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewName, setReviewName] = useState('');
  const [reviews, setReviews] = useState<Review[]>([]);

  // Filter initiatives
  const filteredInitiatives = initiatives.filter((initiative) => {
    const matchesSearch = initiative.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         initiative.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'الكل' || initiative.category === selectedCategory;
    const matchesStatus = selectedStatus === 'الكل' || initiative.status === selectedStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleSubmitReview = () => {
    if (selectedInitiative && reviewName && reviewComment) {
      const newReview: Review = {
        id: Date.now(),
        userName: reviewName,
        rating: reviewRating,
        comment: reviewComment,
        date: new Date().toISOString().split('T')[0]
      };
      setReviews([...reviews, newReview]);
      setReviewName('');
      setReviewComment('');
      setReviewRating(5);
      alert('تم إضافة التقييم بنجاح!');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500">نشط</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500">مكتمل</Badge>;
      case 'planned':
        return <Badge className="bg-amber-500">مخطط</Badge>;
      default:
        return <Badge>غير معروف</Badge>;
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">المبادرات الزراعية</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            استعرض المبادرات الزراعية المختلفة وأثرها على التنمية الزراعية، 
            ويمكنك البحث والتصفية حسب النوع والحالة
          </p>
        </div>

        {/* Search & Filter */}
        <div className="bg-white p-6 rounded-2xl shadow-sm mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="بحث في المبادرات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <Filter className="h-4 w-4 ml-2" />
                <SelectValue placeholder="التصنيف" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger>
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="الكل">جميع الحالات</SelectItem>
                <SelectItem value="active">نشط</SelectItem>
                <SelectItem value="completed">مكتمل</SelectItem>
                <SelectItem value="planned">مخطط</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('الكل');
                setSelectedStatus('الكل');
              }}
            >
              إعادة ضبط
            </Button>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <span className="text-gray-600">
            تم العثور على <span className="font-semibold text-gray-900">{filteredInitiatives.length}</span> مبادرة
          </span>
        </div>

        {/* Initiatives Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredInitiatives.map((initiative) => (
            <Dialog key={initiative.id}>
              <DialogTrigger asChild>
                <Card className="overflow-hidden group hover:shadow-xl transition-all cursor-pointer">
                  <div className="h-48 overflow-hidden relative">
                    <img 
                      src={initiative.image} 
                      alt={initiative.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute top-4 right-4">
                      {getStatusBadge(initiative.status)}
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <Badge variant="outline" className="mb-3">{initiative.category}</Badge>
                    <h3 className="text-lg font-semibold mb-2 line-clamp-1">{initiative.title}</h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{initiative.description}</p>
                    
                    <div className="space-y-2 text-sm text-gray-500">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        <span>{initiative.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        <span>{initiative.beneficiaries.toLocaleString()} مستفيد</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4" />
                        <span>{initiative.budget}</span>
                      </div>
                    </div>

                    {initiative.rating > 0 && (
                      <div className="mt-4 pt-4 border-t flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-medium">{initiative.rating}</span>
                        </div>
                        <span className="text-sm text-gray-500">
                          {initiative.reviews.length} تقييم
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </DialogTrigger>
              
              <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-2xl">{initiative.title}</DialogTitle>
                </DialogHeader>
                
                <div className="space-y-6">
                  <img 
                    src={initiative.image} 
                    alt={initiative.title}
                    className="w-full h-64 object-cover rounded-xl"
                  />
                  
                  <div className="flex flex-wrap gap-2">
                    <Badge>{initiative.category}</Badge>
                    {getStatusBadge(initiative.status)}
                  </div>

                  <p className="text-gray-700 leading-relaxed">{initiative.description}</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center gap-2 text-gray-500 mb-1">
                        <MapPin className="h-4 w-4" />
                        <span className="text-sm">الموقع</span>
                      </div>
                      <span className="font-medium">{initiative.location}</span>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center gap-2 text-gray-500 mb-1">
                        <Calendar className="h-4 w-4" />
                        <span className="text-sm">تاريخ البدء</span>
                      </div>
                      <span className="font-medium">{initiative.date}</span>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center gap-2 text-gray-500 mb-1">
                        <Users className="h-4 w-4" />
                        <span className="text-sm">المستفيدون</span>
                      </div>
                      <span className="font-medium">{initiative.beneficiaries.toLocaleString()}</span>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center gap-2 text-gray-500 mb-1">
                        <TrendingUp className="h-4 w-4" />
                        <span className="text-sm">الميزانية</span>
                      </div>
                      <span className="font-medium">{initiative.budget}</span>
                    </div>
                  </div>

                  <div className="bg-green-50 p-4 rounded-xl">
                    <h4 className="font-semibold text-green-800 mb-2">الأثر المتوقع</h4>
                    <p className="text-green-700">{initiative.impact}</p>
                  </div>

                  {/* Reviews Section */}
                  <div className="border-t pt-6">
                    <h4 className="font-semibold text-lg mb-4 flex items-center gap-2">
                      <MessageCircle className="h-5 w-5" />
                      التقييمات والتعليقات
                    </h4>

                    {/* Existing Reviews */}
                    <div className="space-y-4 mb-6">
                      {initiative.reviews.length > 0 ? (
                        initiative.reviews.map((review) => (
                          <div key={review.id} className="bg-gray-50 p-4 rounded-xl">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">{review.userName}</span>
                              <span className="text-sm text-gray-500">{review.date}</span>
                            </div>
                            {renderStars(review.rating)}
                            <p className="text-gray-700 mt-2">{review.comment}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-gray-500 text-center py-4">لا توجد تقييمات بعد</p>
                      )}
                    </div>

                    {/* Add Review Form */}
                    <div className="bg-gray-50 p-4 rounded-xl">
                      <h5 className="font-medium mb-4">أضف تقييمك</h5>
                      <div className="space-y-4">
                        <div>
                          <Label>الاسم</Label>
                          <Input 
                            value={reviewName} 
                            onChange={(e) => setReviewName(e.target.value)}
                            placeholder="أدخل اسمك"
                          />
                        </div>
                        <div>
                          <Label>التقييم</Label>
                          <div className="flex gap-2 mt-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                onClick={() => setReviewRating(star)}
                                className="focus:outline-none"
                              >
                                <Star
                                  className={`h-6 w-6 ${
                                    star <= reviewRating 
                                      ? 'fill-yellow-400 text-yellow-400' 
                                      : 'text-gray-300'
                                  }`}
                                />
                              </button>
                            ))}
                          </div>
                        </div>
                        <div>
                          <Label>التعليق</Label>
                          <Textarea 
                            value={reviewComment}
                            onChange={(e) => setReviewComment(e.target.value)}
                            placeholder="اكتب تعليقك هنا..."
                            rows={3}
                          />
                        </div>
                        <Button onClick={handleSubmitReview} className="w-full">
                          إرسال التقييم
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>

        {filteredInitiatives.length === 0 && (
          <div className="text-center py-16">
            <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد نتائج</h3>
            <p className="text-gray-600">جرب تغيير معايير البحث أو التصفية</p>
          </div>
        )}
      </div>
    </div>
  );
}
