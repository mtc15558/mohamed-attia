import { useState } from 'react';
import { FileText, Download, Calendar, Filter, Search, FileSpreadsheet, FileBarChart } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { reports } from '@/data/mockData';

export default function Reports() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('الكل');
  const [selectedYear, setSelectedYear] = useState('الكل');

  // Filter reports
  const filteredReports = reports.filter((report) => {
    const matchesSearch = report.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'الكل' || report.type === selectedType;
    const matchesYear = selectedYear === 'الكل' || report.year.toString() === selectedYear;
    return matchesSearch && matchesType && matchesYear;
  });

  const getReportIcon = (type: string) => {
    switch (type) {
      case 'ربعي':
        return <FileSpreadsheet className="h-8 w-8 text-blue-600" />;
      case 'سنوي':
        return <FileBarChart className="h-8 w-8 text-green-600" />;
      case 'تنموي':
        return <FileText className="h-8 w-8 text-purple-600" />;
      default:
        return <FileText className="h-8 w-8 text-gray-600" />;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'ربعي':
        return <Badge className="bg-blue-100 text-blue-800">ربعي</Badge>;
      case 'سنوي':
        return <Badge className="bg-green-100 text-green-800">سنوي</Badge>;
      case 'تنموي':
        return <Badge className="bg-purple-100 text-purple-800">تنموي</Badge>;
      default:
        return <Badge>غير معروف</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">التقارير والنشرات</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            تحميل التقارير الدورية والسنوية والنشرات المتعلقة بالقطاع الزراعي المصري، 
            تشمل إحصائيات شاملة وتحليلات مفصلة
          </p>
        </div>

        {/* Search & Filter */}
        <div className="bg-white p-6 rounded-2xl shadow-sm mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="بحث في التقارير..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger>
                <Filter className="h-4 w-4 ml-2" />
                <SelectValue placeholder="نوع التقرير" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="الكل">جميع الأنواع</SelectItem>
                <SelectItem value="ربعي">ربعي</SelectItem>
                <SelectItem value="سنوي">سنوي</SelectItem>
                <SelectItem value="تنموي">تنموي</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger>
                <Calendar className="h-4 w-4 ml-2" />
                <SelectValue placeholder="السنة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="الكل">جميع السنوات</SelectItem>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedType('الكل');
                setSelectedYear('الكل');
              }}
            >
              إعادة ضبط
            </Button>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <span className="text-gray-600">
            تم العثور على <span className="font-semibold text-gray-900">{filteredReports.length}</span> تقرير
          </span>
        </div>

        {/* Reports Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReports.map((report) => (
            <Card key={report.id} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="bg-gray-100 p-3 rounded-xl">
                    {getReportIcon(report.type)}
                  </div>
                  {getTypeBadge(report.type)}
                </div>

                <h3 className="text-lg font-semibold mb-2">{report.title}</h3>
                
                <div className="space-y-2 text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>{report.date}</span>
                  </div>
                  {report.quarter !== '-' && (
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <span>الربع: {report.quarter}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    <span>الحجم: {report.size}</span>
                  </div>
                </div>

                <Button className="w-full" variant="outline">
                  <Download className="h-4 w-4 ml-2" />
                  تحميل التقرير
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredReports.length === 0 && (
          <div className="text-center py-16">
            <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد نتائج</h3>
            <p className="text-gray-600">جرب تغيير معايير البحث أو التصفية</p>
          </div>
        )}

        {/* Additional Info */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <FileSpreadsheet className="h-10 w-10 text-blue-600 mb-4" />
              <h4 className="font-semibold text-lg mb-2">التقارير الربعية</h4>
              <p className="text-gray-600 text-sm">
                تقارير دورية تصدر كل ثلاثة أشهر تتضمن إحصائيات ومؤشرات أداء القطاع الزراعي
              </p>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-6">
              <FileBarChart className="h-10 w-10 text-green-600 mb-4" />
              <h4 className="font-semibold text-lg mb-2">التقارير السنوية</h4>
              <p className="text-gray-600 text-sm">
                تقارير شاملة تصدر في نهاية كل عام تتضمن تحليلاً كاملاً لأداء القطاع الزراعي
              </p>
            </CardContent>
          </Card>

          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="p-6">
              <FileText className="h-10 w-10 text-purple-600 mb-4" />
              <h4 className="font-semibold text-lg mb-2">التقارير التنموية</h4>
              <p className="text-gray-600 text-sm">
                تقارير متخصصة تركز على التنمية المستدامة والمبادرات الزراعية وأثرها
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
