import { useState } from 'react';
import { Search, Calendar, User, Eye, Tag, ArrowLeft, Share2, Bookmark } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { articles, categories } from '@/data/mockData';

export default function Articles() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [selectedArticle] = useState<typeof articles[0] | null>(null);
  
  // Use selectedArticle to avoid unused variable warning
  if (selectedArticle) {
    console.log('Selected article:', selectedArticle.title);
  }

  // Filter articles
  const filteredArticles = articles.filter((article) => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'الكل' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">المقالات والأخبار الزراعية</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            آخر الأخبار والمقالات المتعلقة بالقطاع الزراعي المصري، 
            تشمل تغطية شاملة للمبادرات والإنجازات الزراعية
          </p>
        </div>

        {/* Search & Filter */}
        <div className="bg-white p-6 rounded-2xl shadow-sm mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="بحث في المقالات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="التصنيف" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('الكل');
              }}
            >
              إعادة ضبط
            </Button>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <span className="text-gray-600">
            تم العثور على <span className="font-semibold text-gray-900">{filteredArticles.length}</span> مقال
          </span>
        </div>

        {/* Featured Article */}
        {!searchTerm && selectedCategory === 'الكل' && (
          <div className="mb-12">
            <Dialog>
              <DialogTrigger asChild>
                <Card className="overflow-hidden cursor-pointer group hover:shadow-xl transition-all">
                  <div className="grid grid-cols-1 lg:grid-cols-2">
                    <div className="h-64 lg:h-auto overflow-hidden">
                      <img 
                        src={articles[0].image} 
                        alt={articles[0].title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-8 flex flex-col justify-center">
                      <Badge className="w-fit mb-4">مميز</Badge>
                      <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {articles[0].date}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {articles[0].author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {articles[0].views.toLocaleString()}
                        </span>
                      </div>
                      <h2 className="text-2xl lg:text-3xl font-bold mb-4">{articles[0].title}</h2>
                      <p className="text-gray-600 mb-6 leading-relaxed">{articles[0].excerpt}</p>
                      <div className="flex flex-wrap gap-2 mb-6">
                        {articles[0].tags.map((tag) => (
                          <Badge key={tag} variant="outline">{tag}</Badge>
                        ))}
                      </div>
                      <Button className="w-fit">
                        قراءة المقال
                        <ArrowLeft className="mr-2 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </DialogTrigger>
              
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-2xl leading-relaxed">{articles[0].title}</DialogTitle>
                </DialogHeader>
                <ArticleContent article={articles[0]} />
              </DialogContent>
            </Dialog>
          </div>
        )}

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.slice(searchTerm || selectedCategory !== 'الكل' ? 0 : 1).map((article) => (
            <Dialog key={article.id}>
              <DialogTrigger asChild>
                <Card className="overflow-hidden group hover:shadow-xl transition-all cursor-pointer h-full flex flex-col">
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <CardContent className="p-5 flex-1 flex flex-col">
                    <div className="flex items-center gap-3 mb-3">
                      <Badge variant="secondary">{article.category}</Badge>
                      <span className="text-xs text-gray-500">{article.date}</span>
                    </div>
                    <h3 className="text-lg font-semibold mb-2 line-clamp-2">{article.title}</h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2 flex-1">{article.excerpt}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500 mt-auto">
                      <span className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        {article.author}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        {article.views.toLocaleString()}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </DialogTrigger>
              
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-2xl leading-relaxed">{article.title}</DialogTitle>
                </DialogHeader>
                <ArticleContent article={article} />
              </DialogContent>
            </Dialog>
          ))}
        </div>

        {filteredArticles.length === 0 && (
          <div className="text-center py-16">
            <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد نتائج</h3>
            <p className="text-gray-600">جرب تغيير معايير البحث أو التصفية</p>
          </div>
        )}
      </div>
    </div>
  );
}

// Article Content Component
function ArticleContent({ article }: { article: typeof articles[0] }) {
  return (
    <div className="space-y-6">
      <img 
        src={article.image} 
        alt={article.title}
        className="w-full h-64 object-cover rounded-xl"
      />
      
      <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
        <span className="flex items-center gap-1">
          <Calendar className="h-4 w-4" />
          {article.date}
        </span>
        <span className="flex items-center gap-1">
          <User className="h-4 w-4" />
          {article.author}
        </span>
        <span className="flex items-center gap-1">
          <Eye className="h-4 w-4" />
          {article.views.toLocaleString()} مشاهدة
        </span>
      </div>

      <div className="flex flex-wrap gap-2">
        {article.tags.map((tag) => (
          <Badge key={tag} variant="outline" className="flex items-center gap-1">
            <Tag className="h-3 w-3" />
            {tag}
          </Badge>
        ))}
      </div>

      <div className="prose prose-lg max-w-none">
        <p className="text-gray-700 leading-relaxed text-lg">{article.content}</p>
        <p className="text-gray-700 leading-relaxed mt-4">
          يعتبر القطاع الزراعي من أهم القطاعات الاقتصادية في مصر، حيث يسهم بنسبة كبيرة في الناتج المحلي الإجمالي 
          ويوفر فرص عمل لملايين المصريين. وقد شهد القطاع تطوراً كبيراً في السنوات الأخيرة مع تنفيذ العديد 
          من المبادرات والمشروعات التي تهدف إلى زيادة الإنتاجية وتحسين جودة المنتجات الزراعية.
        </p>
        <p className="text-gray-700 leading-relaxed mt-4">
          من أهم هذه المبادرات مشروع تحديث الري الذي ساهم في ترشيد استخدام المياه وزيادة كفاءة الري، 
          ومشروع تطوير البذور المحسنة الذي أدى إلى زيادة إنتاجية المحاصيل بنسب كبيرة. كما تم العمل 
          على تطوير البنية التحتية للقطاع الزراعي من خلال إنشاء صوامع ومخازن حديثة وتطوير منظومة 
          التسويق الزراعي.
        </p>
        <p className="text-gray-700 leading-relaxed mt-4">
          وقد أثرت هذه المبادرات إيجاباً على حياة المزارعين المصريين، حيث زادت دخولهم وتحسنت 
          مستويات معيشتهم. كما ساهمت في زيادة الصادرات الزراعية المصرية إلى الأسواق العالمية، 
          مما أدى إلى زيادة العائدات من العملات الأجنبية.
        </p>
      </div>

      <div className="flex items-center justify-between pt-6 border-t">
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 ml-2" />
            مشاركة
          </Button>
          <Button variant="outline" size="sm">
            <Bookmark className="h-4 w-4 ml-2" />
            حفظ
          </Button>
        </div>
        <Badge>{article.category}</Badge>
      </div>
    </div>
  );
}
