import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  TrendingUp, Users, Sprout, ArrowLeft, 
  BarChart3, FileText, Newspaper, Target 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { initiatives, articles, statistics, sectors } from '@/data/mockData';

export default function Home() {
  const [activeSector, setActiveSector] = useState(0);

  const featuredInitiatives = initiatives.slice(0, 3);
  const latestArticles = articles.slice(0, 3);
  const featuredStats = statistics.slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-900 via-green-800 to-green-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1920" 
            alt="Agriculture" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="max-w-3xl">
            <Badge className="bg-green-500/30 text-green-100 border-green-400/50 mb-6">
              مشروع تخرج رقم 70
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              موقع إلكتروني لدور القطاع الزراعي
              <span className="block text-green-300">في تدعيم التنمية الزراعية</span>
            </h1>
            <p className="text-xl text-green-100 mb-8 leading-relaxed">
              نقدم لكم منصة شاملة لعرض المبادرات الزراعية والإحصائيات والتقارير 
              التي تدعم التنمية المستدامة في القطاع الزراعي المصري
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="bg-white text-green-900 hover:bg-green-50">
                <Link to="/initiatives">
                  استكشف المبادرات
                  <ArrowLeft className="mr-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Link to="/statistics">
                  عرض الإحصائيات
                </Link>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Stats Bar */}
        <div className="relative bg-green-950/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredStats.map((stat) => (
                <div key={stat.id} className="text-center">
                  <div className="text-3xl lg:text-4xl font-bold text-white mb-1">
                    {stat.value}
                  </div>
                  <div className="text-green-300 text-sm">{stat.title}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">ما يقدمه الموقع</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              منصة متكاملة لعرض جميع المعلومات والبيانات المتعلقة بالقطاع الزراعي
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-green-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors">
                  <Target className="h-8 w-8 text-green-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-2">المبادرات الزراعية</h3>
                <p className="text-gray-600 text-sm mb-4">
                  عرض جميع المبادرات الزراعية وأثرها على التنمية
                </p>
                <Link to="/initiatives" className="text-green-600 text-sm font-medium hover:underline">
                  عرض المبادرات
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors">
                  <BarChart3 className="h-8 w-8 text-blue-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-2">الإحصائيات</h3>
                <p className="text-gray-600 text-sm mb-4">
                  تقارير وإحصائيات عن الإنتاج الزراعي والقطاع
                </p>
                <Link to="/statistics" className="text-blue-600 text-sm font-medium hover:underline">
                  عرض الإحصائيات
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-amber-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-600 transition-colors">
                  <Newspaper className="h-8 w-8 text-amber-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-2">المقالات</h3>
                <p className="text-gray-600 text-sm mb-4">
                  أحدث الأخبار والمقالات الزراعية
                </p>
                <Link to="/articles" className="text-amber-600 text-sm font-medium hover:underline">
                  قراءة المقالات
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="bg-purple-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-600 transition-colors">
                  <FileText className="h-8 w-8 text-purple-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-2">التقارير</h3>
                <p className="text-gray-600 text-sm mb-4">
                  التقارير الدورية والسنوية للقطاع الزراعي
                </p>
                <Link to="/reports" className="text-purple-600 text-sm font-medium hover:underline">
                  تحميل التقارير
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Agricultural Sectors */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">القطاعات الزراعية</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              استعراض القطاعات الزراعية المختلفة ومساهمتها في الاقتصاد
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Sector Tabs */}
            <div className="lg:col-span-1 space-y-2">
              {sectors.map((sector, index) => (
                <button
                  key={sector.id}
                  onClick={() => setActiveSector(index)}
                  className={`w-full text-right p-4 rounded-xl transition-all ${
                    activeSector === index
                      ? 'bg-green-600 text-white shadow-lg'
                      : 'bg-gray-50 text-gray-700 hover:bg-green-50'
                  }`}
                >
                  <div className="font-semibold">{sector.name}</div>
                  <div className={`text-sm ${activeSector === index ? 'text-green-100' : 'text-gray-500'}`}>
                    مساهمة: {sector.contribution}%
                  </div>
                </button>
              ))}
            </div>

            {/* Sector Details */}
            <div className="lg:col-span-2">
              <Card className="overflow-hidden">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={sectors[activeSector].image} 
                    alt={sectors[activeSector].name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold mb-3">{sectors[activeSector].name}</h3>
                  <p className="text-gray-600 mb-6">{sectors[activeSector].description}</p>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-xl">
                      <div className="text-2xl font-bold text-green-600">
                        {sectors[activeSector].contribution}%
                      </div>
                      <div className="text-sm text-gray-600">المساهمة</div>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-xl">
                      <div className="text-2xl font-bold text-blue-600">
                        {sectors[activeSector].employment}%
                      </div>
                      <div className="text-sm text-gray-600">العمالة</div>
                    </div>
                    <div className="text-center p-4 bg-amber-50 rounded-xl">
                      <div className="text-2xl font-bold text-amber-600">
                        +{sectors[activeSector].growth}%
                      </div>
                      <div className="text-sm text-gray-600">النمو</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Initiatives */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">المبادرات المميزة</h2>
              <p className="text-gray-600">أهم المبادرات الزراعية وأثرها على التنمية</p>
            </div>
            <Button asChild variant="outline">
              <Link to="/initiatives">
                عرض الكل
                <ArrowLeft className="mr-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredInitiatives.map((initiative) => (
              <Card key={initiative.id} className="overflow-hidden group hover:shadow-xl transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={initiative.image} 
                    alt={initiative.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <CardContent className="p-5">
                  <Badge className="mb-3" variant="secondary">{initiative.category}</Badge>
                  <h3 className="text-lg font-semibold mb-2 line-clamp-1">{initiative.title}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{initiative.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {initiative.beneficiaries.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      {initiative.budget}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">أحدث المقالات</h2>
              <p className="text-gray-600">آخر الأخبار والمقالات الزراعية</p>
            </div>
            <Button asChild variant="outline">
              <Link to="/articles">
                عرض الكل
                <ArrowLeft className="mr-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestArticles.map((article) => (
              <Card key={article.id} className="overflow-hidden group hover:shadow-xl transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="secondary">{article.category}</Badge>
                    <span className="text-xs text-gray-500">{article.date}</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2 line-clamp-2">{article.title}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{article.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">{article.author}</span>
                    <Link 
                      to={`/articles/${article.id}`} 
                      className="text-green-600 text-sm font-medium hover:underline"
                    >
                      قراءة المزيد
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Sprout className="h-16 w-16 text-green-400 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-4">
            ساهم في تطوير القطاع الزراعي
          </h2>
          <p className="text-green-200 max-w-2xl mx-auto mb-8">
            انضم إلينا في رحلة التنمية الزراعية وتابع آخر المستجدات والمبادرات 
            التي تساهم في بناء مستقبل زراعي مستدام
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="bg-white text-green-900 hover:bg-green-50">
              <Link to="/initiatives">استكشف المبادرات</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              <Link to="/statistics">عرض الإحصائيات</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
