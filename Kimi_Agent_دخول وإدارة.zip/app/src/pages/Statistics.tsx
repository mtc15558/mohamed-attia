import { useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, TrendingDown, Wheat, Droplets, Users, 
  Sprout, BarChart3, PieChart as PieChartIcon, Activity, Target
} from 'lucide-react';
import { statistics, cropData, sectors } from '@/data/mockData';

const COLORS = ['#16a34a', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444', '#10b981', '#f97316', '#6366f1'];

export default function Statistics() {
  const [selectedYear] = useState(2024);
  
  // Use selectedYear to avoid unused variable warning
  if (selectedYear !== 2024) {
    console.log('Selected year:', selectedYear);
  }

  // Prepare data for charts
  const cropProductionData = cropData.map(crop => ({
    name: crop.name,
    production: crop.production / 1000000,
    area: crop.area / 1000,
    yield: crop.yield
  }));

  const sectorContributionData = sectors.map(sector => ({
    name: sector.name,
    value: sector.contribution,
    employment: sector.employment
  }));

  const yearlyGrowthData = [
    { year: 2020, production: 95, exports: 5.2 },
    { year: 2021, production: 102, exports: 6.1 },
    { year: 2022, production: 108, exports: 6.8 },
    { year: 2023, production: 115, exports: 8.1 },
    { year: 2024, production: 120, exports: 9.2 },
  ];

  const waterEfficiencyData = [
    { year: 2020, efficiency: 58 },
    { year: 2021, efficiency: 63 },
    { year: 2022, efficiency: 68 },
    { year: 2023, efficiency: 72 },
    { year: 2024, efficiency: 75 },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">الإحصائيات والتقارير</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            عرض شاملة للإحصائيات والبيانات المتعلقة بالقطاع الزراعي المصري، 
            تشمل الإنتاج والصادرات والمساحات والعمالة
          </p>
        </div>

        {/* Key Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {statistics.slice(0, 4).map((stat) => (
            <Card key={stat.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-gray-500 text-sm mb-1">{stat.title}</p>
                    <p className="text-3xl font-bold text-gray-900">
                      {stat.value} <span className="text-lg font-normal">{stat.unit}</span>
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl ${
                    stat.changeType === 'positive' ? 'bg-green-100' : 
                    stat.changeType === 'negative' ? 'bg-red-100' : 'bg-gray-100'
                  }`}>
                    {stat.changeType === 'positive' ? (
                      <TrendingUp className={`h-6 w-6 ${stat.changeType === 'positive' ? 'text-green-600' : ''}`} />
                    ) : (
                      <TrendingDown className="h-6 w-6 text-red-600" />
                    )}
                  </div>
                </div>
                <div className="mt-4">
                  <Badge className={`
                    ${stat.changeType === 'positive' ? 'bg-green-100 text-green-800' : 
                      stat.changeType === 'negative' ? 'bg-red-100 text-red-800' : 
                      'bg-gray-100 text-gray-800'}
                  `}>
                    {stat.change} من العام السابق
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Tabs */}
        <Tabs defaultValue="production" className="space-y-8">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
            <TabsTrigger value="production" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">الإنتاج</span>
            </TabsTrigger>
            <TabsTrigger value="sectors" className="flex items-center gap-2">
              <PieChartIcon className="h-4 w-4" />
              <span className="hidden sm:inline">القطاعات</span>
            </TabsTrigger>
            <TabsTrigger value="growth" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">النمو</span>
            </TabsTrigger>
            <TabsTrigger value="water" className="flex items-center gap-2">
              <Droplets className="h-4 w-4" />
              <span className="hidden sm:inline">المياه</span>
            </TabsTrigger>
            <TabsTrigger value="all" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">الكل</span>
            </TabsTrigger>
          </TabsList>

          {/* Production Chart */}
          <TabsContent value="production">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wheat className="h-5 w-5 text-green-600" />
                  إنتاج المحاصيل الرئيسية (مليون طن)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={cropProductionData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        contentStyle={{ textAlign: 'right' }}
                        formatter={(value: number) => [`${value.toFixed(2)} مليون طن`, 'الإنتاج']}
                      />
                      <Legend />
                      <Bar dataKey="production" fill="#16a34a" name="الإنتاج (مليون طن)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>المساحات المزروعة (ألف فدان)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={cropProductionData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" width={80} />
                        <Tooltip 
                          contentStyle={{ textAlign: 'right' }}
                          formatter={(value: number) => [`${value.toFixed(0)} ألف فدان`, 'المساحة']}
                        />
                        <Bar dataKey="area" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>متوسط الإنتاجية (طن/فدان)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={cropProductionData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip 
                          contentStyle={{ textAlign: 'right' }}
                          formatter={(value: number) => [`${value.toFixed(1)} طن/فدان`, 'الإنتاجية']}
                        />
                        <Bar dataKey="yield" fill="#f59e0b" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Sectors Chart */}
          <TabsContent value="sectors">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sprout className="h-5 w-5 text-green-600" />
                    مساهمة القطاعات الزراعية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={sectorContributionData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name}: ${value}%`}
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {sectorContributionData.map((_entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: number) => [`${value}%`, 'المساهمة']} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    توزيع العمالة بالقطاعات
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={sectorContributionData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, employment }) => `${name}: ${employment}%`}
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="employment"
                        >
                          {sectorContributionData.map((_entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: number) => [`${value}%`, 'العمالة']} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sector Details Table */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>تفاصيل القطاعات الزراعية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-3 px-4">القطاع</th>
                        <th className="text-right py-3 px-4">المساهمة (%)</th>
                        <th className="text-right py-3 px-4">العمالة (%)</th>
                        <th className="text-right py-3 px-4">معدل النمو (%)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sectors.map((sector) => (
                        <tr key={sector.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{sector.name}</td>
                          <td className="py-3 px-4">{sector.contribution}%</td>
                          <td className="py-3 px-4">{sector.employment}%</td>
                          <td className="py-3 px-4">
                            <Badge className="bg-green-100 text-green-800">
                              +{sector.growth}%
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Growth Chart */}
          <TabsContent value="growth">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  مؤشرات النمو السنوية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={yearlyGrowthData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis />
                      <Tooltip 
                        contentStyle={{ textAlign: 'right' }}
                        formatter={(value: number, name: string) => [
                          `${value} ${name === 'production' ? 'مليون طن' : 'مليار دولار'}`,
                          name === 'production' ? 'الإنتاج' : 'الصادرات'
                        ]}
                      />
                      <Legend />
                      <Line type="monotone" dataKey="production" stroke="#16a34a" strokeWidth={3} name="الإنتاج (مليون طن)" />
                      <Line type="monotone" dataKey="exports" stroke="#3b82f6" strokeWidth={3} name="الصادرات (مليار دولار)" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-green-600 mb-2">120</div>
                  <div className="text-gray-600">مليون طن إنتاج 2024</div>
                  <Badge className="mt-2 bg-green-100 text-green-800">+8.5%</Badge>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-blue-600 mb-2">9.2</div>
                  <div className="text-gray-600">مليار دولار صادرات 2024</div>
                  <Badge className="mt-2 bg-blue-100 text-blue-800">+22.1%</Badge>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl font-bold text-amber-600 mb-2">7.5</div>
                  <div className="text-gray-600">مليون طن صادرات 2024</div>
                  <Badge className="mt-2 bg-amber-100 text-amber-800">+15.3%</Badge>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Water Efficiency Chart */}
          <TabsContent value="water">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-blue-600" />
                  كفاءة استخدام المياه في الزراعة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={waterEfficiencyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip 
                        contentStyle={{ textAlign: 'right' }}
                        formatter={(value: number) => [`${value}%`, 'الكفاءة']}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="efficiency" 
                        stroke="#3b82f6" 
                        fill="#3b82f6" 
                        fillOpacity={0.3}
                        name="كفاءة استخدام المياه (%)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardContent className="p-6">
                  <h4 className="font-semibold mb-4">إنجازات تحديث الري</h4>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <div className="bg-green-100 p-2 rounded-lg">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                      </div>
                      <span>زيادة كفاءة استخدام المياه بنسبة 17% منذ 2020</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="bg-blue-100 p-2 rounded-lg">
                        <Droplets className="h-4 w-4 text-blue-600" />
                      </div>
                      <span>ترشيد استهلاك المياه بمقدار 5 مليار متر مكعب</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="bg-amber-100 p-2 rounded-lg">
                        <Sprout className="h-4 w-4 text-amber-600" />
                      </div>
                      <span>تحديث 3.5 مليون فدان لنظم الري الحديث</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h4 className="font-semibold mb-4">أهداف 2030</h4>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <div className="bg-green-100 p-2 rounded-lg">
                        <Target className="h-4 w-4 text-green-600" />
                      </div>
                      <span>الوصول لـ85% كفاءة في استخدام المياه</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="bg-blue-100 p-2 rounded-lg">
                        <Droplets className="h-4 w-4 text-blue-600" />
                      </div>
                      <span>توفير 10 مليار متر مكعب من المياه</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg">
                        <Wheat className="h-4 w-4 text-purple-600" />
                      </div>
                      <span>زيادة الإنتاجية الزراعية بنسبة 30%</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* All Statistics */}
          <TabsContent value="all">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {statistics.map((stat) => (
                <Card key={stat.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`p-3 rounded-xl ${
                        stat.changeType === 'positive' ? 'bg-green-100' : 
                        stat.changeType === 'negative' ? 'bg-red-100' : 'bg-gray-100'
                      }`}>
                        {stat.changeType === 'positive' ? (
                          <TrendingUp className="h-6 w-6 text-green-600" />
                        ) : (
                          <TrendingDown className="h-6 w-6 text-red-600" />
                        )}
                      </div>
                      <Badge variant="outline">{stat.category}</Badge>
                    </div>
                    <p className="text-gray-500 text-sm mb-1">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mb-2">
                      {stat.value} <span className="text-sm font-normal">{stat.unit}</span>
                    </p>
                    <Badge className={`
                      ${stat.changeType === 'positive' ? 'bg-green-100 text-green-800' : 
                        stat.changeType === 'negative' ? 'bg-red-100 text-red-800' : 
                        'bg-gray-100 text-gray-800'}
                    `}>
                      {stat.change}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}


