import React, { useState, useEffect, createContext, useContext } from 'react';
import { v4 as uuidv4 } from 'uuid';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'user';
  avatar?: string;
  phone?: string;
  address?: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => Promise<{ success: boolean; message: string }>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<{ success: boolean; message: string }>;
}

const AuthContext = createContext<AuthContextType | null>(null);

const DEFAULT_ADMIN: User = {
  id: 'admin-001',
  name: 'مدير النظام',
  email: 'admin@agriculture.gov.eg',
  password: 'admin123',
  role: 'admin',
  avatar: 'https://ui-avatars.com/api/?name=Admin&background=16a34a&color=fff',
  phone: '+20 2 123456789',
  address: 'القاهرة، مصر - وزارة الزراعة',
  createdAt: new Date().toISOString(),
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const users = localStorage.getItem('users');
    if (!users) {
      localStorage.setItem('users', JSON.stringify([DEFAULT_ADMIN]));
    }
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      setUser(JSON.parse(currentUser));
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; message: string }> => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find((u: User) => u.email === email && u.password === password);
    if (foundUser) {
      setUser(foundUser);
      setIsAuthenticated(true);
      localStorage.setItem('currentUser', JSON.stringify(foundUser));
      return { success: true, message: 'تم تسجيل الدخول بنجاح' };
    }
    return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
  };

  const register = async (name: string, email: string, password: string): Promise<{ success: boolean; message: string }> => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.some((u: User) => u.email === email)) {
      return { success: false, message: 'البريد الإلكتروني مستخدم بالفعل' };
    }
    const newUser: User = {
      id: uuidv4(),
      name,
      email,
      password,
      role: 'user',
      avatar: 'https://ui-avatars.com/api/?name=' + encodeURIComponent(name) + '&background=3b82f6&color=fff',
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    setUser(newUser);
    setIsAuthenticated(true);
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    return { success: true, message: 'تم إنشاء الحساب بنجاح' };
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
  };

  const updateProfile = async (updates: Partial<User>): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'غير مسجل الدخول' };
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex((u: User) => u.id === user.id);
    if (userIndex === -1) return { success: false, message: 'المستخدم غير موجود' };
    const updatedUser = { ...users[userIndex], ...updates };
    users[userIndex] = updatedUser;
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    setUser(updatedUser);
    return { success: true, message: 'تم تحديث الملف الشخصي بنجاح' };
  };

  const changePassword = async (oldPassword: string, newPassword: string): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'غير مسجل الدخول' };
    if (user.password !== oldPassword) return { success: false, message: 'كلمة المرور القديمة غير صحيحة' };
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex((u: User) => u.id === user.id);
    if (userIndex === -1) return { success: false, message: 'المستخدم غير موجود' };
    users[userIndex].password = newPassword;
    localStorage.setItem('users', JSON.stringify(users));
    const updatedUser = { ...user, password: newPassword };
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    setUser(updatedUser);
    return { success: true, message: 'تم تغيير كلمة المرور بنجاح' };
  };

  const value = {
    user,
    isAuthenticated,
    isAdmin: user ? user.role === 'admin' : false,
    login,
    register,
    logout,
    updateProfile,
    changePassword,
  };

  return React.createElement(AuthContext.Provider, { value }, children);
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
