// Mock Data for Agricultural Sector Website

import type { Initiative, Article, Statistic, Report, User, Notification, CropData, AgriculturalSector } from '@/types';

export const initiatives: Initiative[] = [
  {
    id: 1,
    title: "مبادرة تحديث الري الحقلي",
    description: "مبادرة شاملة لتحديث نظم الري في المزارع المصرية لزيادة كفاءة استخدام المياه وزيادة الإنتاجية الزراعية",
    category: "ري",
    impact: "زيادة كفاءة استخدام المياه بنسبة 30% وزيادة الإنتاج بنسبة 25%",
    image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800",
    date: "2024-01-15",
    location: "محافظات الدلتا",
    beneficiaries: 50000,
    budget: "2.5 مليار جنيه",
    status: "active",
    rating: 4.5,
    reviews: [
      { id: 1, userName: "أحمد محمد", rating: 5, comment: "مبادرة ممتازة ساعدتنا كثيراً في توفير المياه", date: "2024-02-01" },
      { id: 2, userName: "محمود عبدالله", rating: 4, comment: "نتائج جيدة لكن تحتاج مزيد من التوسع", date: "2024-01-20" }
    ]
  },
  {
    id: 2,
    title: "مشروع الصوامع والمخازن الاستراتيجية",
    description: "إنشاء صوامع ومخازن حديثة لتخزين الحبوب والمحاصيل الاستراتيجية بكفاءة عالية",
    category: "تخزين",
    impact: "تقليل الفاقد من المخزون الاستراتيجي بنسبة 15%",
    image: "https://images.unsplash.com/photo-1586771107445-d3ca888129ff?w=800",
    date: "2023-06-20",
    location: "جميع المحافظات",
    beneficiaries: 2000000,
    budget: "5 مليار جنيه",
    status: "active",
    rating: 4.8,
    reviews: [
      { id: 3, userName: "علي حسن", rating: 5, comment: "تحسن كبير في جودة التخزين", date: "2024-01-15" }
    ]
  },
  {
    id: 3,
    title: "مبادرة الزراعة العضوية",
    description: "تشجيع المزارعين على اعتماد الزراعة العضوية لإنتاج محاصيل صحية وآمنة",
    category: "زراعة عضوية",
    impact: "زيادة المساحات المزروعة عضوياً بنسبة 40%",
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800",
    date: "2024-03-10",
    location: "الوادي الجديد",
    beneficiaries: 15000,
    budget: "800 مليون جنيه",
    status: "active",
    rating: 4.2,
    reviews: []
  },
  {
    id: 4,
    title: "تطوير البذور المحسنة",
    description: "إنتاج بذور محسنة عالية الإنتاجية ومقاومة للأمراض والآفات",
    category: "بذور",
    impact: "زيادة إنتاجية المحاصيل بنسبة 20%",
    image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800",
    date: "2023-09-01",
    location: "محطات البحوث الزراعية",
    beneficiaries: 100000,
    budget: "1.2 مليار جنيه",
    status: "completed",
    rating: 4.7,
    reviews: [
      { id: 4, userName: "سامي رمضان", rating: 5, comment: "بذور ممتازة وإنتاجية عالية", date: "2023-12-10" },
      { id: 5, userName: "خالد محمود", rating: 4, comment: "نتائج مبهرة", date: "2023-11-25" }
    ]
  },
  {
    id: 5,
    title: "مشروع الدلتا الجديدة",
    description: "استصلاح وتنمية مليون فدان في منطقة الدلتا الجديدة",
    category: "استصلاح",
    impact: "إضافة مليون فدان للرقعة الزراعية",
    image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800",
    date: "2024-02-01",
    location: "الدلتا الجديدة",
    beneficiaries: 500000,
    budget: "15 مليار جنيه",
    status: "active",
    rating: 4.6,
    reviews: []
  },
  {
    id: 6,
    title: "مبادرة التحول الرقمي في الزراعة",
    description: "تطبيقات الذكاء الاصطناعي والزراعة الدقيقة لتحسين إدارة الموارد",
    category: "تكنولوجيا",
    impact: "زيادة كفاءة الإنتاج بنسبة 35%",
    image: "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800",
    date: "2024-04-01",
    location: "المحافظات الرئيسية",
    beneficiaries: 25000,
    budget: "2 مليار جنيه",
    status: "planned",
    rating: 0,
    reviews: []
  }
];

export const articles: Article[] = [
  {
    id: 1,
    title: "مصر تحقق الاكتفاء الذاتي من القمح",
    content: "حققت مصر إنجازاً تاريخياً في مجال الزراعة حيث وصلت نسبة الاكتفاء الذاتي من القمح إلى 60% للمرة الأولى في تاريخها...",
    excerpt: "إنجاز تاريخي في الزراعة المصرية مع الوصول لـ60% اكتفاء ذاتي من القمح",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800",
    author: "د. أحمد عبدالله",
    date: "2024-05-15",
    category: "إنتاج",
    tags: ["قمح", "اكتفاء ذاتي", "محاصيل استراتيجية"],
    views: 15420
  },
  {
    id: 2,
    title: "الزراعة العضوية: مستقبل الزراعة المصرية",
    content: "تتجه مصر نحو توسيع المساحات المزروعة عضوياً لمواكبة الطلب العالمي المتزايد على المنتجات العضوية...",
    excerpt: "توسيع المساحات العضوية لمواكبة الطلب العالمي المتزايد",
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800",
    author: "م. سارة محمود",
    date: "2024-05-10",
    category: "زراعة عضوية",
    tags: ["عضوي", "صحة", "تصدير"],
    views: 8930
  },
  {
    id: 3,
    title: "تحديث الري: خطوة نحو الاستدامة",
    content: "تستمر وزارة الزراعة في جهودها لتحديث نظم الري لتحقيق الاستدامة المائية وضمان مستقبل الزراعة في مصر...",
    excerpt: "جهود مستمرة لتحديث نظم الري وتحقيق الاستدامة المائية",
    image: "https://images.unsplash.com/photo-1500076656116-558758c991c1?w=800",
    author: "د. محمد علي",
    date: "2024-05-05",
    category: "ري",
    tags: ["مياه", "استدامة", "تحديث"],
    views: 12450
  },
  {
    id: 4,
    title: "الصادرات الزراعية تسجل أرقاماً قياسية",
    content: "سجلت الصادرات الزراعية المصرية رقماً قياسياً جديداً حيث وصلت إلى 7.5 مليون طن خلال الموسم الحالي...",
    excerpt: "رقم قياسي جديد للصادرات الزراعية المصرية",
    image: "https://images.unsplash.com/photo-1595855709915-fa457bd24059?w=800",
    author: "أ. خالد سامي",
    date: "2024-04-28",
    category: "تصدير",
    tags: ["تصدير", "اقتصاد", "تنمية"],
    views: 21500
  },
  {
    id: 5,
    title: "الاستثمار في البحث العلمي الزراعي",
    content: "تضاعف الاستثمار في البحث العلمي الزراعي لإنتاج أصناف جديدة مقاومة للتغيرات المناخية...",
    excerpt: "تضاعف الاستثمار في البحث العلمي لمواجهة التغيرات المناخية",
    image: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800",
    author: "د. هالة فؤاد",
    date: "2024-04-20",
    category: "بحث علمي",
    tags: ["بحث", "تقنية", "مناخ"],
    views: 6780
  },
  {
    id: 6,
    title: "مشروعات الاستصلاح: آفاق جديدة",
    content: "تفتح مشروعات استصلاح الأراضي آفاقاً جديدة للتوسع الزراعي واستيعاب الشباب في المجال الزراعي...",
    excerpt: "آفاق جديدة للتوسع الزراعي من خلال مشروعات الاستصلاح",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800",
    author: "م. عمرو حسن",
    date: "2024-04-15",
    category: "استصلاح",
    tags: ["استصلاح", "تنمية", "فرص عمل"],
    views: 9870
  }
];

export const statistics: Statistic[] = [
  {
    id: 1,
    title: "إجمالي الإنتاج الزراعي",
    value: "120",
    unit: "مليون طن",
    change: "+8.5%",
    changeType: "positive",
    year: 2024,
    category: "إنتاج",
    icon: "Wheat"
  },
  {
    id: 2,
    title: "المساحة الزراعية",
    value: "9.5",
    unit: "مليون فدان",
    change: "+3.2%",
    changeType: "positive",
    year: 2024,
    category: "مساحة",
    icon: "Map"
  },
  {
    id: 3,
    title: "الصادرات الزراعية",
    value: "7.5",
    unit: "مليون طن",
    change: "+15.3%",
    changeType: "positive",
    year: 2024,
    category: "تصدير",
    icon: "Ship"
  },
  {
    id: 4,
    title: "العمالة في الزراعة",
    value: "28",
    unit: "% من العمالة",
    change: "-1.2%",
    changeType: "negative",
    year: 2024,
    category: "عمالة",
    icon: "Users"
  },
  {
    id: 5,
    title: "قيمة الصادرات",
    value: "9.2",
    unit: "مليار دولار",
    change: "+22.1%",
    changeType: "positive",
    year: 2024,
    category: "اقتصاد",
    icon: "DollarSign"
  },
  {
    id: 6,
    title: "كفاءة استخدام المياه",
    value: "75",
    unit: "%",
    change: "+12.5%",
    changeType: "positive",
    year: 2024,
    category: "مياه",
    icon: "Droplets"
  },
  {
    id: 7,
    title: "المساحات المستصلحة",
    value: "2.5",
    unit: "مليون فدان",
    change: "+18.7%",
    changeType: "positive",
    year: 2024,
    category: "استصلاح",
    icon: "Sprout"
  },
  {
    id: 8,
    title: "عدد المزارعين المستفيدين",
    value: "5.2",
    unit: "مليون مزارع",
    change: "+5.8%",
    changeType: "positive",
    year: 2024,
    category: "مزارعين",
    icon: "UserCheck"
  }
];

export const reports: Report[] = [
  { id: 1, title: "التقرير الربعي الأول 2024", type: "ربعي", year: 2024, quarter: "Q1", fileUrl: "#", size: "5.2 MB", date: "2024-04-01" },
  { id: 2, title: "التقرير السنوي 2023", type: "سنوي", year: 2023, quarter: "-", fileUrl: "#", size: "12.8 MB", date: "2024-01-15" },
  { id: 3, title: "التقرير الربعي الرابع 2023", type: "ربعي", year: 2023, quarter: "Q4", fileUrl: "#", size: "4.9 MB", date: "2024-01-10" },
  { id: 4, title: "التقرير الربعي الثالث 2023", type: "ربعي", year: 2023, quarter: "Q3", fileUrl: "#", size: "5.1 MB", date: "2023-10-15" },
  { id: 5, title: "تقرير التنمية الزراعية", type: "تنموي", year: 2023, quarter: "-", fileUrl: "#", size: "8.3 MB", date: "2023-12-20" }
];

export const adminUser: User = {
  id: 1,
  name: "مدير النظام",
  email: "admin@agriculture.gov.eg",
  role: "admin",
  avatar: "https://ui-avatars.com/api/?name=Admin&background=16a34a&color=fff"
};

export const notifications: Notification[] = [
  { id: 1, title: "مبادرة جديدة", message: "تم إضافة مبادرة تحديث الري الحقلي", type: "success", date: "2024-05-15 10:30", read: false },
  { id: 2, title: "تعليق جديد", message: "تعليق جديد على مبادرة الزراعة العضوية", type: "info", date: "2024-05-14 15:45", read: false },
  { id: 3, title: "تحديث إحصائي", message: "تم تحديث إحصائيات الإنتاج الزراعي", type: "info", date: "2024-05-13 09:00", read: true },
  { id: 4, title: "مقال جديد", message: "تم نشر مقال عن الاكتفاء الذاتي من القمح", type: "success", date: "2024-05-12 14:20", read: true }
];

export const cropData: CropData[] = [
  { id: 1, name: "قمح", production: 9500000, area: 3200000, yield: 29.7, year: 2024, region: "الدلتا" },
  { id: 2, name: "أرز", production: 6200000, area: 1850000, yield: 33.5, year: 2024, region: "الدلتا" },
  { id: 3, name: "ذرة", production: 7800000, area: 2100000, yield: 37.1, year: 2024, region: "الوجه البحري" },
  { id: 4, name: "قصب سكر", production: 14500000, area: 380000, yield: 381.6, year: 2024, region: "صعيد مصر" },
  { id: 5, name: "قطن", production: 280000, area: 120000, yield: 23.3, year: 2024, region: "الدلتا" },
  { id: 6, name: "بطاطس", production: 5200000, area: 450000, yield: 115.6, year: 2024, region: "الوجه البحري" },
  { id: 7, name: "طماطم", production: 6800000, area: 280000, yield: 242.9, year: 2024, region: "جميع المحافظات" },
  { id: 8, name: "بصل", production: 3200000, area: 180000, yield: 177.8, year: 2024, region: "صعيد مصر" }
];

export const sectors: AgriculturalSector[] = [
  {
    id: 1,
    name: "محاصيل الحبوب",
    description: "تشمل القمح والأرز والذرة والشعير",
    contribution: 35,
    employment: 42,
    growth: 8.5,
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400"
  },
  {
    id: 2,
    name: "الخضروات",
    description: "تشمل الطماطم والبطاطس والبصل والفلفل",
    contribution: 28,
    employment: 35,
    growth: 12.3,
    image: "https://images.unsplash.com/photo-1597362925123-77861d3fbac7?w=400"
  },
  {
    id: 3,
    name: "الفاكهة",
    description: "تشمل الموالح والعنب والمانجو والتفاح",
    contribution: 18,
    employment: 15,
    growth: 15.7,
    image: "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=400"
  },
  {
    id: 4,
    name: "محاصيل صناعية",
    description: "تشمل القطن وقصب السكر والبنجر",
    contribution: 12,
    employment: 5,
    growth: 6.2,
    image: "https://images.unsplash.com/photo-1598511726623-d0996d241333?w=400"
  },
  {
    id: 5,
    name: "الثروة الحيوانية",
    description: "تشمل الألبان واللحوم والدواجن",
    contribution: 7,
    employment: 3,
    growth: 9.8,
    image: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=400"
  }
];

export const categories = ["الكل", "ري", "تخزين", "زراعة عضوية", "بذور", "استصلاح", "تكنولوجيا", "إنتاج", "تصدير", "بحث علمي"];
