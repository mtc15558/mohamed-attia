import { Wheat, Phone, Mail, MapPin, Facebook, Twitter, Youtube, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-green-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-white p-2 rounded-lg">
                <Wheat className="h-6 w-6 text-green-900" />
              </div>
              <span className="text-xl font-bold">القطاع الزراعي</span>
            </div>
            <p className="text-green-200 text-sm leading-relaxed">
              موقع إلكتروني متخصص في عرض دور القطاع الزراعي في تدعيم التنمية الزراعية، 
              وعرض المبادرات والإحصائيات والأخبار الزراعية.
            </p>
            <div className="flex gap-3">
              <a href="#" className="bg-green-800 p-2 rounded-lg hover:bg-green-700 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-green-800 p-2 rounded-lg hover:bg-green-700 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-green-800 p-2 rounded-lg hover:bg-green-700 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" className="bg-green-800 p-2 rounded-lg hover:bg-green-700 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-green-200 hover:text-white transition-colors">الرئيسية</a>
              </li>
              <li>
                <a href="/initiatives" className="text-green-200 hover:text-white transition-colors">المبادرات الزراعية</a>
              </li>
              <li>
                <a href="/statistics" className="text-green-200 hover:text-white transition-colors">الإحصائيات</a>
              </li>
              <li>
                <a href="/articles" className="text-green-200 hover:text-white transition-colors">المقالات</a>
              </li>
              <li>
                <a href="/reports" className="text-green-200 hover:text-white transition-colors">التقارير</a>
              </li>
            </ul>
          </div>

          {/* Sectors */}
          <div>
            <h3 className="text-lg font-semibold mb-4">القطاعات الزراعية</h3>
            <ul className="space-y-2">
              <li>
                <span className="text-green-200">محاصيل الحبوب</span>
              </li>
              <li>
                <span className="text-green-200">الخضروات</span>
              </li>
              <li>
                <span className="text-green-200">الفاكهة</span>
              </li>
              <li>
                <span className="text-green-200">الثروة الحيوانية</span>
              </li>
              <li>
                <span className="text-green-200">الثروة السمكية</span>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">تواصل معنا</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-green-400" />
                <span className="text-green-200">القاهرة، مصر - وزارة الزراعة</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-green-400" />
                <span className="text-green-200">+20 2 123456789</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-green-400" />
                <span className="text-green-200">info@agriculture.gov.eg</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-green-800 mt-8 pt-8 text-center">
          <p className="text-green-300 text-sm">
            جميع الحقوق محفوظة © {new Date().getFullYear()} - موقع القطاع الزراعي المصري
          </p>
        </div>
      </div>
    </footer>
  );
}
