// User Types
export type UserRole = 'admin' | 'farmer' | 'investor' | 'student';

export interface User {
  id: number;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  phone?: string;
  avatar?: string;
  created_at: string;
  is_active: boolean;
}

// Sector Types
export interface Sector {
  id: number;
  name: string;
  name_en: string;
  description: string;
  importance: string;
  challenges: string[];
  investment_opportunities: string[];
  image: string;
  icon: string;
  crop_types?: CropType[];
}

export interface CropType {
  id: number;
  sector_id: number;
  name: string;
  description: string;
  image: string;
  production_area?: string;
  season?: string;
}

// Project Types
export interface Project {
  id: number;
  name: string;
  description: string;
  goal: string;
  area: string;
  expected_production: string;
  economic_impact: string;
  image: string;
  location: string;
  start_date: string;
  status: 'active' | 'completed' | 'planned';
  investment_cost?: string;
}

// News Types
export interface News {
  id: number;
  title: string;
  content: string;
  summary: string;
  image: string;
  category: string;
  author: string;
  published_at: string;
  views: number;
  is_featured: boolean;
}

// Investment Types
export interface Investment {
  id: number;
  title: string;
  description: string;
  type: 'land_sale' | 'land_rent' | 'small_project';
  location: string;
  area?: string;
  price: string;
  contact_info: string;
  images: string[];
  feasibility_study?: string;
  owner_id: number;
  status: 'available' | 'sold' | 'rented';
  created_at: string;
}

// Statistics Types
export interface Statistics {
  id: number;
  year: number;
  crop_name: string;
  production_tons: number;
  area_feddans: number;
  export_value: number;
  import_value: number;
}

// Comment Types
export interface Comment {
  id: number;
  user_id: number;
  project_id?: number;
  investment_id?: number;
  content: string;
  rating: number;
  created_at: string;
  user?: User;
  is_approved: boolean;
}

// Message Types
export interface Message {
  id: number;
  sender_id: number;
  receiver_id: number;
  content: string;
  created_at: string;
  is_read: boolean;
  sender?: User;
  receiver?: User;
}

// Notification Types
export interface Notification {
  id: number;
  user_id: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning';
  created_at: string;
  is_read: boolean;
  link?: string;
}

// Guidance Types
export interface Guidance {
  id: number;
  category: 'irrigation' | 'pest_control' | 'fertilization' | 'soil';
  title: string;
  content: string;
  image?: string;
  video_url?: string;
  pdf_url?: string;
}

// Auth Context Types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Partial<User>) => Promise<boolean>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
}

// Dashboard Stats
export interface DashboardStats {
  totalUsers: number;
  totalProjects: number;
  totalInvestments: number;
  totalNews: number;
  pendingComments: number;
  monthlyStats: {
    month: string;
    users: number;
    projects: number;
  }[];
}

// Search Filters
export interface SearchFilters {
  query?: string;
  sector?: string;
  location?: string;
  type?: string;
  minPrice?: number;
  maxPrice?: number;
}
