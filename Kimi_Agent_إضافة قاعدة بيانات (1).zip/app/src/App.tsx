import { useAuth } from '@/hooks/useAuth';
import { Navbar } from '@/components/Navbar';
import { AdminDashboard } from '@/components/dashboard/AdminDashboard';
import { FarmerDashboard } from '@/components/dashboard/FarmerDashboard';
import { InvestorDashboard } from '@/components/dashboard/InvestorDashboard';
import { HeroSection } from '@/sections/HeroSection';
import { SectorsSection } from '@/sections/SectorsSection';
import { ProjectsSection } from '@/sections/ProjectsSection';
import { InvestmentSection } from '@/sections/InvestmentSection';
import { StatisticsSection } from '@/sections/StatisticsSection';
import { NewsSection } from '@/sections/NewsSection';
import { GuidanceSection } from '@/sections/GuidanceSection';
import { ContactSection } from '@/sections/ContactSection';
import { Footer } from '@/sections/Footer';

function App() {
  const { user, isAuthenticated } = useAuth();

  // Check if user is on a dashboard route
  const path = window.location.pathname;
  
  if (path === '/admin' && isAuthenticated && user?.role === 'admin') {
    return <AdminDashboard />;
  }
  
  if (path === '/farmer' && isAuthenticated && user?.role === 'farmer') {
    return <FarmerDashboard />;
  }
  
  if (path === '/investor' && isAuthenticated && user?.role === 'investor') {
    return <InvestorDashboard />;
  }

  // Main website
  return (
    <div className="min-h-screen bg-white" dir="rtl">
      <Navbar />
      <main>
        <HeroSection />
        <SectorsSection />
        <ProjectsSection />
        <InvestmentSection />
        <StatisticsSection />
        <NewsSection />
        <GuidanceSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
