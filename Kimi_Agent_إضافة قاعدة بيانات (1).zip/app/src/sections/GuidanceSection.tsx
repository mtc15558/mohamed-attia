import { useState } from 'react';
import { Droplets, Bug, FlaskConical, Mountain, Play, FileText, X } from 'lucide-react';
import { guidance } from '@/data/mockData';
import { useToast } from '@/hooks/useToast';
import type { Guidance } from '@/types';

const categories = [
  { id: 'all', name: 'الكل', icon: null },
  { id: 'irrigation', name: 'الري', icon: Droplets },
  { id: 'pest_control', name: 'مكافحة الآفات', icon: Bug },
  { id: 'fertilization', name: 'التسميد', icon: FlaskConical },
  { id: 'soil', name: 'التربة', icon: Mountain }
];

export function GuidanceSection() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedGuidance, setSelectedGuidance] = useState<Guidance | null>(null);
  const { showToast } = useToast();

  const filteredGuidance = selectedCategory === 'all' 
    ? guidance 
    : guidance.filter(g => g.category === selectedCategory);

  const getCategoryName = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat?.name || category;
  };

  return (
    <section id="guidance" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">الإرشاد الزراعي</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            إرشادات ونصائح زراعية من الخبراء لتحسين إنتاجيتك
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {categories.map(cat => {
            const IconComponent = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-[#2d5a27] text-white'
                    : 'bg-[#f5f0e8] text-gray-700 hover:bg-gray-200'
                }`}
              >
                {IconComponent && <IconComponent className="w-5 h-5" />}
                {cat.name}
              </button>
            );
          })}
        </div>

        {/* Guidance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredGuidance.map(item => {
            const IconComponent = categories.find(c => c.id === item.category)?.icon || Droplets;
            
            return (
              <div 
                key={item.id}
                className="agri-card p-6 cursor-pointer group"
                onClick={() => setSelectedGuidance(item)}
              >
                <div className="flex gap-6">
                  <div className="w-32 h-32 flex-shrink-0 rounded-xl overflow-hidden">
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <IconComponent className="w-4 h-4 text-[#d4a574]" />
                      <span className="text-sm text-[#d4a574]">{getCategoryName(item.category)}</span>
                    </div>
                    <h3 className="text-lg font-bold text-[#2d5a27] mb-2">{item.title}</h3>
                    <p className="text-gray-600 text-sm line-clamp-2">{item.content}</p>
                    <div className="flex items-center gap-4 mt-3">
                      {item.video_url && (
                        <span className="flex items-center gap-1 text-sm text-blue-600">
                          <Play className="w-4 h-4" />
                          فيديو
                        </span>
                      )}
                      {item.pdf_url && (
                        <span className="flex items-center gap-1 text-sm text-green-600">
                          <FileText className="w-4 h-4" />
                          PDF
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Guidance Detail Modal */}
        {selectedGuidance && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
              <div className="relative">
                <img 
                  src={selectedGuidance.image} 
                  alt={selectedGuidance.title} 
                  className="w-full h-64 object-cover"
                />
                <button 
                  onClick={() => setSelectedGuidance(null)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                  <span className="text-white/80 text-sm">{getCategoryName(selectedGuidance.category)}</span>
                  <h2 className="text-2xl font-bold text-white">{selectedGuidance.title}</h2>
                </div>
              </div>
              
              <div className="p-6">
                <div className="prose max-w-none mb-6">
                  <p className="text-gray-700 leading-relaxed">{selectedGuidance.content}</p>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  {selectedGuidance.video_url && (
                    <button 
                      onClick={() => showToast('سيتم تشغيل الفيديو', 'info')}
                      className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
                    >
                      <Play className="w-5 h-5" />
                      مشاهدة الفيديو
                    </button>
                  )}
                  {selectedGuidance.pdf_url && (
                    <button 
                      onClick={() => showToast('سيتم تحميل الملف', 'info')}
                      className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors"
                    >
                      <FileText className="w-5 h-5" />
                      تحميل PDF
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
