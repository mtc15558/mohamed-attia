import { useState } from 'react';
import { MapPin, Phone, FileText, Heart, Search, Filter, ChevronLeft } from 'lucide-react';
import { investments } from '@/data/mockData';
import { useToast } from '@/hooks/useToast';
import type { Investment } from '@/types';

export function InvestmentSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [favorites, setFavorites] = useState<number[]>([]);
  const [selectedInvestment, setSelectedInvestment] = useState<Investment | null>(null);
  const { showToast } = useToast();

  const filteredInvestments = investments.filter(inv => {
    const matchesSearch = inv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         inv.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || inv.type === selectedType;
    return matchesSearch && matchesType;
  });

  const toggleFavorite = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(f => f !== id));
      showToast('تم الإزالة من المفضلة', 'info');
    } else {
      setFavorites([...favorites, id]);
      showToast('تم الإضافة للمفضلة', 'success');
    }
  };

  return (
    <section id="investment" className="py-20 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">الاستثمار الزراعي</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            فرص استثمارية متنوعة في القطاع الزراعي المصري
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-2xl p-6 mb-8 shadow-sm">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="ابحث عن فرصة استثمارية..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="agri-input pr-12"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="agri-input"
              >
                <option value="all">جميع الأنواع</option>
                <option value="land_sale">أراضي للبيع</option>
                <option value="land_rent">أراضي للإيجار</option>
                <option value="small_project">مشروعات صغيرة</option>
              </select>
            </div>
          </div>
        </div>

        {/* Investment Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredInvestments.map((investment) => (
            <div 
              key={investment.id}
              className="agri-card overflow-hidden cursor-pointer group"
              onClick={() => setSelectedInvestment(investment)}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={investment.images[0]} 
                  alt={investment.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <button
                  onClick={(e) => toggleFavorite(e, investment.id)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow"
                >
                  <Heart 
                    className={`w-5 h-5 ${favorites.includes(investment.id) ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
                  />
                </button>
                <div className="absolute bottom-4 right-4">
                  <span className={`badge ${
                    investment.type === 'land_sale' ? 'badge-success' : 
                    investment.type === 'land_rent' ? 'badge-info' : 'badge-warning'
                  }`}>
                    {investment.type === 'land_sale' ? 'بيع' : 
                     investment.type === 'land_rent' ? 'إيجار' : 'مشروع'}
                  </span>
                </div>
              </div>
              
              <div className="p-5">
                <h3 className="text-lg font-bold text-[#2d5a27] mb-2 line-clamp-1">{investment.title}</h3>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{investment.description}</p>
                
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                  <MapPin className="w-4 h-4" />
                  {investment.location}
                </div>
                
                {investment.area && (
                  <div className="text-sm text-gray-600 mb-3">
                    المساحة: <span className="font-medium">{investment.area}</span>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold text-[#d4a574]">{investment.price}</span>
                  <span className="flex items-center gap-1 text-[#2d5a27] font-medium">
                    التفاصيل
                    <ChevronLeft className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredInvestments.length === 0 && (
          <div className="text-center py-12">
            <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد نتائج مطابقة للبحث</p>
          </div>
        )}

        {/* Investment Detail Modal */}
        {selectedInvestment && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
              <div className="relative">
                <img 
                  src={selectedInvestment.images[0]} 
                  alt={selectedInvestment.title} 
                  className="w-full h-64 object-cover"
                />
                <button 
                  onClick={() => setSelectedInvestment(null)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                >
                  ×
                </button>
              </div>
              
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className={`badge mb-2 ${
                      selectedInvestment.type === 'land_sale' ? 'badge-success' : 
                      selectedInvestment.type === 'land_rent' ? 'badge-info' : 'badge-warning'
                    }`}>
                      {selectedInvestment.type === 'land_sale' ? 'أرض للبيع' : 
                       selectedInvestment.type === 'land_rent' ? 'أرض للإيجار' : 'مشروع استثماري'}
                    </span>
                    <h2 className="text-2xl font-bold text-[#2d5a27]">{selectedInvestment.title}</h2>
                  </div>
                  <button
                    onClick={(e) => toggleFavorite(e, selectedInvestment.id)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <Heart 
                      className={`w-6 h-6 ${favorites.includes(selectedInvestment.id) ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
                    />
                  </button>
                </div>
                
                <p className="text-gray-600 mb-4">{selectedInvestment.description}</p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#d4a574]" />
                    <span className="text-gray-700">{selectedInvestment.location}</span>
                  </div>
                  {selectedInvestment.area && (
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 flex items-center justify-center text-[#d4a574]">📐</div>
                      <span className="text-gray-700">المساحة: {selectedInvestment.area}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-[#d4a574]" />
                    <span className="text-gray-700" dir="ltr">{selectedInvestment.contact_info}</span>
                  </div>
                </div>
                
                <div className="bg-[#f5f0e8] rounded-xl p-4 mb-6">
                  <div className="text-sm text-gray-600 mb-1">السعر</div>
                  <div className="text-2xl font-bold text-[#d4a574]">{selectedInvestment.price}</div>
                </div>
                
                {selectedInvestment.feasibility_study && (
                  <div className="mb-6">
                    <a 
                      href={selectedInvestment.feasibility_study}
                      className="flex items-center gap-2 text-[#2d5a27] hover:underline"
                      onClick={(e) => {
                        e.preventDefault();
                        showToast('سيتم تحميل دراسة الجدوى', 'info');
                      }}
                    >
                      <FileText className="w-5 h-5" />
                      تحميل دراسة الجدوى (PDF)
                    </a>
                  </div>
                )}
                
                <button 
                  onClick={() => {
                    showToast('سيتم التواصل مع المعلن', 'success');
                    setSelectedInvestment(null);
                  }}
                  className="w-full agri-button flex items-center justify-center gap-2"
                >
                  <Phone className="w-5 h-5" />
                  تواصل مع المعلن
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
