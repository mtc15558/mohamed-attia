import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, Facebook, Twitter, Youtube, Instagram } from 'lucide-react';
import { useToast } from '@/hooks/useToast';

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const { showToast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
      return;
    }

    showToast('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً', 'success');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <section id="contact" className="py-20 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">تواصل معنا</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            نحن هنا لمساعدتك. تواصل معنا للاستفسارات والاقتراحات
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-6">
            <div className="agri-card p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#2d5a27]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-[#2d5a27]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2d5a27] mb-1">العنوان</h3>
                  <p className="text-gray-600 text-sm">
                    وزارة الزراعة واستصلاح الأراضي<br />
                    شارع نادي الصيد - الدقي - الجيزة
                  </p>
                </div>
              </div>
            </div>

            <div className="agri-card p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#2d5a27]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-[#2d5a27]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2d5a27] mb-1">الهاتف</h3>
                  <p className="text-gray-600 text-sm" dir="ltr">
                    02-33350101
                  </p>
                  <p className="text-gray-600 text-sm" dir="ltr">
                    02-33350102
                  </p>
                </div>
              </div>
            </div>

            <div className="agri-card p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#2d5a27]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-[#2d5a27]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2d5a27] mb-1">البريد الإلكتروني</h3>
                  <p className="text-gray-600 text-sm" dir="ltr">
                    info@agri.gov.eg
                  </p>
                  <p className="text-gray-600 text-sm" dir="ltr">
                    support@agri.gov.eg
                  </p>
                </div>
              </div>
            </div>

            <div className="agri-card p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#2d5a27]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-[#2d5a27]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2d5a27] mb-1">ساعات العمل</h3>
                  <p className="text-gray-600 text-sm">
                    الأحد - الخميس: 9:00 ص - 3:00 م
                  </p>
                  <p className="text-gray-600 text-sm">
                    الجمعة - السبت: مغلق
                  </p>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div className="agri-card p-6">
              <h3 className="font-bold text-[#2d5a27] mb-4">تابعنا على</h3>
              <div className="flex gap-3">
                <a href="#" className="w-10 h-10 bg-blue-600 text-white rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-sky-500 text-white rounded-lg flex items-center justify-center hover:bg-sky-600 transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-red-600 text-white rounded-lg flex items-center justify-center hover:bg-red-700 transition-colors">
                  <Youtube className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg flex items-center justify-center hover:opacity-90 transition-opacity">
                  <Instagram className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="agri-card p-8">
              <h3 className="text-xl font-bold text-[#2d5a27] mb-6">أرسل رسالتك</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      الاسم الكامل *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="agri-input"
                      placeholder="أدخل اسمك"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      البريد الإلكتروني *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="agri-input"
                      placeholder="أدخل بريدك الإلكتروني"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="agri-input"
                      placeholder="أدخل رقم هاتفك"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      الموضوع
                    </label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="agri-input"
                    >
                      <option value="">اختر الموضوع</option>
                      <option value="inquiry">استفسار عام</option>
                      <option value="investment">استثمار</option>
                      <option value="technical">دعم فني</option>
                      <option value="suggestion">اقتراح</option>
                      <option value="complaint">شكوى</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الرسالة *
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="agri-input"
                    rows={5}
                    placeholder="اكتب رسالتك هنا..."
                  />
                </div>

                <button
                  type="submit"
                  className="agri-button flex items-center justify-center gap-2 w-full md:w-auto"
                >
                  <Send className="w-5 h-5" />
                  إرسال الرسالة
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
