import { useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Sprout, ArrowUpRight } from 'lucide-react';
import { statistics } from '@/data/mockData';

const COLORS = ['#2d5a27', '#4a7c43', '#d4a574', '#8b7355', '#a8d5a2'];

export function StatisticsSection() {
  const [selectedCrop, setSelectedCrop] = useState('القمح');
  const [chartType, setChartType] = useState<'production' | 'area' | 'trade'>('production');

  const cropStats = statistics.filter(s => s.crop_name === selectedCrop);
  
  const latestYear = Math.max(...statistics.map(s => s.year));
  const latestStats = statistics.filter(s => s.year === latestYear);
  
  const totalProduction = latestStats.reduce((sum, s) => sum + s.production_tons, 0);
  const totalArea = latestStats.reduce((sum, s) => sum + s.area_feddans, 0);
  const totalExports = latestStats.reduce((sum, s) => sum + s.export_value, 0);

  const pieData = latestStats.map(s => ({
    name: s.crop_name,
    value: s.production_tons
  }));

  return (
    <section id="statistics" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">إحصائيات وتقارير</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            بيانات وإحصائيات دقيقة عن القطاع الزراعي المصري
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="stats-card">
            <Sprout className="w-10 h-10 text-[#2d5a27] mx-auto mb-3" />
            <div className="stats-number">{(totalProduction / 1000000).toFixed(1)}M</div>
            <div className="stats-label">إجمالي الإنتاج (طن)</div>
            <div className="flex items-center justify-center gap-1 text-green-600 text-sm mt-2">
              <ArrowUpRight className="w-4 h-4" />
              <span>+12% عن العام الماضي</span>
            </div>
          </div>
          
          <div className="stats-card">
            <TrendingUp className="w-10 h-10 text-[#2d5a27] mx-auto mb-3" />
            <div className="stats-number">{(totalArea / 1000000).toFixed(1)}M</div>
            <div className="stats-label">إجمالي المساحة (فدان)</div>
            <div className="flex items-center justify-center gap-1 text-green-600 text-sm mt-2">
              <ArrowUpRight className="w-4 h-4" />
              <span>+8% عن العام الماضي</span>
            </div>
          </div>
          
          <div className="stats-card">
            <div className="w-10 h-10 bg-[#2d5a27]/10 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-[#2d5a27] font-bold">$</span>
            </div>
            <div className="stats-number">{(totalExports / 1000000).toFixed(1)}M</div>
            <div className="stats-label">الصادرات (دولار)</div>
            <div className="flex items-center justify-center gap-1 text-green-600 text-sm mt-2">
              <ArrowUpRight className="w-4 h-4" />
              <span>+15% عن العام الماضي</span>
            </div>
          </div>
        </div>

        {/* Charts Controls */}
        <div className="bg-[#f5f0e8] rounded-2xl p-6 mb-8">
          <div className="flex flex-wrap gap-4 justify-center">
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="agri-input"
            >
              <option value="القمح">القمح</option>
              <option value="الأرز">الأرز</option>
              <option value="الذرة">الذرة</option>
            </select>
            
            <div className="flex gap-2">
              <button
                onClick={() => setChartType('production')}
                className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                  chartType === 'production' 
                    ? 'bg-[#2d5a27] text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                الإنتاج
              </button>
              <button
                onClick={() => setChartType('area')}
                className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                  chartType === 'area' 
                    ? 'bg-[#2d5a27] text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                المساحة
              </button>
              <button
                onClick={() => setChartType('trade')}
                className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                  chartType === 'trade' 
                    ? 'bg-[#2d5a27] text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                التجارة
              </button>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Main Chart */}
          <div className="agri-card p-6">
            <h3 className="text-lg font-bold text-[#2d5a27] mb-4">
              {chartType === 'production' && `إنتاج ${selectedCrop} سنوياً`}
              {chartType === 'area' && `مساحة ${selectedCrop} المزروعة`}
              {chartType === 'trade' && `صادرات وواردات ${selectedCrop}`}
            </h3>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={300}>
                {chartType === 'production' ? (
                  <BarChart data={cropStats}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => value.toLocaleString()} />
                    <Bar dataKey="production_tons" fill="#2d5a27" name="الإنتاج (طن)" />
                  </BarChart>
                ) : chartType === 'area' ? (
                  <LineChart data={cropStats}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => value.toLocaleString()} />
                    <Line type="monotone" dataKey="area_feddans" stroke="#4a7c43" strokeWidth={3} name="المساحة (فدان)" />
                  </LineChart>
                ) : (
                  <BarChart data={cropStats}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => `$${(value / 1000000).toFixed(1)}M`} />
                    <Legend />
                    <Bar dataKey="export_value" fill="#2d5a27" name="الصادرات" />
                    <Bar dataKey="import_value" fill="#d4a574" name="الواردات" />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          {/* Pie Chart */}
          <div className="agri-card p-6">
            <h3 className="text-lg font-bold text-[#2d5a27] mb-4">توزيع الإنتاج الزراعي {latestYear}</h3>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((_entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `${(value / 1000000).toFixed(1)}M طن`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Data Table */}
        <div className="agri-card p-6 mt-8">
          <h3 className="text-lg font-bold text-[#2d5a27] mb-4">بيانات تفصيلية</h3>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>السنة</th>
                  <th>المحصول</th>
                  <th>الإنتاج (طن)</th>
                  <th>المساحة (فدان)</th>
                  <th>الصادرات ($)</th>
                  <th>الواردات ($)</th>
                </tr>
              </thead>
              <tbody>
                {statistics.slice(0, 10).map((stat) => (
                  <tr key={stat.id}>
                    <td>{stat.year}</td>
                    <td>{stat.crop_name}</td>
                    <td>{stat.production_tons.toLocaleString()}</td>
                    <td>{stat.area_feddans.toLocaleString()}</td>
                    <td>${(stat.export_value / 1000000).toFixed(1)}M</td>
                    <td>${(stat.import_value / 1000000).toFixed(1)}M</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
