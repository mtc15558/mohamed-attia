import { useState } from 'react';
import { MapPin, Calendar, TrendingUp, DollarSign, Target, ChevronLeft, X } from 'lucide-react';
import { projects } from '@/data/mockData';
import type { Project } from '@/types';

export function ProjectsSection() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">المشروعات الزراعية القومية</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            أضخم المشروعات الزراعية التي تغير وجه الاقتصاد المصري
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project) => (
            <div 
              key={project.id}
              className="agri-card overflow-hidden group cursor-pointer"
              onClick={() => setSelectedProject(project)}
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4">
                  <span className={`badge ${
                    project.status === 'active' ? 'badge-success' : 
                    project.status === 'completed' ? 'badge-info' : 'badge-warning'
                  }`}>
                    {project.status === 'active' ? 'نشط' : 
                     project.status === 'completed' ? 'مكتمل' : 'مخطط'}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-[#2d5a27] mb-2">{project.name}</h3>
                <p className="text-gray-600 mb-4 line-clamp-2">{project.description}</p>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-[#d4a574]" />
                    <span className="text-gray-600">{project.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Target className="w-4 h-4 text-[#d4a574]" />
                    <span className="text-gray-600">{project.area}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#2d5a27] font-medium">
                    <span>التفاصيل</span>
                    <ChevronLeft className="w-5 h-5" />
                  </div>
                  {project.investment_cost && (
                    <span className="text-[#d4a574] font-bold">{project.investment_cost}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Project Detail Modal */}
        {selectedProject && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
              <div className="relative">
                <img 
                  src={selectedProject.image} 
                  alt={selectedProject.name} 
                  className="w-full h-72 object-cover"
                />
                <button 
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                  <span className={`badge mb-2 ${
                    selectedProject.status === 'active' ? 'badge-success' : 
                    selectedProject.status === 'completed' ? 'badge-info' : 'badge-warning'
                  }`}>
                    {selectedProject.status === 'active' ? 'نشط' : 
                     selectedProject.status === 'completed' ? 'مكتمل' : 'مخطط'}
                  </span>
                  <h2 className="text-3xl font-bold text-white">{selectedProject.name}</h2>
                </div>
              </div>
              
              <div className="p-6">
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">الوصف</h3>
                  <p className="text-gray-600">{selectedProject.description}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-[#f5f0e8] rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Target className="w-5 h-5 text-[#2d5a27]" />
                      <h4 className="font-bold text-[#2d5a27]">الهدف</h4>
                    </div>
                    <p className="text-gray-600">{selectedProject.goal}</p>
                  </div>
                  
                  <div className="bg-[#f5f0e8] rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <MapPin className="w-5 h-5 text-[#2d5a27]" />
                      <h4 className="font-bold text-[#2d5a27]">الموقع</h4>
                    </div>
                    <p className="text-gray-600">{selectedProject.location}</p>
                  </div>
                  
                  <div className="bg-[#f5f0e8] rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <TrendingUp className="w-5 h-5 text-[#2d5a27]" />
                      <h4 className="font-bold text-[#2d5a27]">المساحة</h4>
                    </div>
                    <p className="text-gray-600">{selectedProject.area}</p>
                  </div>
                  
                  <div className="bg-[#f5f0e8] rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Calendar className="w-5 h-5 text-[#2d5a27]" />
                      <h4 className="font-bold text-[#2d5a27]">تاريخ البدء</h4>
                    </div>
                    <p className="text-gray-600">{new Date(selectedProject.start_date).toLocaleDateString('ar-EG')}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">الإنتاج المتوقع</h3>
                  <p className="text-gray-600">{selectedProject.expected_production}</p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">التأثير الاقتصادي</h3>
                  <p className="text-gray-600">{selectedProject.economic_impact}</p>
                </div>
                
                {selectedProject.investment_cost && (
                  <div className="bg-[#2d5a27] text-white rounded-xl p-6">
                    <div className="flex items-center gap-3 mb-2">
                      <DollarSign className="w-6 h-6" />
                      <h4 className="font-bold text-lg">التكلفة الاستثمارية</h4>
                    </div>
                    <p className="text-2xl font-bold">{selectedProject.investment_cost}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
