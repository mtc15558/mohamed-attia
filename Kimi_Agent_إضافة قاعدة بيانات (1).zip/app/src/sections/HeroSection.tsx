import { useEffect, useState } from 'react';
import { ArrowLeft, Sprout, TrendingUp, Users, MapPin } from 'lucide-react';
import { quickStats } from '@/data/mockData';

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="hero-section">
      <div className="max-w-7xl mx-auto px-4 py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className={`text-white transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <Sprout className="w-5 h-5" />
              <span className="text-sm font-medium">البوابة الزراعية المصرية</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              نحو مستقبل زراعي
              <span className="block text-[#d4a574]">مستدام ومزدهر</span>
            </h1>
            
            <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed">
              منصة متكاملة لدعم القطاع الزراعي المصري، نوفر لك كل ما تحتاجه من معلومات 
              وفرص استثمارية وإرشادات زراعية حديثة
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => scrollToSection('sectors')}
                className="bg-white text-[#2d5a27] px-8 py-4 rounded-xl font-bold hover:bg-[#f5f0e8] transition-all flex items-center gap-2"
              >
                استكشف القطاعات
                <ArrowLeft className="w-5 h-5" />
              </button>
              <button 
                onClick={() => scrollToSection('investment')}
                className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-xl font-bold hover:bg-white/10 transition-all"
              >
                فرص الاستثمار
              </button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className={`grid grid-cols-2 gap-4 transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-white border border-white/20">
              <MapPin className="w-10 h-10 mb-4 text-[#d4a574]" />
              <div className="text-3xl font-bold mb-2">{quickStats.totalArea}</div>
              <div className="text-white/80 text-sm">فدان مساحة زراعية</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-white border border-white/20">
              <TrendingUp className="w-10 h-10 mb-4 text-[#d4a574]" />
              <div className="text-3xl font-bold mb-2">{quickStats.productionPercentage}</div>
              <div className="text-white/80 text-sm">نسبة الإنتاج المحلي</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-white border border-white/20">
              <Users className="w-10 h-10 mb-4 text-[#d4a574]" />
              <div className="text-3xl font-bold mb-2">{quickStats.farmersCount}</div>
              <div className="text-white/80 text-sm">مزارع مصري</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-white border border-white/20">
              <Sprout className="w-10 h-10 mb-4 text-[#d4a574]" />
              <div className="text-3xl font-bold mb-2">{quickStats.exportValue}</div>
              <div className="text-white/80 text-sm">دولار صادرات زراعية</div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave Decoration */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path 
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" 
            fill="#f5f0e8"
          />
        </svg>
      </div>
    </section>
  );
}
