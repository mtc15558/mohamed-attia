import { useState } from 'react';
import { Calendar, Eye, ChevronLeft, X, Tag } from 'lucide-react';
import { news } from '@/data/mockData';
import type { News } from '@/types';

const categories = [
  { id: 'all', name: 'الكل' },
  { id: 'إنتاج', name: 'إنتاج' },
  { id: 'أسعار', name: 'أسعار' },
  { id: 'تصدير', name: 'تصدير' },
  { id: 'قرارات', name: 'قرارات' },
  { id: 'معارض', name: 'معارض' }
];

export function NewsSection() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedNews, setSelectedNews] = useState<News | null>(null);

  const filteredNews = selectedCategory === 'all' 
    ? news 
    : news.filter(n => n.category === selectedCategory);

  const featuredNews = news.filter(n => n.is_featured).slice(0, 2);

  return (
    <section id="news" className="py-20 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">أخبار القطاع الزراعي</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            آخر الأخبار والتطورات في القطاع الزراعي المصري
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full font-medium transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-[#2d5a27] text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Featured News */}
        {selectedCategory === 'all' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {featuredNews.map(item => (
              <div 
                key={item.id}
                className="agri-card overflow-hidden cursor-pointer group"
                onClick={() => setSelectedNews(item)}
              >
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <span className="badge badge-info">{item.category}</span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2 line-clamp-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.summary}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {item.published_at}
                    </div>
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      {item.views.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNews.map(item => (
            <div 
              key={item.id}
              className="agri-card overflow-hidden cursor-pointer group"
              onClick={() => setSelectedNews(item)}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4">
                  <span className="badge badge-info">{item.category}</span>
                </div>
              </div>
              <div className="p-5">
                <h3 className="text-base font-bold text-[#2d5a27] mb-2 line-clamp-2">{item.title}</h3>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.summary}</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {item.published_at}
                  </div>
                  <span className="flex items-center gap-1 text-[#2d5a27]">
                    المزيد
                    <ChevronLeft className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* News Detail Modal */}
        {selectedNews && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
              <div className="relative">
                <img 
                  src={selectedNews.image} 
                  alt={selectedNews.title} 
                  className="w-full h-72 object-cover"
                />
                <button 
                  onClick={() => setSelectedNews(null)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                  <span className="badge badge-info mb-2">{selectedNews.category}</span>
                  <h2 className="text-2xl font-bold text-white">{selectedNews.title}</h2>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center gap-6 text-sm text-gray-500 mb-6">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {selectedNews.published_at}
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4" />
                    {selectedNews.author}
                  </div>
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    {selectedNews.views.toLocaleString()} مشاهدة
                  </div>
                </div>
                
                <div className="prose max-w-none">
                  <p className="text-gray-700 leading-relaxed text-lg">{selectedNews.content}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
