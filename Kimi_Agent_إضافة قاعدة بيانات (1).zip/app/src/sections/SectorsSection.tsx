import { useState } from 'react';
import { Wheat, Beef, Egg, Fish, Leaf, Warehouse, ChevronLeft, X } from 'lucide-react';
import { sectors } from '@/data/mockData';
import type { Sector } from '@/types';

const iconMap: Record<string, React.ElementType> = {
  Wheat,
  Beef,
  Egg,
  Fish,
  Leaf,
  Warehouse
};

export function SectorsSection() {
  const [selectedSector, setSelectedSector] = useState<Sector | null>(null);

  return (
    <section id="sectors" className="py-20 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title">القطاعات الزراعية</h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto">
            اكتشف تنوع القطاع الزراعي المصري من زراعة المحاصيل إلى الإنتاج الحيواني والسمكي
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sectors.map((sector, index) => {
            const IconComponent = iconMap[sector.icon] || Wheat;
            
            return (
              <div 
                key={sector.id}
                className="agri-card p-6 cursor-pointer group"
                onClick={() => setSelectedSector(sector)}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 bg-[#2d5a27]/10 rounded-xl flex items-center justify-center group-hover:bg-[#2d5a27] transition-colors">
                    <IconComponent className="w-7 h-7 text-[#2d5a27] group-hover:text-white transition-colors" />
                  </div>
                  <span className="text-[#d4a574] font-bold">0{sector.id}</span>
                </div>
                
                <h3 className="text-xl font-bold text-[#2d5a27] mb-2">{sector.name}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{sector.description}</p>
                
                <div className="flex items-center gap-2 text-[#2d5a27] font-medium group-hover:gap-4 transition-all">
                  <span>المزيد</span>
                  <ChevronLeft className="w-5 h-5" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Sector Detail Modal */}
        {selectedSector && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
              <div className="relative">
                <img 
                  src={selectedSector.image} 
                  alt={selectedSector.name} 
                  className="w-full h-64 object-cover"
                />
                <button 
                  onClick={() => setSelectedSector(null)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                  <h2 className="text-3xl font-bold text-white">{selectedSector.name}</h2>
                </div>
              </div>
              
              <div className="p-6">
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">الوصف</h3>
                  <p className="text-gray-600">{selectedSector.description}</p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">الأهمية</h3>
                  <p className="text-gray-600">{selectedSector.importance}</p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">التحديات</h3>
                  <ul className="space-y-2">
                    {selectedSector.challenges.map((challenge, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-gray-600">
                        <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                        {challenge}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#2d5a27] mb-2">فرص الاستثمار</h3>
                  <ul className="space-y-2">
                    {selectedSector.investment_opportunities.map((opportunity, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-gray-600">
                        <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                        {opportunity}
                      </li>
                    ))}
                  </ul>
                </div>

                {selectedSector.crop_types && selectedSector.crop_types.length > 0 && (
                  <div>
                    <h3 className="text-lg font-bold text-[#2d5a27] mb-4">أنواع المحاصيل</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {selectedSector.crop_types.map(crop => (
                        <div key={crop.id} className="border rounded-lg p-4">
                          <img src={crop.image} alt={crop.name} className="w-full h-32 object-cover rounded-lg mb-2" />
                          <h4 className="font-bold text-[#2d5a27]">{crop.name}</h4>
                          <p className="text-sm text-gray-600">{crop.description}</p>
                          {crop.production_area && (
                            <p className="text-xs text-gray-500 mt-1">منطقة الإنتاج: {crop.production_area}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
