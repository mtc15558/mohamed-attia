import { Sprout, MapPin, Phone, Mail, ChevronLeft } from 'lucide-react';

export function Footer() {
  const quickLinks = [
    { name: 'الصفحة الرئيسية', href: '#' },
    { name: 'القطاعات الزراعية', href: '#sectors' },
    { name: 'المشروعات القومية', href: '#projects' },
    { name: 'فرص الاستثمار', href: '#investment' },
    { name: 'الإحصائيات', href: '#statistics' },
    { name: 'الأخبار', href: '#news' },
    { name: 'الإرشاد الزراعي', href: '#guidance' },
    { name: 'تواصل معنا', href: '#contact' }
  ];

  const services = [
    { name: 'طلب ترخيص زراعي', href: '#' },
    { name: 'استشارات زراعية', href: '#' },
    { name: 'دراسات جدوى', href: '#' },
    { name: 'تدريب مهني', href: '#' },
    { name: 'دعم فني', href: '#' }
  ];

  return (
    <footer className="bg-[#1a3d1a] text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <Sprout className="w-7 h-7 text-[#d4a574]" />
              </div>
              <div>
                <h3 className="text-xl font-bold">القطاع الزراعي</h3>
                <p className="text-white/60 text-sm">جمهورية مصر العربية</p>
              </div>
            </div>
            <p className="text-white/70 text-sm leading-relaxed mb-6">
              منصة متكاملة لدعم القطاع الزراعي المصري، نسعى لتحقيق الأمن الغذائي 
              وتعزيز الاقتصاد الوطني من خلال تطوير الزراعة المصرية.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-white/70">
                <MapPin className="w-4 h-4 text-[#d4a574]" />
                <span>الدقي - الجيزة</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-white/70" dir="ltr">
                <Phone className="w-4 h-4 text-[#d4a574]" />
                <span>02-33350101</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-white/70" dir="ltr">
                <Mail className="w-4 h-4 text-[#d4a574]" />
                <span>info@agri.gov.eg</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">روابط سريعة</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href}
                    className="flex items-center gap-2 text-white/70 hover:text-[#d4a574] transition-colors text-sm"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold mb-6">خدماتنا</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <a 
                    href={service.href}
                    className="flex items-center gap-2 text-white/70 hover:text-[#d4a574] transition-colors text-sm"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    {service.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-lg font-bold mb-6">النشرة البريدية</h4>
            <p className="text-white/70 text-sm mb-4">
              اشترك في نشرتنا البريدية ليصلك آخر الأخبار والتحديثات
            </p>
            <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); }}>
              <input
                type="email"
                placeholder="بريدك الإلكتروني"
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-[#d4a574]"
                dir="ltr"
              />
              <button
                type="submit"
                className="w-full px-4 py-3 bg-[#d4a574] text-[#1a3d1a] font-bold rounded-lg hover:bg-[#c49a64] transition-colors"
              >
                اشترك الآن
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/60 text-sm">
              © 2024 القطاع الزراعي المصري. جميع الحقوق محفوظة.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-white/60 hover:text-[#d4a574] text-sm transition-colors">
                سياسة الخصوصية
              </a>
              <a href="#" className="text-white/60 hover:text-[#d4a574] text-sm transition-colors">
                شروط الاستخدام
              </a>
              <a href="#" className="text-white/60 hover:text-[#d4a574] text-sm transition-colors">
                خريطة الموقع
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
