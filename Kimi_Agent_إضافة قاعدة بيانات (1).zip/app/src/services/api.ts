import { useAuth } from '@/hooks/useAuth';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

interface ApiOptions {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
  requireAuth?: boolean;
}

class ApiService {
  private baseUrl: string;

  constructor() {
    this.baseUrl = API_BASE_URL;
  }

  private getToken(): string | null {
    return localStorage.getItem('token');
  }

  private async request<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
    const { method = 'GET', body, headers = {}, requireAuth = true } = options;

    const requestHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      ...headers
    };

    if (requireAuth) {
      const token = this.getToken();
      if (token) {
        requestHeaders['Authorization'] = `Bearer ${token}`;
      }
    }

    const config: RequestInit = {
      method,
      headers: requestHeaders
    };

    if (body) {
      config.body = JSON.stringify(body);
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Request failed');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Auth
  async login(email: string, password: string) {
    return this.request('/auth/login', {
      method: 'POST',
      body: { email, password },
      requireAuth: false
    });
  }

  async register(userData: {
    name: string;
    email: string;
    password: string;
    role?: string;
    phone?: string;
  }) {
    return this.request('/auth/register', {
      method: 'POST',
      body: userData,
      requireAuth: false
    });
  }

  async getMe() {
    return this.request('/auth/me');
  }

  async updateProfile(data: { name: string; phone: string }) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: data
    });
  }

  // Sectors
  async getSectors() {
    return this.request('/sectors', { requireAuth: false });
  }

  async getSectorById(id: number) {
    return this.request(`/sectors/${id}`, { requireAuth: false });
  }

  // Projects
  async getProjects(params?: { status?: string; featured?: boolean; page?: number; limit?: number }) {
    const queryString = params ? '?' + new URLSearchParams(params as any).toString() : '';
    return this.request(`/projects${queryString}`, { requireAuth: false });
  }

  async getProjectById(id: number) {
    return this.request(`/projects/${id}`, { requireAuth: false });
  }

  // News
  async getNews(params?: { category?: string; featured?: boolean; search?: string; page?: number; limit?: number }) {
    const queryString = params ? '?' + new URLSearchParams(params as any).toString() : '';
    return this.request(`/news${queryString}`, { requireAuth: false });
  }

  async getNewsById(id: number) {
    return this.request(`/news/${id}`, { requireAuth: false });
  }

  // Investments
  async getInvestments(params?: { type?: string; location?: string; search?: string; page?: number; limit?: number }) {
    const queryString = params ? '?' + new URLSearchParams(params as any).toString() : '';
    return this.request(`/investments${queryString}`, { requireAuth: false });
  }

  async getInvestmentById(id: number) {
    return this.request(`/investments/${id}`, { requireAuth: false });
  }

  async getMyInvestments() {
    return this.request('/investments/my/listings');
  }

  async createInvestment(data: any) {
    return this.request('/investments', {
      method: 'POST',
      body: data
    });
  }

  // Statistics
  async getStatistics() {
    return this.request('/statistics', { requireAuth: false });
  }

  async getDashboardStats() {
    return this.request('/statistics/dashboard', { requireAuth: false });
  }

  async getStatisticsByCrop(cropName: string) {
    return this.request(`/statistics/crop/${cropName}`, { requireAuth: false });
  }

  // Comments
  async createComment(data: { project_id?: number; investment_id?: number; news_id?: number; content: string; rating?: number }) {
    return this.request('/comments', {
      method: 'POST',
      body: data
    });
  }

  // Messages
  async getMessages() {
    return this.request('/messages');
  }

  async getConversation(userId: number) {
    return this.request(`/messages/conversation/${userId}`);
  }

  async sendMessage(data: { receiver_id: number; content: string }) {
    return this.request('/messages', {
      method: 'POST',
      body: data
    });
  }

  // Notifications
  async getNotifications() {
    return this.request('/notifications');
  }

  async markNotificationAsRead(id: number) {
    return this.request(`/notifications/${id}/read`, {
      method: 'PUT'
    });
  }

  async markAllNotificationsAsRead() {
    return this.request('/notifications/read-all', {
      method: 'PUT'
    });
  }

  // Users (Admin)
  async getUsers() {
    return this.request('/users');
  }

  async getUserStats() {
    return this.request('/users/stats');
  }
}

export const api = new ApiService();
export default api;
