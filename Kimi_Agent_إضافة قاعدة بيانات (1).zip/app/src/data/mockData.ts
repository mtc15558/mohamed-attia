import type { 
  User, 
  Sector, 
  Project, 
  News, 
  Investment, 
  Statistics, 
  Comment, 
  Message, 
  Notification, 
  Guidance,
  DashboardStats 
} from '@/types';

// Users Data
export const users: User[] = [
  {
    id: 1,
    name: 'المدير العام',
    email: 'admin@agri.gov.eg',
    password: 'admin123',
    role: 'admin',
    phone: '01001234567',
    avatar: 'https://ui-avatars.com/api/?name=Admin&background=2d5a27&color=fff',
    created_at: '2024-01-01',
    is_active: true
  },
  {
    id: 2,
    name: 'أحمد محمود',
    email: 'farmer@example.com',
    password: 'farmer123',
    role: 'farmer',
    phone: '01012345678',
    avatar: 'https://ui-avatars.com/api/?name=Ahmed+M&background=4a7c43&color=fff',
    created_at: '2024-01-15',
    is_active: true
  },
  {
    id: 3,
    name: 'محمد علي',
    email: 'investor@example.com',
    password: 'investor123',
    role: 'investor',
    phone: '01023456789',
    avatar: 'https://ui-avatars.com/api/?name=Mohamed+A&background=d4a574&color=fff',
    created_at: '2024-02-01',
    is_active: true
  },
  {
    id: 4,
    name: 'سارة أحمد',
    email: 'student@example.com',
    password: 'student123',
    role: 'student',
    phone: '01034567890',
    avatar: 'https://ui-avatars.com/api/?name=Sara+A&background=8b7355&color=fff',
    created_at: '2024-02-15',
    is_active: true
  }
];

// Sectors Data
export const sectors: Sector[] = [
  {
    id: 1,
    name: 'الزراعة النباتية',
    name_en: 'Crop Agriculture',
    description: 'تشمل زراعة المحاصيل الأساسية مثل القمح والذرة والأرز والخضروات والفاكهة',
    importance: 'توفر الأمن الغذائي وتدعم الاقتصاد الوطني من خلال الصادرات الزراعية',
    challenges: ['نقص المياه', 'التغيرات المناخية', 'الآفات الزراعية', 'ارتفاع تكاليف الإنتاج'],
    investment_opportunities: ['الصوب الزراعية الحديثة', 'الزراعة العضوية', 'تصنيع المحاصيل'],
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
    icon: 'Wheat',
    crop_types: [
      { id: 1, sector_id: 1, name: 'القمح', description: 'أهم محصول غذائي في مصر', image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400', production_area: 'الدلتا والوادي', season: 'الشتاء' },
      { id: 2, sector_id: 1, name: 'الذرة', description: 'محصول استراتيجي للأعلاف', image: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=400', production_area: 'الوجه البحري', season: 'الصيف' },
      { id: 3, sector_id: 1, name: 'الأرز', description: 'المحصول الرئيسي في الدلتا', image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400', production_area: 'محافظات الدلتا', season: 'الصيف' },
      { id: 4, sector_id: 1, name: 'الخضروات', description: 'تنوع كبير في المحاصيل', image: 'https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?w=400', production_area: 'جميع المحافظات', season: 'على مدار العام' },
      { id: 5, sector_id: 1, name: 'الفاكهة', description: 'من أهم الصادرات الزراعية', image: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=400', production_area: 'الوجه البحري والصعيد', season: 'حسب النوع' }
    ]
  },
  {
    id: 2,
    name: 'الإنتاج الحيواني',
    name_en: 'Animal Production',
    description: 'تربية الماشية وإنتاج اللحوم والألبان',
    importance: 'توفير البروتين الحيواني ودعم الاقتصاد',
    challenges: ['ارتفاع أسعار الأعلاف', 'الأمراض', 'نقض الرعاية البيطرية'],
    investment_opportunities: ['مزارع تربية المواشي', 'مصانع الألبان', 'مجازر حديثة'],
    image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=800',
    icon: 'Beef'
  },
  {
    id: 3,
    name: 'الإنتاج الداجني',
    name_en: 'Poultry Production',
    description: 'تربية الدواجن لإنتاج اللحوم والبيض',
    importance: 'أهم مصدر للبروتين الحيواني بأسعار مقبولة',
    challenges: ['الأمراض مثل أنفلونزا الطيور', 'تكاليف التبريد', 'المنافسة'],
    investment_opportunities: ['مزارع دواجن متكاملة', 'مصانع الأعلاف', 'مجازر دواجن'],
    image: 'https://images.unsplash.com/photo-1548550023-2bdb3c5b9239?w=800',
    icon: 'Egg'
  },
  {
    id: 4,
    name: 'الثروة السمكية',
    name_en: 'Fisheries',
    description: 'تربية الأسماك في المزارع السمكية والصيد من البحار والبحيرات',
    importance: 'توفير البروتين السمكي وزيادة الصادرات',
    challenges: ['تلوث المياه', 'نقص التفريخ', 'الصيد الجائر'],
    investment_opportunities: ['مزارع سمكية', 'أقفاص عائمة', 'مصانع تعليب'],
    image: 'https://images.unsplash.com/photo-1534043464124-3882f3e1e5b9?w=800',
    icon: 'Fish'
  },
  {
    id: 5,
    name: 'الزراعة العضوية',
    name_en: 'Organic Agriculture',
    description: 'زراعة خالية من الكيماويات والمبيدات',
    importance: 'صحة الإنسان وحماية البيئة',
    challenges: ['ارتفاع التكاليف', 'قلة الوعي', 'صعوبة التسويق'],
    investment_opportunities: ['مزارع عضوية', 'أسواق متخصصة', 'تصدير'],
    image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800',
    icon: 'Leaf'
  },
  {
    id: 6,
    name: 'الصوب الزراعية',
    name_en: 'Greenhouses',
    description: 'زراعة محمية داخل صوب زراعية حديثة',
    importance: 'إنتاج على مدار العام مع جودة عالية',
    challenges: ['التكلفة الأولية', 'الطاقة', 'التدريب'],
    investment_opportunities: ['صوب ذكية', 'طاقة شمسية', 'تقنيات IoT'],
    image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800',
    icon: 'Warehouse'
  }
];

// National Projects Data
export const projects: Project[] = [
  {
    id: 1,
    name: 'مشروع الدلتا الجديدة',
    description: 'أضخم مشروع استصلاح زراعي في مصر بمنطقة غرب الدلتا',
    goal: 'استصلاح 2 مليون فدان لسد الفجوة الغذائية',
    area: '2,000,000 فدان',
    expected_production: '15 مليون طن سنوياً',
    economic_impact: 'إنشاء 5 ملايين فرصة عمل',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
    location: 'غرب الدلتا',
    start_date: '2021-01-01',
    status: 'active',
    investment_cost: '300 مليار جنيه'
  },
  {
    id: 2,
    name: 'مشروع توشكى',
    description: 'استصلاح أراضي جنوب الوادي',
    goal: 'استصلاح 1.5 مليون فدان',
    area: '1,500,000 فدان',
    expected_production: '10 مليون طن سنوياً',
    economic_impact: 'تنمية جنوب الوادي',
    image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800',
    location: 'جنوب الوادي',
    start_date: '2020-01-01',
    status: 'active',
    investment_cost: '200 مليار جنيه'
  },
  {
    id: 3,
    name: 'مشروع مستقبل مصر',
    description: 'استصلاح أراضي غرب غرب النوبارية',
    goal: 'استصلاح 3 ملايين فدان',
    area: '3,000,000 فدان',
    expected_production: '25 مليون طن سنوياً',
    economic_impact: 'أكبر مشروع زراعي في العالم',
    image: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?w=800',
    location: 'غرب النوبارية',
    start_date: '2022-01-01',
    status: 'active',
    investment_cost: '500 مليار جنيه'
  },
  {
    id: 4,
    name: 'مشروع 100 ألف صوبة',
    description: 'إنشاء صوب زراعية حديثة',
    goal: 'زيادة الإنتاجية وتحسين الجودة',
    area: '100,000 صوبة',
    expected_production: '5 مليون طن خضروات',
    economic_impact: 'توفير احتياجات السوق المحلي',
    image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800',
    location: 'جميع المحافظات',
    start_date: '2023-01-01',
    status: 'active',
    investment_cost: '100 مليار جنيه'
  },
  {
    id: 5,
    name: 'مشروع استصلاح الأراضي',
    description: 'استصلاح الأراضي الصحراوية',
    goal: 'إضافة 4 ملايين فدان',
    area: '4,000,000 فدان',
    expected_production: '30 مليون طن سنوياً',
    economic_impact: 'تعظيم الاستفادة من الموارد',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
    location: 'جميع أنحاء مصر',
    start_date: '2019-01-01',
    status: 'active',
    investment_cost: '400 مليار جنيه'
  }
];

// News Data
export const news: News[] = [
  {
    id: 1,
    title: 'مصر تحقق الاكتفاء الذاتي من القمح',
    content: 'أعلنت وزارة الزراعة المصرية عن تحقيق نسبة 60% من الاكتفاء الذاتي من القمح هذا العام...',
    summary: 'زيادة إنتاج القمح بنسبة 15% عن العام الماضي',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800',
    category: 'إنتاج',
    author: 'وزارة الزراعة',
    published_at: '2024-06-15',
    views: 15234,
    is_featured: true
  },
  {
    id: 2,
    title: 'افتتاح أكبر مجمع للإنتاج الحيواني في الشرق الأوسط',
    content: 'تم افتتاح مجمع البELLA الزراعي كأكبر مجمع متكامل للإنتاج الحيواني...',
    summary: 'استثمارات تصل إلى 5 مليارات جنيه',
    image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=800',
    category: 'مشروعات',
    author: 'الهيئة العامة للاستثمار',
    published_at: '2024-06-14',
    views: 12345,
    is_featured: true
  },
  {
    id: 3,
    title: 'أسعار الخضروات اليوم في سوق العبور',
    content: 'شهدت أسعار الخضروات استقراراً نسبياً اليوم في سوق العبور...',
    summary: 'انخفاض أسعار الطماطم والخيار',
    image: 'https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?w=800',
    category: 'أسعار',
    author: 'سوق العبور',
    published_at: '2024-06-13',
    views: 9876,
    is_featured: false
  },
  {
    id: 4,
    title: 'مصر تتصدر قائمة الدول المصدرة للحاصلات الزراعية',
    content: 'حققت مصر قفزة كبيرة في الصادرات الزراعية خلال النصف الأول من العام...',
    summary: '6.5 مليون طن صادرات زراعية',
    image: 'https://images.unsplash.com/photo-1592419044706-39796d40f98c?w=800',
    category: 'تصدير',
    author: 'هيئة التنمية الصادرات',
    published_at: '2024-06-12',
    views: 8765,
    is_featured: true
  },
  {
    id: 5,
    title: 'قرار وزاري بشأن مكافحة الآفات الزراعية',
    content: 'أصدر وزير الزراعة قراراً بشأن تطبيق برامج متكاملة لمكافحة الآفات...',
    summary: 'خطة شاملة لمكافحة الآفات',
    image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
    category: 'قرارات',
    author: 'وزارة الزراعة',
    published_at: '2024-06-11',
    views: 7654,
    is_featured: false
  },
  {
    id: 6,
    title: 'معرض القاهرة الدولي للزراعة 2024',
    content: 'ينطلق معرض القاهرة الدولي للزراعة بمشاركة أكثر من 500 شركة...',
    summary: 'أكبر تجمع زراعي في المنطقة',
    image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800',
    category: 'معارض',
    author: 'غرفة الزراعة',
    published_at: '2024-06-10',
    views: 6543,
    is_featured: false
  }
];

// Investment Opportunities Data
export const investments: Investment[] = [
  {
    id: 1,
    title: 'أرض زراعية للبيع - الوادي الجديد',
    description: 'أرض صالحة للزراعة بمساحة 50 فدان مع بئر ماء وكهرباء',
    type: 'land_sale',
    location: 'الوادي الجديد',
    area: '50 فدان',
    price: '5,000,000 جنيه',
    contact_info: '01001234567 - أحمد',
    images: ['https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800'],
    owner_id: 2,
    status: 'available',
    created_at: '2024-06-01'
  },
  {
    id: 2,
    title: 'مزرعة دواجن للإيجار - المنوفية',
    description: 'مزرعة دواجن مجهزة بالكامل مع جميع التراخيص',
    type: 'land_rent',
    location: 'المنوفية',
    area: '10 أفدنة',
    price: '50,000 جنيه/شهر',
    contact_info: '01002345678 - محمد',
    images: ['https://images.unsplash.com/photo-1548550023-2bdb3c5b9239?w=800'],
    owner_id: 2,
    status: 'available',
    created_at: '2024-06-05'
  },
  {
    id: 3,
    title: 'مشروع صوب زراعية - للشراكة',
    description: 'مشروع إنشاء 10 صوب زراعية حديثة',
    type: 'small_project',
    location: 'البحيرة',
    price: '2,000,000 جنيه',
    contact_info: '01003456789 - سارة',
    images: ['https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800'],
    feasibility_study: '/studies/greenhouse.pdf',
    owner_id: 3,
    status: 'available',
    created_at: '2024-06-10'
  },
  {
    id: 4,
    title: 'أرض زراعية - استثمار طويل الأجل',
    description: 'أرض مميزة لزراعة المحاصيل الاستراتيجية',
    type: 'land_sale',
    location: 'كفر الشيخ',
    area: '100 فدان',
    price: '12,000,000 جنيه',
    contact_info: '01004567890 - علي',
    images: ['https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800'],
    owner_id: 2,
    status: 'available',
    created_at: '2024-06-12'
  }
];

// Statistics Data
export const statistics: Statistics[] = [
  { id: 1, year: 2020, crop_name: 'القمح', production_tons: 9000000, area_feddans: 3200000, export_value: 0, import_value: 2500000000 },
  { id: 2, year: 2021, crop_name: 'القمح', production_tons: 9500000, area_feddans: 3300000, export_value: 0, import_value: 2300000000 },
  { id: 3, year: 2022, crop_name: 'القمح', production_tons: 10000000, area_feddans: 3400000, export_value: 0, import_value: 2000000000 },
  { id: 4, year: 2023, crop_name: 'القمح', production_tons: 11000000, area_feddans: 3600000, export_value: 50000000, import_value: 1800000000 },
  { id: 5, year: 2024, crop_name: 'القمح', production_tons: 12000000, area_feddans: 3800000, export_value: 100000000, import_value: 1500000000 },
  { id: 6, year: 2020, crop_name: 'الأرز', production_tons: 6000000, area_feddans: 2800000, export_value: 200000000, import_value: 0 },
  { id: 7, year: 2021, crop_name: 'الأرز', production_tons: 6200000, area_feddans: 2900000, export_value: 250000000, import_value: 0 },
  { id: 8, year: 2022, crop_name: 'الأرز', production_tons: 6500000, area_feddans: 3000000, export_value: 300000000, import_value: 0 },
  { id: 9, year: 2023, crop_name: 'الأرز', production_tons: 6800000, area_feddans: 3100000, export_value: 350000000, import_value: 0 },
  { id: 10, year: 2024, crop_name: 'الأرز', production_tons: 7000000, area_feddans: 3200000, export_value: 400000000, import_value: 0 },
  { id: 11, year: 2020, crop_name: 'الذرة', production_tons: 8000000, area_feddans: 2500000, export_value: 100000000, import_value: 500000000 },
  { id: 12, year: 2021, crop_name: 'الذرة', production_tons: 8500000, area_feddans: 2600000, export_value: 120000000, import_value: 450000000 },
  { id: 13, year: 2022, crop_name: 'الذرة', production_tons: 9000000, area_feddans: 2700000, export_value: 150000000, import_value: 400000000 },
  { id: 14, year: 2023, crop_name: 'الذرة', production_tons: 9500000, area_feddans: 2800000, export_value: 180000000, import_value: 350000000 },
  { id: 15, year: 2024, crop_name: 'الذرة', production_tons: 10000000, area_feddans: 2900000, export_value: 200000000, import_value: 300000000 }
];

// Comments Data
export const comments: Comment[] = [
  {
    id: 1,
    user_id: 3,
    project_id: 1,
    content: 'مشروع رائع وواعد للاستثمار',
    rating: 5,
    created_at: '2024-06-10',
    user: users[2],
    is_approved: true
  },
  {
    id: 2,
    user_id: 4,
    investment_id: 1,
    content: 'هل الأرض مسجلة في الشهر العقاري؟',
    rating: 4,
    created_at: '2024-06-12',
    user: users[3],
    is_approved: true
  }
];

// Messages Data
export const messages: Message[] = [
  {
    id: 1,
    sender_id: 3,
    receiver_id: 2,
    content: 'مرحباً، أريد الاستفسار عن الأرض المعروضة',
    created_at: '2024-06-15T10:00:00',
    is_read: false,
    sender: users[2],
    receiver: users[1]
  },
  {
    id: 2,
    sender_id: 2,
    receiver_id: 3,
    content: 'أهلاً بك، تفضل بالسؤال عن أي شيء',
    created_at: '2024-06-15T11:00:00',
    is_read: true,
    sender: users[1],
    receiver: users[2]
  }
];

// Notifications Data
export const notifications: Notification[] = [
  {
    id: 1,
    user_id: 2,
    title: 'تعليق جديد',
    message: 'قام محمد علي بالتعليق على إعلانك',
    type: 'info',
    created_at: '2024-06-15T10:00:00',
    is_read: false,
    link: '/investments/1'
  },
  {
    id: 2,
    user_id: 2,
    title: 'تم قبول تعليقك',
    message: 'تم قبول تعليقك على مشروع الدلتا الجديدة',
    type: 'success',
    created_at: '2024-06-14T09:00:00',
    is_read: true,
    link: '/projects/1'
  }
];

// Guidance Data
export const guidance: Guidance[] = [
  {
    id: 1,
    category: 'irrigation',
    title: 'نظم الري الحديثة',
    content: 'تعتبر نظم الري الحديثة من أهم عوامل ترشيد استهلاك المياه في الزراعة...',
    image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
    video_url: 'https://www.youtube.com/watch?v=example1'
  },
  {
    id: 2,
    category: 'pest_control',
    title: 'مكافحة الآفات المتكاملة',
    content: 'تعتمد المكافحة المتكاملة على استخدام عدة طرق معاً...',
    image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
    pdf_url: '/guides/pest-control.pdf'
  },
  {
    id: 3,
    category: 'fertilization',
    title: 'التسميد العقلاني',
    content: 'التسميد العقلاني يعتمد على تحليل التربة وتحديد الاحتياجات الفعلية...',
    image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800'
  },
  {
    id: 4,
    category: 'soil',
    title: 'تحسين خصوبة التربة',
    content: 'تحسين خصوبة التربة يبدأ بفهم تركيبها وخصائصها...',
    image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800'
  }
];

// Dashboard Stats
export const dashboardStats: DashboardStats = {
  totalUsers: 1250,
  totalProjects: 15,
  totalInvestments: 45,
  totalNews: 120,
  pendingComments: 8,
  monthlyStats: [
    { month: 'يناير', users: 80, projects: 2 },
    { month: 'فبراير', users: 95, projects: 1 },
    { month: 'مارس', users: 110, projects: 3 },
    { month: 'أبريل', users: 125, projects: 2 },
    { month: 'مايو', users: 140, projects: 2 },
    { month: 'يونيو', users: 160, projects: 3 }
  ]
};

// Quick Stats for Homepage
export const quickStats = {
  totalArea: '9.5 مليون',
  productionPercentage: '85%',
  farmersCount: '5.2 مليون',
  exportValue: '6.5 مليار'
};
