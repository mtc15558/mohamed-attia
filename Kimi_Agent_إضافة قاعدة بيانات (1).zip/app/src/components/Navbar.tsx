import { useState, useEffect } from 'react';
import { Sprout, Menu, X, User, Bell, LogOut, ChevronDown } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { LoginModal } from './auth/LoginModal';
import { RegisterModal } from './auth/RegisterModal';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const { showToast } = useToast();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    showToast('تم تسجيل الخروج بنجاح', 'success');
    setIsUserMenuOpen(false);
  };

  const navLinks = [
    { name: 'الرئيسية', href: '#' },
    { name: 'القطاعات', href: '#sectors' },
    { name: 'المشروعات', href: '#projects' },
    { name: 'الاستثمار', href: '#investment' },
    { name: 'الإحصائيات', href: '#statistics' },
    { name: 'الأخبار', href: '#news' },
    { name: 'الإرشاد', href: '#guidance' },
    { name: 'تواصل معنا', href: '#contact' }
  ];

  const scrollToSection = (href: string) => {
    if (href === '#') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white shadow-lg py-3' 
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); scrollToSection('#'); }}
              className="flex items-center gap-3"
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isScrolled ? 'bg-[#2d5a27]' : 'bg-white/20 backdrop-blur-sm'
              }`}>
                <Sprout className={`w-6 h-6 ${isScrolled ? 'text-white' : 'text-white'}`} />
              </div>
              <div className={`hidden sm:block ${isScrolled ? 'text-[#2d5a27]' : 'text-white'}`}>
                <h1 className="text-lg font-bold leading-tight">القطاع الزراعي</h1>
                <p className="text-xs opacity-70">جمهورية مصر العربية</p>
              </div>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isScrolled 
                      ? 'text-gray-700 hover:text-[#2d5a27] hover:bg-[#2d5a27]/10' 
                      : 'text-white/90 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* Auth Buttons */}
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <div className="relative">
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                      isScrolled 
                        ? 'hover:bg-gray-100' 
                        : 'hover:bg-white/10'
                    }`}
                  >
                    <img 
                      src={user?.avatar} 
                      alt={user?.name} 
                      className="w-8 h-8 rounded-full"
                    />
                    <span className={`hidden sm:block text-sm font-medium ${
                      isScrolled ? 'text-gray-700' : 'text-white'
                    }`}>
                      {user?.name?.split(' ')[0]}
                    </span>
                    <ChevronDown className={`w-4 h-4 ${isScrolled ? 'text-gray-500' : 'text-white/70'}`} />
                  </button>

                  {isUserMenuOpen && (
                    <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 py-2 animate-fadeIn">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <p className="font-medium text-[#2d5a27]">{user?.name}</p>
                        <p className="text-sm text-gray-500">{user?.email}</p>
                        <span className="inline-block mt-2 px-2 py-1 bg-[#2d5a27]/10 text-[#2d5a27] text-xs rounded-full">
                          {user?.role === 'admin' ? 'مدير' : 
                           user?.role === 'farmer' ? 'مزارع' : 
                           user?.role === 'investor' ? 'مستثمر' : 'طالب'}
                        </span>
                      </div>
                      <a 
                        href={user?.role === 'admin' ? '/admin' : user?.role === 'farmer' ? '/farmer' : '/investor'}
                        className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50"
                      >
                        <User className="w-5 h-5" />
                        لوحة التحكم
                      </a>
                      <a 
                        href="#"
                        className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50"
                      >
                        <Bell className="w-5 h-5" />
                        التنبيهات
                      </a>
                      <div className="border-t border-gray-100 mt-2 pt-2">
                        <button 
                          onClick={handleLogout}
                          className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 w-full"
                        >
                          <LogOut className="w-5 h-5" />
                          تسجيل الخروج
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsLoginOpen(true)}
                    className={`hidden sm:block px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isScrolled 
                        ? 'text-[#2d5a27] hover:bg-[#2d5a27]/10' 
                        : 'text-white hover:bg-white/10'
                    }`}
                  >
                    تسجيل الدخول
                  </button>
                  <button
                    onClick={() => setIsRegisterOpen(true)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isScrolled 
                        ? 'bg-[#2d5a27] text-white hover:bg-[#1a3d1a]' 
                        : 'bg-white text-[#2d5a27] hover:bg-gray-100'
                    }`}
                  >
                    إنشاء حساب
                  </button>
                </div>
              )}

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={`lg:hidden p-2 rounded-lg transition-colors ${
                  isScrolled 
                    ? 'hover:bg-gray-100' 
                    : 'hover:bg-white/10'
                }`}
              >
                {isMobileMenuOpen ? (
                  <X className={`w-6 h-6 ${isScrolled ? 'text-gray-700' : 'text-white'}`} />
                ) : (
                  <Menu className={`w-6 h-6 ${isScrolled ? 'text-gray-700' : 'text-white'}`} />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="lg:hidden mt-4 bg-white rounded-2xl shadow-xl p-4 animate-fadeIn">
              <div className="space-y-2">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                    className="block px-4 py-3 rounded-lg text-gray-700 hover:bg-[#2d5a27]/10 hover:text-[#2d5a27] transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
              </div>
              {!isAuthenticated && (
                <div className="mt-4 pt-4 border-t border-gray-100 space-y-2">
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      setIsLoginOpen(true);
                    }}
                    className="w-full px-4 py-3 text-[#2d5a27] font-medium hover:bg-[#2d5a27]/10 rounded-lg"
                  >
                    تسجيل الدخول
                  </button>
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      setIsRegisterOpen(true);
                    }}
                    className="w-full px-4 py-3 bg-[#2d5a27] text-white font-medium rounded-lg hover:bg-[#1a3d1a]"
                  >
                    إنشاء حساب
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </nav>

      {/* Auth Modals */}
      <LoginModal 
        isOpen={isLoginOpen} 
        onClose={() => setIsLoginOpen(false)}
        onSwitchToRegister={() => {
          setIsLoginOpen(false);
          setIsRegisterOpen(true);
        }}
      />
      <RegisterModal 
        isOpen={isRegisterOpen} 
        onClose={() => setIsRegisterOpen(false)}
        onSwitchToLogin={() => {
          setIsRegisterOpen(false);
          setIsLoginOpen(true);
        }}
      />
    </>
  );
}
