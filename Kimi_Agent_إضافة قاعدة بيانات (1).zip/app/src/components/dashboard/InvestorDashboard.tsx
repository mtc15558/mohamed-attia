import { useState } from 'react';
import { 
  TrendingUp, 
  MessageSquare, 
  Bell, 
  Settings, 
  LogOut,
  Search,
  Heart,
  MapPin,
  Phone
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { investments, messages, notifications, projects } from '@/data/mockData';

export function InvestorDashboard() {
  const [activeTab, setActiveTab] = useState('opportunities');
  const [favorites, setFavorites] = useState<number[]>([]);
  const { user, logout } = useAuth();
  const { showToast } = useToast();

  const handleLogout = () => {
    logout();
    showToast('تم تسجيل الخروج بنجاح', 'success');
  };

  const toggleFavorite = (id: number) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(f => f !== id));
      showToast('تم الإزالة من المفضلة', 'info');
    } else {
      setFavorites([...favorites, id]);
      showToast('تم الإضافة للمفضلة', 'success');
    }
  };

  const myMessages = messages.filter(m => m.receiver_id === user?.id || m.sender_id === user?.id);
  const myNotifications = notifications.filter(n => n.user_id === user?.id);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <img src={user?.avatar} alt={user?.name} className="w-12 h-12 rounded-full" />
            <div>
              <h1 className="text-xl font-bold text-[#2d5a27]">{user?.name}</h1>
              <p className="text-sm text-gray-600">مستثمر</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-red-600 hover:bg-red-50 px-4 py-2 rounded-lg"
          >
            <LogOut size={20} />
            تسجيل الخروج
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <nav className="agri-card p-4 space-y-2">
              <button
                onClick={() => setActiveTab('opportunities')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'opportunities' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Search size={20} />
                <span>فرص الاستثمار</span>
              </button>
              <button
                onClick={() => setActiveTab('projects')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'projects' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <TrendingUp size={20} />
                <span>المشروعات القومية</span>
              </button>
              <button
                onClick={() => setActiveTab('favorites')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'favorites' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Heart size={20} />
                <span>المفضلة</span>
                {favorites.length > 0 && (
                  <span className="mr-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {favorites.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('messages')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'messages' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <MessageSquare size={20} />
                <span>الرسائل</span>
                {myMessages.filter(m => !m.is_read).length > 0 && (
                  <span className="mr-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {myMessages.filter(m => !m.is_read).length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('notifications')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'notifications' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Bell size={20} />
                <span>التنبيهات</span>
                {myNotifications.filter(n => !n.is_read).length > 0 && (
                  <span className="mr-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {myNotifications.filter(n => !n.is_read).length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'settings' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Settings size={20} />
                <span>الإعدادات</span>
              </button>
            </nav>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {activeTab === 'opportunities' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-[#2d5a27]">فرص الاستثمار المتاحة</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {investments.filter(i => i.status === 'available').map(investment => (
                    <div key={investment.id} className="agri-card p-4">
                      <div className="relative">
                        <img src={investment.images[0]} alt={investment.title} className="w-full h-48 object-cover rounded-lg mb-3" />
                        <button 
                          onClick={() => toggleFavorite(investment.id)}
                          className="absolute top-2 left-2 p-2 bg-white rounded-full shadow-md hover:shadow-lg"
                        >
                          <Heart 
                            size={20} 
                            className={favorites.includes(investment.id) ? 'fill-red-500 text-red-500' : 'text-gray-400'} 
                          />
                        </button>
                      </div>
                      <h3 className="font-bold text-[#2d5a27] mb-2">{investment.title}</h3>
                      <p className="text-sm text-gray-600 mb-2 line-clamp-2">{investment.description}</p>
                      <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                        <MapPin size={16} />
                        {investment.location}
                      </div>
                      {investment.area && (
                        <div className="text-sm text-gray-600 mb-2">المساحة: {investment.area}</div>
                      )}
                      <div className="flex justify-between items-center mb-3">
                        <span className="font-bold text-lg text-[#d4a574]">{investment.price}</span>
                        <span className="badge badge-success">متاح</span>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => showToast('سيتم التواصل مع المعلن', 'info')}
                          className="flex-1 agri-button flex items-center justify-center gap-2"
                        >
                          <Phone size={16} />
                          تواصل
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'projects' && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-[#2d5a27]">المشروعات القومية</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {projects.map(project => (
                    <div key={project.id} className="agri-card p-4">
                      <img src={project.image} alt={project.name} className="w-full h-48 object-cover rounded-lg mb-3" />
                      <h3 className="font-bold text-[#2d5a27] mb-2">{project.name}</h3>
                      <p className="text-sm text-gray-600 mb-3">{project.description}</p>
                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">المساحة:</span>
                          <span className="font-medium">{project.area}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">الإنتاج المتوقع:</span>
                          <span className="font-medium">{project.expected_production}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">التكلفة:</span>
                          <span className="font-medium">{project.investment_cost}</span>
                        </div>
                      </div>
                      <button 
                        onClick={() => showToast('سيتم توجيهك لصفحة التفاصيل', 'info')}
                        className="w-full agri-button"
                      >
                        عرض التفاصيل
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'favorites' && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-[#2d5a27]">المفضلة</h2>
                {favorites.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {investments.filter(i => favorites.includes(i.id)).map(investment => (
                      <div key={investment.id} className="agri-card p-4">
                        <img src={investment.images[0]} alt={investment.title} className="w-full h-48 object-cover rounded-lg mb-3" />
                        <h3 className="font-bold text-[#2d5a27] mb-2">{investment.title}</h3>
                        <p className="text-sm text-gray-600 mb-2">{investment.location}</p>
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-[#d4a574]">{investment.price}</span>
                          <button 
                            onClick={() => toggleFavorite(investment.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                          >
                            <Heart size={20} className="fill-red-500" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-white rounded-lg">
                    <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">لا توجد عناصر في المفضلة</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'messages' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">الرسائل</h2>
                <div className="space-y-4">
                  {myMessages.length > 0 ? myMessages.map(message => (
                    <div key={message.id} className={`p-4 rounded-lg ${message.is_read ? 'bg-gray-50' : 'bg-blue-50 border-r-4 border-blue-500'}`}>
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-3">
                          <img src={message.sender?.avatar} alt={message.sender?.name} className="w-10 h-10 rounded-full" />
                          <div>
                            <p className="font-medium">{message.sender?.name}</p>
                            <p className="text-xs text-gray-500">{new Date(message.created_at).toLocaleString('ar-EG')}</p>
                          </div>
                        </div>
                        {!message.is_read && <span className="badge badge-info">جديد</span>}
                      </div>
                      <p className="text-gray-700 mr-13">{message.content}</p>
                    </div>
                  )) : (
                    <p className="text-center text-gray-500 py-8">لا توجد رسائل</p>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">التنبيهات</h2>
                <div className="space-y-3">
                  {myNotifications.length > 0 ? myNotifications.map(notification => (
                    <div key={notification.id} className={`p-4 rounded-lg ${notification.is_read ? 'bg-gray-50' : 'bg-yellow-50 border-r-4 border-yellow-500'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">{notification.title}</p>
                          <p className="text-sm text-gray-600">{notification.message}</p>
                          <p className="text-xs text-gray-500 mt-1">{new Date(notification.created_at).toLocaleString('ar-EG')}</p>
                        </div>
                        {!notification.is_read && <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>}
                      </div>
                    </div>
                  )) : (
                    <p className="text-center text-gray-500 py-8">لا توجد تنبيهات</p>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">الإعدادات</h2>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
                    <input type="text" defaultValue={user?.name} className="agri-input" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                    <input type="email" defaultValue={user?.email} className="agri-input" dir="ltr" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                    <input type="tel" defaultValue={user?.phone} className="agri-input" dir="ltr" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">مجالات الاستثمار المفضلة</label>
                    <select className="agri-input" multiple>
                      <option>الأراضي الزراعية</option>
                      <option>المشروعات الداجنية</option>
                      <option>الثروة السمكية</option>
                      <option>الصوب الزراعية</option>
                    </select>
                  </div>
                  <button 
                    type="button"
                    onClick={() => showToast('تم حفظ التغييرات', 'success')}
                    className="agri-button"
                  >
                    حفظ التغييرات
                  </button>
                </form>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
