import { useState } from 'react';
import { 
  Sprout, 
  MessageSquare, 
  Bell, 
  Settings, 
  LogOut,
  Plus,
  Edit,
  Eye,
  TrendingUp
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { investments, messages, notifications } from '@/data/mockData';

export function FarmerDashboard() {
  const [activeTab, setActiveTab] = useState('listings');
  const { user, logout } = useAuth();
  const { showToast } = useToast();

  const handleLogout = () => {
    logout();
    showToast('تم تسجيل الخروج بنجاح', 'success');
  };

  const myInvestments = investments.filter(i => i.owner_id === user?.id);
  const myMessages = messages.filter(m => m.receiver_id === user?.id || m.sender_id === user?.id);
  const myNotifications = notifications.filter(n => n.user_id === user?.id);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <img src={user?.avatar} alt={user?.name} className="w-12 h-12 rounded-full" />
            <div>
              <h1 className="text-xl font-bold text-[#2d5a27]">{user?.name}</h1>
              <p className="text-sm text-gray-600">مزارع</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-red-600 hover:bg-red-50 px-4 py-2 rounded-lg"
          >
            <LogOut size={20} />
            تسجيل الخروج
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <nav className="agri-card p-4 space-y-2">
              <button
                onClick={() => setActiveTab('listings')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'listings' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Sprout size={20} />
                <span>إعلاناتي</span>
              </button>
              <button
                onClick={() => setActiveTab('messages')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'messages' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <MessageSquare size={20} />
                <span>الرسائل</span>
                {myMessages.filter(m => !m.is_read).length > 0 && (
                  <span className="mr-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {myMessages.filter(m => !m.is_read).length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('notifications')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'notifications' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Bell size={20} />
                <span>التنبيهات</span>
                {myNotifications.filter(n => !n.is_read).length > 0 && (
                  <span className="mr-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {myNotifications.filter(n => !n.is_read).length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('stats')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'stats' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <TrendingUp size={20} />
                <span>إحصائيات</span>
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'settings' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Settings size={20} />
                <span>الإعدادات</span>
              </button>
            </nav>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {activeTab === 'listings' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-[#2d5a27]">إعلاناتي</h2>
                  <button 
                    onClick={() => showToast('سيتم إضافة إعلان جديد', 'info')}
                    className="agri-button flex items-center gap-2"
                  >
                    <Plus size={18} />
                    إضافة إعلان
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {myInvestments.length > 0 ? myInvestments.map(investment => (
                    <div key={investment.id} className="agri-card p-4">
                      <img src={investment.images[0]} alt={investment.title} className="w-full h-40 object-cover rounded-lg mb-3" />
                      <h3 className="font-bold text-[#2d5a27] mb-2">{investment.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">{investment.location}</p>
                      <div className="flex justify-between items-center mb-3">
                        <span className="font-bold text-[#d4a574]">{investment.price}</span>
                        <span className={`badge ${investment.status === 'available' ? 'badge-success' : 'badge-warning'}`}>
                          {investment.status === 'available' ? 'متاح' : 'محجوز'}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2">
                          <Eye size={16} />
                          عرض
                        </button>
                        <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
                          <Edit size={16} />
                        </button>
                      </div>
                    </div>
                  )) : (
                    <div className="col-span-2 text-center py-12 bg-white rounded-lg">
                      <Sprout className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500">لا توجد إعلانات حالياً</p>
                      <button 
                        onClick={() => showToast('سيتم إضافة إعلان جديد', 'info')}
                        className="mt-4 text-[#2d5a27] hover:underline"
                      >
                        أضف إعلانك الأول
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'messages' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">الرسائل</h2>
                <div className="space-y-4">
                  {myMessages.length > 0 ? myMessages.map(message => (
                    <div key={message.id} className={`p-4 rounded-lg ${message.is_read ? 'bg-gray-50' : 'bg-blue-50 border-r-4 border-blue-500'}`}>
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-3">
                          <img src={message.sender?.avatar} alt={message.sender?.name} className="w-10 h-10 rounded-full" />
                          <div>
                            <p className="font-medium">{message.sender?.name}</p>
                            <p className="text-xs text-gray-500">{new Date(message.created_at).toLocaleString('ar-EG')}</p>
                          </div>
                        </div>
                        {!message.is_read && <span className="badge badge-info">جديد</span>}
                      </div>
                      <p className="text-gray-700 mr-13">{message.content}</p>
                    </div>
                  )) : (
                    <p className="text-center text-gray-500 py-8">لا توجد رسائل</p>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">التنبيهات</h2>
                <div className="space-y-3">
                  {myNotifications.length > 0 ? myNotifications.map(notification => (
                    <div key={notification.id} className={`p-4 rounded-lg ${notification.is_read ? 'bg-gray-50' : 'bg-yellow-50 border-r-4 border-yellow-500'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">{notification.title}</p>
                          <p className="text-sm text-gray-600">{notification.message}</p>
                          <p className="text-xs text-gray-500 mt-1">{new Date(notification.created_at).toLocaleString('ar-EG')}</p>
                        </div>
                        {!notification.is_read && <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>}
                      </div>
                    </div>
                  )) : (
                    <p className="text-center text-gray-500 py-8">لا توجد تنبيهات</p>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'stats' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">إحصائياتي</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="stats-card">
                    <div className="stats-number">{myInvestments.length}</div>
                    <div className="stats-label">إعلاناتي</div>
                  </div>
                  <div className="stats-card">
                    <div className="stats-number">{myMessages.filter(m => m.receiver_id === user?.id).length}</div>
                    <div className="stats-label">رسائل مستلمة</div>
                  </div>
                  <div className="stats-card">
                    <div className="stats-number">{myNotifications.filter(n => !n.is_read).length}</div>
                    <div className="stats-label">تنبيهات جديدة</div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="agri-card p-6">
                <h2 className="text-xl font-bold text-[#2d5a27] mb-4">الإعدادات</h2>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
                    <input type="text" defaultValue={user?.name} className="agri-input" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                    <input type="email" defaultValue={user?.email} className="agri-input" dir="ltr" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                    <input type="tel" defaultValue={user?.phone} className="agri-input" dir="ltr" />
                  </div>
                  <button 
                    type="button"
                    onClick={() => showToast('تم حفظ التغييرات', 'success')}
                    className="agri-button"
                  >
                    حفظ التغييرات
                  </button>
                </form>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
