import { useState } from 'react';
import { 
  Users, 
  FolderOpen, 
  TrendingUp, 
  Newspaper, 
  MessageSquare, 
  BarChart3,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  LogOut
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { dashboardStats, users, news, comments, projects } from '@/data/mockData';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

type TabType = 'overview' | 'users' | 'news' | 'comments' | 'projects';

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const { logout } = useAuth();
  const { showToast } = useToast();

  const handleLogout = () => {
    logout();
    showToast('تم تسجيل الخروج بنجاح', 'success');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="stats-card">
          <Users className="w-8 h-8 text-[#2d5a27] mx-auto mb-2" />
          <div className="stats-number">{dashboardStats.totalUsers.toLocaleString()}</div>
          <div className="stats-label">إجمالي المستخدمين</div>
        </div>
        <div className="stats-card">
          <FolderOpen className="w-8 h-8 text-[#2d5a27] mx-auto mb-2" />
          <div className="stats-number">{dashboardStats.totalProjects}</div>
          <div className="stats-label">المشروعات</div>
        </div>
        <div className="stats-card">
          <TrendingUp className="w-8 h-8 text-[#2d5a27] mx-auto mb-2" />
          <div className="stats-number">{dashboardStats.totalInvestments}</div>
          <div className="stats-label">فرص الاستثمار</div>
        </div>
        <div className="stats-card">
          <Newspaper className="w-8 h-8 text-[#2d5a27] mx-auto mb-2" />
          <div className="stats-number">{dashboardStats.totalNews}</div>
          <div className="stats-label">الأخبار</div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="agri-card p-6">
          <h3 className="text-lg font-bold text-[#2d5a27] mb-4">نمو المستخدمين والمشروعات</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dashboardStats.monthlyStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="users" fill="#2d5a27" name="المستخدمين" />
                <Bar dataKey="projects" fill="#d4a574" name="المشروعات" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="agri-card p-6">
          <h3 className="text-lg font-bold text-[#2d5a27] mb-4">النشاط الشهري</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={dashboardStats.monthlyStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="users" stroke="#2d5a27" strokeWidth={2} />
                <Line type="monotone" dataKey="projects" stroke="#d4a574" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Pending Comments */}
      <div className="agri-card p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-[#2d5a27]">تعليقات بانتظار الموافقة</h3>
          <span className="badge badge-warning">{dashboardStats.pendingComments} جديد</span>
        </div>
        <div className="space-y-3">
          {comments.filter(c => !c.is_approved).slice(0, 3).map(comment => (
            <div key={comment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">{comment.user?.name}</p>
                <p className="text-sm text-gray-600 truncate max-w-md">{comment.content}</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => showToast('تمت الموافقة على التعليق', 'success')}
                  className="p-2 text-green-600 hover:bg-green-50 rounded-lg"
                >
                  <CheckCircle size={20} />
                </button>
                <button 
                  onClick={() => showToast('تم رفض التعليق', 'error')}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <XCircle size={20} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="agri-card p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-[#2d5a27]">إدارة المستخدمين</h3>
        <button className="agri-button flex items-center gap-2">
          <Plus size={18} />
          إضافة مستخدم
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              <th>المستخدم</th>
              <th>البريد الإلكتروني</th>
              <th>النوع</th>
              <th>الحالة</th>
              <th>الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td className="flex items-center gap-3">
                  <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                  <span>{user.name}</span>
                </td>
                <td>{user.email}</td>
                <td>
                  <span className={`badge ${
                    user.role === 'admin' ? 'badge-info' : 
                    user.role === 'farmer' ? 'badge-success' : 
                    user.role === 'investor' ? 'badge-warning' : 'badge-info'
                  }}`}>
                    {user.role === 'admin' ? 'مدير' : 
                     user.role === 'farmer' ? 'مزارع' : 
                     user.role === 'investor' ? 'مستثمر' : 'طالب'}
                  </span>
                </td>
                <td>
                  <span className={`badge ${user.is_active ? 'badge-success' : 'badge-warning'}`}>
                    {user.is_active ? 'نشط' : 'معطل'}
                  </span>
                </td>
                <td>
                  <div className="flex gap-2">
                    <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                      <Edit size={18} />
                    </button>
                    <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderNews = () => (
    <div className="agri-card p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-[#2d5a27]">إدارة الأخبار</h3>
        <button className="agri-button flex items-center gap-2">
          <Plus size={18} />
          إضافة خبر
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {news.map(item => (
          <div key={item.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <img src={item.image} alt={item.title} className="w-full h-32 object-cover rounded-lg mb-3" />
            <h4 className="font-bold text-[#2d5a27] mb-2">{item.title}</h4>
            <p className="text-sm text-gray-600 mb-3">{item.summary}</p>
            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-500">{item.published_at}</span>
              <div className="flex gap-2">
                <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                  <Edit size={16} />
                </button>
                <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderComments = () => (
    <div className="agri-card p-6">
      <h3 className="text-lg font-bold text-[#2d5a27] mb-4">إدارة التعليقات</h3>
      <div className="space-y-4">
        {comments.map(comment => (
          <div key={comment.id} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-3">
                <img src={comment.user?.avatar} alt={comment.user?.name} className="w-10 h-10 rounded-full" />
                <div>
                  <p className="font-medium">{comment.user?.name}</p>
                  <p className="text-sm text-gray-500">{comment.created_at}</p>
                </div>
              </div>
              <span className={`badge ${comment.is_approved ? 'badge-success' : 'badge-warning'}`}>
                {comment.is_approved ? 'معتمد' : 'بانتظار الموافقة'}
              </span>
            </div>
            <p className="text-gray-700 mb-3">{comment.content}</p>
            <div className="flex gap-2">
              {!comment.is_approved && (
                <button 
                  onClick={() => showToast('تمت الموافقة على التعليق', 'success')}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  موافقة
                </button>
              )}
              <button 
                onClick={() => showToast('تم حذف التعليق', 'success')}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderProjects = () => (
    <div className="agri-card p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-[#2d5a27]">إدارة المشروعات</h3>
        <button className="agri-button flex items-center gap-2">
          <Plus size={18} />
          إضافة مشروع
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map(project => (
          <div key={project.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <img src={project.image} alt={project.name} className="w-full h-40 object-cover rounded-lg mb-3" />
            <h4 className="font-bold text-[#2d5a27] mb-2">{project.name}</h4>
            <p className="text-sm text-gray-600 mb-2">{project.description}</p>
            <div className="flex flex-wrap gap-2 mb-3">
              <span className="badge badge-info">{project.area}</span>
              <span className={`badge ${
                project.status === 'active' ? 'badge-success' : 
                project.status === 'completed' ? 'badge-info' : 'badge-warning'
              }`}>
                {project.status === 'active' ? 'نشط' : 
                 project.status === 'completed' ? 'مكتمل' : 'مخطط'}
              </span>
            </div>
            <div className="flex gap-2">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2">
                <Edit size={16} />
                تعديل
              </button>
              <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-[#2d5a27]">لوحة تحكم المدير</h1>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-red-600 hover:bg-red-50 px-4 py-2 rounded-lg"
          >
            <LogOut size={20} />
            تسجيل الخروج
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <nav className="agri-card p-4 space-y-2">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'overview' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <BarChart3 size={20} />
                <span>نظرة عامة</span>
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'users' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Users size={20} />
                <span>المستخدمين</span>
              </button>
              <button
                onClick={() => setActiveTab('projects')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'projects' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <FolderOpen size={20} />
                <span>المشروعات</span>
              </button>
              <button
                onClick={() => setActiveTab('news')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'news' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <Newspaper size={20} />
                <span>الأخبار</span>
              </button>
              <button
                onClick={() => setActiveTab('comments')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'comments' ? 'bg-[#2d5a27] text-white' : 'hover:bg-gray-100'
                }`}
              >
                <MessageSquare size={20} />
                <span>التعليقات</span>
              </button>
            </nav>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {activeTab === 'overview' && renderOverview()}
            {activeTab === 'users' && renderUsers()}
            {activeTab === 'news' && renderNews()}
            {activeTab === 'comments' && renderComments()}
            {activeTab === 'projects' && renderProjects()}
          </main>
        </div>
      </div>
    </div>
  );
}
