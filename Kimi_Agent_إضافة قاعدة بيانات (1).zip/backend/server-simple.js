const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Mock Data
const mockData = {
  users: [
    { id: 1, name: 'المدير العام', email: 'admin@agri.gov.eg', password: 'admin123', role: 'admin', phone: '01001234567', avatar: 'https://ui-avatars.com/api/?name=Admin&background=2d5a27&color=fff' },
    { id: 2, name: 'أحمد محمود', email: 'farmer@example.com', password: 'farmer123', role: 'farmer', phone: '01012345678', avatar: 'https://ui-avatars.com/api/?name=Ahmed+M&background=4a7c43&color=fff' },
    { id: 3, name: 'محمد علي', email: 'investor@example.com', password: 'investor123', role: 'investor', phone: '01023456789', avatar: 'https://ui-avatars.com/api/?name=Mohamed+A&background=d4a574&color=fff' },
    { id: 4, name: 'سارة أحمد', email: 'student@example.com', password: 'student123', role: 'student', phone: '01034567890', avatar: 'https://ui-avatars.com/api/?name=Sara+A&background=8b7355&color=fff' }
  ],
  sectors: [
    { id: 1, name: 'الزراعة النباتية', description: 'تشمل زراعة المحاصيل الأساسية مثل القمح والذرة والأرز', image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800', icon: 'Wheat' },
    { id: 2, name: 'الإنتاج الحيواني', description: 'تربية الماشية وإنتاج اللحوم والألبان', image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=800', icon: 'Beef' },
    { id: 3, name: 'الإنتاج الداجني', description: 'تربية الدواجن لإنتاج اللحوم والبيض', image: 'https://images.unsplash.com/photo-1548550023-2bdb3c5b9239?w=800', icon: 'Egg' },
    { id: 4, name: 'الثروة السمكية', description: 'تربية الأسماك في المزارع السمكية', image: 'https://images.unsplash.com/photo-1534043464124-3882f3e1e5b9?w=800', icon: 'Fish' },
    { id: 5, name: 'الزراعة العضوية', description: 'زراعة خالية من الكيماويات والمبيدات', image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800', icon: 'Leaf' },
    { id: 6, name: 'الصوب الزراعية', description: 'زراعة محمية داخل صوب زراعية حديثة', image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800', icon: 'Warehouse' }
  ],
  projects: [
    { id: 1, name: 'مشروع الدلتا الجديدة', description: 'أضخم مشروع استصلاح زراعي في مصر', area: '2,000,000 فدان', investment_cost: '300 مليار جنيه', image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800', location: 'غرب الدلتا', status: 'active' },
    { id: 2, name: 'مشروع توشكى', description: 'استصلاح أراضي جنوب الوادي', area: '1,500,000 فدان', investment_cost: '200 مليار جنيه', image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800', location: 'جنوب الوادي', status: 'active' },
    { id: 3, name: 'مشروع مستقبل مصر', description: 'استصلاح أراضي غرب غرب النوبارية', area: '3,000,000 فدان', investment_cost: '500 مليار جنيه', image: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?w=800', location: 'غرب النوبارية', status: 'active' },
    { id: 4, name: 'مشروع 100 ألف صوبة', description: 'إنشاء صوب زراعية حديثة', area: '100,000 صوبة', investment_cost: '100 مليار جنيه', image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800', location: 'جميع المحافظات', status: 'active' }
  ],
  news: [
    { id: 1, title: 'مصر تحقق الاكتفاء الذاتي من القمح بنسبة 60%', summary: 'زيادة إنتاج القمح بنسبة 15% عن العام الماضي', image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800', category: 'إنتاج', views: 15234, published_at: '2024-06-15' },
    { id: 2, title: 'افتتاح أكبر مجمع للإنتاج الحيواني في الشرق الأوسط', summary: 'استثمارات تصل إلى 5 مليارات جنيه', image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=800', category: 'مشروعات', views: 12345, published_at: '2024-06-14' },
    { id: 3, title: 'أسعار الخضروات اليوم في سوق العبور', summary: 'انخفاض أسعار الطماطم والخيار', image: 'https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?w=800', category: 'أسعار', views: 9876, published_at: '2024-06-13' },
    { id: 4, title: 'مصر تتصدر قائمة الدول المصدرة للحاصلات الزراعية', summary: '6.5 مليون طن صادرات زراعية', image: 'https://images.unsplash.com/photo-1592419044706-39796d40f98c?w=800', category: 'تصدير', views: 8765, published_at: '2024-06-12' }
  ],
  investments: [
    { id: 1, title: 'أرض زراعية للبيع - الوادي الجديد', description: 'أرض صالحة للزراعة بمساحة 50 فدان', location: 'الوادي الجديد', area: '50 فدان', price: '5,000,000 جنيه', type: 'land_sale', status: 'available' },
    { id: 2, title: 'مزرعة دواجن للإيجار - المنوفية', description: 'مزرعة دواجن مجهزة بالكامل', location: 'المنوفية', area: '10 أفدنة', price: '50,000 جنيه/شهر', type: 'land_rent', status: 'available' },
    { id: 3, title: 'مشروع صوب زراعية - للشراكة', description: 'مشروع إنشاء 10 صوب زراعية', location: 'البحيرة', price: '2,000,000 جنيه', type: 'small_project', status: 'available' }
  ],
  statistics: [
    { year: 2020, crop_name: 'القمح', production_tons: 9000000, area_feddans: 3200000 },
    { year: 2021, crop_name: 'القمح', production_tons: 9500000, area_feddans: 3300000 },
    { year: 2022, crop_name: 'القمح', production_tons: 10000000, area_feddans: 3400000 },
    { year: 2023, crop_name: 'القمح', production_tons: 11000000, area_feddans: 3600000 },
    { year: 2024, crop_name: 'القمح', production_tons: 12000000, area_feddans: 3800000 }
  ],
  guidance: [
    { id: 1, category: 'irrigation', title: 'نظم الري الحديثة', content: 'تعتبر نظم الري الحديثة من أهم عوامل ترشيد استهلاك المياه...', image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800' },
    { id: 2, category: 'pest_control', title: 'مكافحة الآفات المتكاملة', content: 'تعتمد المكافحة المتكاملة على استخدام عدة طرق معاً...', image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800' }
  ]
};

// Auth Routes
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = mockData.users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
  
  const { password: _, ...userWithoutPassword } = user;
  res.json({ 
    success: true, 
    data: { 
      user: userWithoutPassword, 
      token: 'mock-jwt-token-' + user.id 
    } 
  });
});

app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role, phone } = req.body;
  const existingUser = mockData.users.find(u => u.email === email);
  
  if (existingUser) {
    return res.status(409).json({ success: false, message: 'Email already registered' });
  }
  
  const newUser = {
    id: mockData.users.length + 1,
    name,
    email,
    role: role || 'student',
    phone,
    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=2d5a27&color=fff`
  };
  
  mockData.users.push({ ...newUser, password });
  res.status(201).json({ success: true, data: { user: newUser, token: 'mock-jwt-token-' + newUser.id } });
});

app.get('/api/auth/me', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  const userId = token?.split('-').pop();
  const user = mockData.users.find(u => u.id === parseInt(userId));
  
  if (!user) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }
  
  const { password: _, ...userWithoutPassword } = user;
  res.json({ success: true, data: { user: userWithoutPassword } });
});

// Data Routes
app.get('/api/sectors', (req, res) => {
  res.json({ success: true, data: { sectors: mockData.sectors } });
});

app.get('/api/sectors/:id', (req, res) => {
  const sector = mockData.sectors.find(s => s.id === parseInt(req.params.id));
  if (!sector) return res.status(404).json({ success: false, message: 'Sector not found' });
  res.json({ success: true, data: { sector } });
});

app.get('/api/projects', (req, res) => {
  res.json({ success: true, data: { projects: mockData.projects } });
});

app.get('/api/projects/:id', (req, res) => {
  const project = mockData.projects.find(p => p.id === parseInt(req.params.id));
  if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
  res.json({ success: true, data: { project } });
});

app.get('/api/news', (req, res) => {
  res.json({ success: true, data: { news: mockData.news } });
});

app.get('/api/news/:id', (req, res) => {
  const news = mockData.news.find(n => n.id === parseInt(req.params.id));
  if (!news) return res.status(404).json({ success: false, message: 'News not found' });
  res.json({ success: true, data: { news } });
});

app.get('/api/investments', (req, res) => {
  res.json({ success: true, data: { investments: mockData.investments } });
});

app.get('/api/investments/:id', (req, res) => {
  const investment = mockData.investments.find(i => i.id === parseInt(req.params.id));
  if (!investment) return res.status(404).json({ success: false, message: 'Investment not found' });
  res.json({ success: true, data: { investment } });
});

app.get('/api/statistics', (req, res) => {
  res.json({ success: true, data: { statistics: mockData.statistics } });
});

app.get('/api/statistics/dashboard', (req, res) => {
  res.json({ 
    success: true, 
    data: { 
      stats: {
        total_users: mockData.users.length,
        total_projects: mockData.projects.length,
        total_investments: mockData.investments.length,
        total_news: mockData.news.length,
        pending_comments: 0
      }
    } 
  });
});

app.get('/api/guidance', (req, res) => {
  res.json({ success: true, data: { guidance: mockData.guidance } });
});

app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'API is running', database: 'mock mode' });
});

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🌾 Egyptian Agricultural Sector API',
    version: '1.0.0',
    endpoints: [
      'POST /api/auth/login',
      'POST /api/auth/register',
      'GET  /api/auth/me',
      'GET  /api/sectors',
      'GET  /api/projects',
      'GET  /api/news',
      'GET  /api/investments',
      'GET  /api/statistics',
      'GET  /api/guidance'
    ]
  });
});

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║     🌾 Egyptian Agricultural Sector API 🌾                ║
║                                                            ║
║     Server running on http://localhost:${PORT}              ║
║     Mode: Mock Data (No database required)                 ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
  `);
});
