# Agricultural System Backend API

Backend API for the Egyptian Agricultural Sector System built with Node.js, Express, and MySQL.

## 🚀 Features

- ✅ RESTful API design
- ✅ JWT authentication & authorization
- ✅ Role-based access control (Admin, Farmer, Investor, Student)
- ✅ MySQL database with connection pooling
- ✅ Input validation with express-validator
- ✅ Rate limiting & security headers
- ✅ File upload support with Multer
- ✅ Comprehensive error handling

## 📁 Project Structure

```
backend/
├── config/
│   └── database.js          # Database connection configuration
├── controllers/             # Route controllers
│   ├── authController.js
│   ├── userController.js
│   ├── sectorController.js
│   ├── projectController.js
│   ├── newsController.js
│   ├── investmentController.js
│   ├── statisticsController.js
│   ├── commentController.js
│   ├── messageController.js
│   └── notificationController.js
├── middleware/              # Custom middleware
│   ├── auth.js             # Authentication middleware
│   └── errorHandler.js     # Error handling middleware
├── routes/                  # API routes
│   ├── auth.js
│   ├── users.js
│   ├── sectors.js
│   ├── projects.js
│   ├── news.js
│   ├── investments.js
│   ├── statistics.js
│   ├── comments.js
│   ├── messages.js
│   └── notifications.js
├── .env                    # Environment variables
├── package.json
├── server.js               # Main server file
└── README.md
```

## 🛠️ Installation

### Prerequisites

- Node.js (v16 or higher)
- MySQL (v8.0 or higher)

### Step 1: Install Dependencies

```bash
cd backend
npm install
```

### Step 2: Setup Database

1. Create MySQL database:
```sql
CREATE DATABASE agricultural_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. Import the SQL file:
```bash
mysql -u root -p agricultural_system < ../database/agricultural_system.sql
```

### Step 3: Configure Environment Variables

Create a `.env` file in the backend directory:

```env
PORT=5000
NODE_ENV=development

# Database
DB_HOST=localhost
DB_PORT=3306
DB_NAME=agricultural_system
DB_USER=your_mysql_username
DB_PASSWORD=your_mysql_password

# JWT
JWT_SECRET=your_super_secret_key_here
JWT_EXPIRES_IN=7d

# CORS
CORS_ORIGIN=http://localhost:5173,http://localhost:3000
```

### Step 4: Start the Server

Development mode:
```bash
npm run dev
```

Production mode:
```bash
npm start
```

The API will be available at `http://localhost:5000`

## 📚 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| GET | `/api/auth/me` | Get current user |
| PUT | `/api/auth/profile` | Update profile |
| PUT | `/api/auth/change-password` | Change password |

### Users (Admin only)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | Get all users |
| GET | `/api/users/stats` | Get user stats |
| GET | `/api/users/:id` | Get user by ID |
| PUT | `/api/users/:id` | Update user |
| DELETE | `/api/users/:id` | Delete user |

### Sectors
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/sectors` | Get all sectors |
| GET | `/api/sectors/:id` | Get sector by ID |
| GET | `/api/sectors/crop-types` | Get all crop types |
| POST | `/api/sectors` | Create sector (Admin) |
| PUT | `/api/sectors/:id` | Update sector (Admin) |
| DELETE | `/api/sectors/:id` | Delete sector (Admin) |

### Projects
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/projects` | Get all projects |
| GET | `/api/projects/:id` | Get project by ID |
| POST | `/api/projects` | Create project (Admin) |
| PUT | `/api/projects/:id` | Update project (Admin) |
| DELETE | `/api/projects/:id` | Delete project (Admin) |

### News
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/news` | Get all news |
| GET | `/api/news/:id` | Get news by ID |
| POST | `/api/news` | Create news (Admin) |
| PUT | `/api/news/:id` | Update news (Admin) |
| DELETE | `/api/news/:id` | Delete news (Admin) |

### Investments
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/investments` | Get all investments |
| GET | `/api/investments/:id` | Get investment by ID |
| GET | `/api/investments/my/listings` | Get my listings (Farmer) |
| POST | `/api/investments` | Create investment |
| PUT | `/api/investments/:id` | Update investment |
| DELETE | `/api/investments/:id` | Delete investment |
| PUT | `/api/investments/:id/approve` | Approve investment (Admin) |

### Statistics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/statistics` | Get all statistics |
| GET | `/api/statistics/dashboard` | Get dashboard stats |
| GET | `/api/statistics/crop/:cropName` | Get stats by crop |
| POST | `/api/statistics` | Create statistic (Admin) |
| PUT | `/api/statistics/:id` | Update statistic (Admin) |
| DELETE | `/api/statistics/:id` | Delete statistic (Admin) |

### Comments
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/comments` | Get all comments (Admin) |
| POST | `/api/comments` | Create comment |
| PUT | `/api/comments/:id/approve` | Approve comment (Admin) |
| DELETE | `/api/comments/:id` | Delete comment |

### Messages
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/messages` | Get my messages |
| GET | `/api/messages/conversation/:userId` | Get conversation |
| POST | `/api/messages` | Send message |
| DELETE | `/api/messages/:id` | Delete message |

### Notifications
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/notifications` | Get my notifications |
| PUT | `/api/notifications/:id/read` | Mark as read |
| PUT | `/api/notifications/read-all` | Mark all as read |
| DELETE | `/api/notifications/:id` | Delete notification |
| POST | `/api/notifications` | Create notification (Admin) |

## 🔐 Authentication

The API uses JWT tokens for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

## 👥 User Roles

- **admin**: Full access to all endpoints
- **farmer**: Can create/manage investments
- **investor**: Can view investments and send messages
- **student**: Basic read access

## 📄 License

MIT License
