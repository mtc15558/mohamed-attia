const express = require('express');
const router = express.Router();
const commentController = require('../controllers/commentController');
const { authenticate, authorize } = require('../middleware/auth');

// Public routes - none

// Protected routes
router.get('/', authenticate, authorize('admin'), commentController.getAllComments);
router.post('/', authenticate, commentController.createComment);
router.put('/:id/approve', authenticate, authorize('admin'), commentController.approveComment);
router.delete('/:id', authenticate, commentController.deleteComment);

module.exports = router;
