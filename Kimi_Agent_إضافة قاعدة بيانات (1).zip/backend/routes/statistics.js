const express = require('express');
const router = express.Router();
const statisticsController = require('../controllers/statisticsController');
const { authenticate, authorize } = require('../middleware/auth');

// Public routes
router.get('/', statisticsController.getAllStatistics);
router.get('/dashboard', statisticsController.getDashboardStats);
router.get('/crop/:cropName', statisticsController.getStatisticsByCrop);

// Admin only routes
router.post('/', authenticate, authorize('admin'), statisticsController.createStatistic);
router.put('/:id', authenticate, authorize('admin'), statisticsController.updateStatistic);
router.delete('/:id', authenticate, authorize('admin'), statisticsController.deleteStatistic);

module.exports = router;
