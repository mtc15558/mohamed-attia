const express = require('express');
const router = express.Router();
const newsController = require('../controllers/newsController');
const { authenticate, authorize } = require('../middleware/auth');

// Public routes
router.get('/', newsController.getAllNews);
router.get('/:id', newsController.getNewsById);

// Admin only routes
router.post('/', authenticate, authorize('admin'), newsController.createNews);
router.put('/:id', authenticate, authorize('admin'), newsController.updateNews);
router.delete('/:id', authenticate, authorize('admin'), newsController.deleteNews);

module.exports = router;
