const express = require('express');
const router = express.Router();
const investmentController = require('../controllers/investmentController');
const { authenticate, authorize } = require('../middleware/auth');

// Public routes
router.get('/', investmentController.getAllInvestments);
router.get('/:id', investmentController.getInvestmentById);

// Protected routes
router.get('/my/listings', authenticate, authorize('farmer'), investmentController.getMyInvestments);
router.post('/', authenticate, authorize('farmer', 'investor'), investmentController.createInvestment);
router.put('/:id', authenticate, investmentController.updateInvestment);
router.delete('/:id', authenticate, investmentController.deleteInvestment);

// Admin only
router.put('/:id/approve', authenticate, authorize('admin'), investmentController.approveInvestment);

module.exports = router;
