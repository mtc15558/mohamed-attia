const express = require('express');
const router = express.Router();
const messageController = require('../controllers/messageController');
const { authenticate } = require('../middleware/auth');

// All routes require authentication
router.use(authenticate);

router.get('/', messageController.getMyMessages);
router.get('/conversation/:otherUserId', messageController.getConversation);
router.post('/', messageController.sendMessage);
router.delete('/:id', messageController.deleteMessage);

module.exports = router;
