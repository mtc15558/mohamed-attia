const express = require('express');
const router = express.Router();
const sectorController = require('../controllers/sectorController');
const { authenticate, authorize } = require('../middleware/auth');

// Public routes
router.get('/', sectorController.getAllSectors);
router.get('/crop-types', sectorController.getAllCropTypes);
router.get('/:id', sectorController.getSectorById);

// Admin only routes
router.post('/', authenticate, authorize('admin'), sectorController.createSector);
router.put('/:id', authenticate, authorize('admin'), sectorController.updateSector);
router.delete('/:id', authenticate, authorize('admin'), sectorController.deleteSector);

module.exports = router;
