const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'agricultural_secret_key_2024';

// Middleware
app.use(cors());
app.use(express.json());

// Database Connection Pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'agricultural_system',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test database connection
const testDB = async () => {
  try {
    const connection = await pool.getConnection();
    console.log('✅ Database connected successfully!');
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    console.log('⚠️  Running in MOCK MODE (no database)');
    return false;
  }
};

// Mock Data (for testing without database)
const mockData = {
  users: [
    { id: 1, name: 'المدير العام', email: 'admin@agri.gov.eg', password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', role: 'admin', phone: '01001234567', avatar: 'https://ui-avatars.com/api/?name=Admin&background=2d5a27&color=fff', is_active: true },
    { id: 2, name: 'أحمد محمود', email: 'farmer@example.com', password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', role: 'farmer', phone: '01012345678', avatar: 'https://ui-avatars.com/api/?name=Ahmed+M&background=4a7c43&color=fff', is_active: true },
    { id: 3, name: 'محمد علي', email: 'investor@example.com', password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', role: 'investor', phone: '01023456789', avatar: 'https://ui-avatars.com/api/?name=Mohamed+A&background=d4a574&color=fff', is_active: true },
    { id: 4, name: 'سارة أحمد', email: 'student@example.com', password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', role: 'student', phone: '01034567890', avatar: 'https://ui-avatars.com/api/?name=Sara+A&background=8b7355&color=fff', is_active: true }
  ],
  sectors: [
    { id: 1, name: 'الزراعة النباتية', name_en: 'Crop Agriculture', description: 'تشمل زراعة المحاصيل الأساسية', importance: 'توفر الأمن الغذائي', challenges: '["نقص المياه", "التغيرات المناخية"]', investment_opportunities: '["الصوب الزراعية", "الزراعة العضوية"]', image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800', icon: 'Wheat', display_order: 1 },
    { id: 2, name: 'الإنتاج الحيواني', name_en: 'Animal Production', description: 'تربية الماشية وإنتاج اللحوم والألبان', importance: 'توفير البروتين الحيواني', challenges: '["ارتفاع أسعار الأعلاف"]', investment_opportunities: '["مزارع تربية المواشي"]', image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=800', icon: 'Beef', display_order: 2 },
    { id: 3, name: 'الإنتاج الداجني', name_en: 'Poultry Production', description: 'تربية الدواجن لإنتاج اللحوم والبيض', importance: 'أهم مصدر للبروتين الحيواني', challenges: '["أنفلونزا الطيور"]', investment_opportunities: '["مزارع دواجن متكاملة"]', image: 'https://images.unsplash.com/photo-1548550023-2bdb3c5b9239?w=800', icon: 'Egg', display_order: 3 },
    { id: 4, name: 'الثروة السمكية', name_en: 'Fisheries', description: 'تربية الأسماك في المزارع السمكية', importance: 'توفير البروتين السمكي', challenges: '["تلوث المياه"]', investment_opportunities: '["مزارع سمكية"]', image: 'https://images.unsplash.com/photo-1534043464124-3882f3e1e5b9?w=800', icon: 'Fish', display_order: 4 },
    { id: 5, name: 'الزراعة العضوية', name_en: 'Organic Agriculture', description: 'زراعة خالية من الكيماويات', importance: 'صحة الإنسان وحماية البيئة', challenges: '["ارتفاع التكاليف"]', investment_opportunities: '["مزارع عضوية"]', image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800', icon: 'Leaf', display_order: 5 },
    { id: 6, name: 'الصوب الزراعية', name_en: 'Greenhouses', description: 'زراعة محمية داخل صوب زراعية', importance: 'إنتاج على مدار العام', challenges: '["التكلفة الأولية"]', investment_opportunities: '["صوب ذكية"]', image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800', icon: 'Warehouse', display_order: 6 }
  ],
  projects: [
    { id: 1, name: 'مشروع الدلتا الجديدة', description: 'أضخم مشروع استصلاح زراعي في مصر', goal: 'استصلاح 2 مليون فدان', area: '2,000,000 فدان', expected_production: '15 مليون طن سنوياً', economic_impact: 'إنشاء 5 ملايين فرصة عمل', image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800', location: 'غرب الدلتا', start_date: '2021-01-01', status: 'active', investment_cost: '300 مليار جنيه', progress_percentage: 65, is_featured: 1 },
    { id: 2, name: 'مشروع توشكى', description: 'استصلاح أراضي جنوب الوادي', goal: 'استصلاح 1.5 مليون فدان', area: '1,500,000 فدان', expected_production: '10 مليون طن سنوياً', economic_impact: 'تنمية جنوب الوادي', image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800', location: 'جنوب الوادي', start_date: '2020-01-01', status: 'active', investment_cost: '200 مليار جنيه', progress_percentage: 70, is_featured: 1 },
    { id: 3, name: 'مشروع مستقبل مصر', description: 'استصلاح أراضي غرب غرب النوبارية', goal: 'استصلاح 3 ملايين فدان', area: '3,000,000 فدان', expected_production: '25 مليون طن سنوياً', economic_impact: 'أكبر مشروع زراعي في العالم', image: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?w=800', location: 'غرب النوبارية', start_date: '2022-01-01', status: 'active', investment_cost: '500 مليار جنيه', progress_percentage: 45, is_featured: 1 },
    { id: 4, name: 'مشروع 100 ألف صوبة', description: 'إنشاء صوب زراعية حديثة', goal: 'زيادة الإنتاجية وتحسين الجودة', area: '100,000 صوبة', expected_production: '5 مليون طن خضروات', economic_impact: 'توفير احتياجات السوق المحلي', image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800', location: 'جميع المحافظات', start_date: '2023-01-01', status: 'active', investment_cost: '100 مليار جنيه', progress_percentage: 80, is_featured: 1 }
  ],
  news: [
    { id: 1, title: 'مصر تحقق الاكتفاء الذاتي من القمح بنسبة 60%', content: 'أعلنت وزارة الزراعة المصرية عن تحقيق نسبة 60% من الاكتفاء الذاتي من القمح هذا العام...', summary: 'زيادة إنتاج القمح بنسبة 15% عن العام الماضي', image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800', category: 'إنتاج', author: 'وزارة الزراعة', views: 15234, is_featured: 1, published_at: '2024-06-15' },
    { id: 2, title: 'افتتاح أكبر مجمع للإنتاج الحيواني في الشرق الأوسط', content: 'تم افتتاح مجمع البELLA الزراعي كأكبر مجمع متكامل للإنتاج الحيواني...', summary: 'استثمارات تصل إلى 5 مليارات جنيه', image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=800', category: 'مشروعات', author: 'الهيئة العامة للاستثمار', views: 12345, is_featured: 1, published_at: '2024-06-14' },
    { id: 3, title: 'أسعار الخضروات اليوم في سوق العبور', content: 'شهدت أسعار الخضروات استقراراً نسبياً اليوم في سوق العبور...', summary: 'انخفاض أسعار الطماطم والخيار', image: 'https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?w=800', category: 'أسعار', author: 'سوق العبور', views: 9876, is_featured: 0, published_at: '2024-06-13' },
    { id: 4, title: 'مصر تتصدر قائمة الدول المصدرة للحاصلات الزراعية', content: 'حققت مصر قفزة كبيرة في الصادرات الزراعية خلال النصف الأول من العام...', summary: '6.5 مليون طن صادرات زراعية', image: 'https://images.unsplash.com/photo-1592419044706-39796d40f98c?w=800', category: 'تصدير', author: 'هيئة التنمية الصادرات', views: 8765, is_featured: 1, published_at: '2024-06-12' }
  ],
  investments: [
    { id: 1, title: 'أرض زراعية للبيع - الوادي الجديد', description: 'أرض صالحة للزراعة بمساحة 50 فدان مع بئر ماء وكهرباء', type: 'land_sale', location: 'الوادي الجديد', area: '50 فدان', price: '5,000,000 جنيه', price_numeric: 5000000, contact_info: 'أحمد محمود', contact_phone: '01001234567', images: '["/images/investments/land1.jpg"]', owner_id: 2, status: 'available', is_approved: 1, view_count: 150 },
    { id: 2, title: 'مزرعة دواجن للإيجار - المنوفية', description: 'مزرعة دواجن مجهزة بالكامل مع جميع التراخيص', type: 'land_rent', location: 'المنوفية', area: '10 أفدنة', price: '50,000 جنيه/شهر', price_numeric: 50000, contact_info: 'محمد علي', contact_phone: '01002345678', images: '["/images/investments/poultry.jpg"]', owner_id: 2, status: 'available', is_approved: 1, view_count: 89 },
    { id: 3, title: 'مشروع صوب زراعية - للشراكة', description: 'مشروع إنشاء 10 صوب زراعية حديثة', type: 'small_project', location: 'البحيرة', area: null, price: '2,000,000 جنيه', price_numeric: 2000000, contact_info: 'سارة أحمد', contact_phone: '01003456789', images: '["/images/investments/greenhouse.jpg"]', owner_id: 3, status: 'available', is_approved: 1, view_count: 234 }
  ],
  statistics: [
    { id: 1, year: 2020, crop_name: 'القمح', production_tons: 9000000, area_feddans: 3200000, export_value: 0, import_value: 2500000000 },
    { id: 2, year: 2021, crop_name: 'القمح', production_tons: 9500000, area_feddans: 3300000, export_value: 0, import_value: 2300000000 },
    { id: 3, year: 2022, crop_name: 'القمح', production_tons: 10000000, area_feddans: 3400000, export_value: 0, import_value: 2000000000 },
    { id: 4, year: 2023, crop_name: 'القمح', production_tons: 11000000, area_feddans: 3600000, export_value: 50000000, import_value: 1800000000 },
    { id: 5, year: 2024, crop_name: 'القمح', production_tons: 12000000, area_feddans: 3800000, export_value: 100000000, import_value: 1500000000 },
    { id: 6, year: 2020, crop_name: 'الأرز', production_tons: 6000000, area_feddans: 2800000, export_value: 200000000, import_value: 0 },
    { id: 7, year: 2021, crop_name: 'الأرز', production_tons: 6200000, area_feddans: 2900000, export_value: 250000000, import_value: 0 },
    { id: 8, year: 2022, crop_name: 'الأرز', production_tons: 6500000, area_feddans: 3000000, export_value: 300000000, import_value: 0 },
    { id: 9, year: 2023, crop_name: 'الأرز', production_tons: 6800000, area_feddans: 3100000, export_value: 350000000, import_value: 0 },
    { id: 10, year: 2024, crop_name: 'الأرز', production_tons: 7000000, area_feddans: 3200000, export_value: 400000000, import_value: 0 }
  ],
  guidance: [
    { id: 1, category: 'irrigation', title: 'نظم الري الحديثة', content: 'تعتبر نظم الري الحديثة من أهم عوامل ترشيد استهلاك المياه في الزراعة...', image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800' },
    { id: 2, category: 'pest_control', title: 'مكافحة الآفات المتكاملة', content: 'تعتمد المكافحة المتكاملة على استخدام عدة طرق معاً للتحكم في الآفات...', image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800' },
    { id: 3, category: 'fertilization', title: 'التسميد العقلاني', content: 'التسميد العقلاني يعتمد على تحليل التربة وتحديد الاحتياجات الفعلية للنبات...', image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800' },
    { id: 4, category: 'soil', title: 'تحسين خصوبة التربة', content: 'تحسين خصوبة التربة يبدأ بفهم تركيبها وخصائصها الفيزيائية والكيميائية...', image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800' }
  ],
  comments: [],
  messages: [],
  notifications: []
};

let useMockData = false;

// JWT Middleware
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, message: 'Access denied' });
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
};

// Generate Token
const generateToken = (userId) => jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });

// ============== AUTH ROUTES ==============

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, role = 'student', phone } = req.body;
    
    if (useMockData) {
      const existingUser = mockData.users.find(u => u.email === email);
      if (existingUser) return res.status(409).json({ success: false, message: 'Email already registered' });
      
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = {
        id: mockData.users.length + 1,
        name,
        email,
        password: hashedPassword,
        role,
        phone,
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=2d5a27&color=fff`,
        is_active: true
      };
      mockData.users.push(newUser);
      
      const { password: _, ...userWithoutPassword } = newUser;
      return res.status(201).json({ success: true, data: { user: userWithoutPassword, token: generateToken(newUser.id) } });
    }
    
    const [existing] = await pool.execute('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) return res.status(409).json({ success: false, message: 'Email already registered' });
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const avatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=2d5a27&color=fff`;
    
    const [result] = await pool.execute(
      'INSERT INTO users (name, email, password, role, phone, avatar) VALUES (?, ?, ?, ?, ?, ?)',
      [name, email, hashedPassword, role, phone, avatar]
    );
    
    res.status(201).json({ success: true, data: { user: { id: result.insertId, name, email, role, phone, avatar }, token: generateToken(result.insertId) } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (useMockData) {
      const user = mockData.users.find(u => u.email === email);
      if (!user) return res.status(401).json({ success: false, message: 'Invalid credentials' });
      
      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) return res.status(401).json({ success: false, message: 'Invalid credentials' });
      
      const { password: _, ...userWithoutPassword } = user;
      return res.json({ success: true, data: { user: userWithoutPassword, token: generateToken(user.id) } });
    }
    
    const [users] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (users.length === 0) return res.status(401).json({ success: false, message: 'Invalid credentials' });
    
    const user = users[0];
    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) return res.status(401).json({ success: false, message: 'Invalid credentials' });
    
    await pool.execute('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);
    
    const { password: _, ...userWithoutPassword } = user;
    res.json({ success: true, data: { user: userWithoutPassword, token: generateToken(user.id) } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get Me
app.get('/api/auth/me', authenticate, async (req, res) => {
  try {
    if (useMockData) {
      const user = mockData.users.find(u => u.id === req.userId);
      if (!user) return res.status(404).json({ success: false, message: 'User not found' });
      const { password: _, ...userWithoutPassword } = user;
      return res.json({ success: true, data: { user: userWithoutPassword } });
    }
    
    const [users] = await pool.execute('SELECT id, name, email, role, phone, avatar FROM users WHERE id = ?', [req.userId]);
    if (users.length === 0) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, data: { user: users[0] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== SECTORS ROUTES ==============

app.get('/api/sectors', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({ success: true, data: { sectors: mockData.sectors } });
    }
    const [sectors] = await pool.execute('SELECT * FROM sectors WHERE is_active = TRUE ORDER BY display_order');
    res.json({ success: true, data: { sectors } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get('/api/sectors/:id', async (req, res) => {
  try {
    if (useMockData) {
      const sector = mockData.sectors.find(s => s.id === parseInt(req.params.id));
      if (!sector) return res.status(404).json({ success: false, message: 'Sector not found' });
      return res.json({ success: true, data: { sector } });
    }
    const [sectors] = await pool.execute('SELECT * FROM sectors WHERE id = ?', [req.params.id]);
    if (sectors.length === 0) return res.status(404).json({ success: false, message: 'Sector not found' });
    res.json({ success: true, data: { sector: sectors[0] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== PROJECTS ROUTES ==============

app.get('/api/projects', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({ success: true, data: { projects: mockData.projects } });
    }
    const [projects] = await pool.execute('SELECT * FROM projects ORDER BY created_at DESC');
    res.json({ success: true, data: { projects } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get('/api/projects/:id', async (req, res) => {
  try {
    if (useMockData) {
      const project = mockData.projects.find(p => p.id === parseInt(req.params.id));
      if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
      return res.json({ success: true, data: { project } });
    }
    const [projects] = await pool.execute('SELECT * FROM projects WHERE id = ?', [req.params.id]);
    if (projects.length === 0) return res.status(404).json({ success: false, message: 'Project not found' });
    res.json({ success: true, data: { project: projects[0] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== NEWS ROUTES ==============

app.get('/api/news', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({ success: true, data: { news: mockData.news } });
    }
    const [news] = await pool.execute('SELECT * FROM news WHERE is_published = TRUE ORDER BY published_at DESC');
    res.json({ success: true, data: { news } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get('/api/news/:id', async (req, res) => {
  try {
    if (useMockData) {
      const news = mockData.news.find(n => n.id === parseInt(req.params.id));
      if (!news) return res.status(404).json({ success: false, message: 'News not found' });
      return res.json({ success: true, data: { news } });
    }
    const [news] = await pool.execute('SELECT * FROM news WHERE id = ?', [req.params.id]);
    if (news.length === 0) return res.status(404).json({ success: false, message: 'News not found' });
    await pool.execute('UPDATE news SET views = views + 1 WHERE id = ?', [req.params.id]);
    res.json({ success: true, data: { news: news[0] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== INVESTMENTS ROUTES ==============

app.get('/api/investments', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({ success: true, data: { investments: mockData.investments } });
    }
    const [investments] = await pool.execute('SELECT i.*, u.name as owner_name FROM investments i JOIN users u ON i.owner_id = u.id WHERE i.status = "available" AND i.is_approved = TRUE');
    res.json({ success: true, data: { investments } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get('/api/investments/:id', async (req, res) => {
  try {
    if (useMockData) {
      const investment = mockData.investments.find(i => i.id === parseInt(req.params.id));
      if (!investment) return res.status(404).json({ success: false, message: 'Investment not found' });
      return res.json({ success: true, data: { investment } });
    }
    const [investments] = await pool.execute('SELECT i.*, u.name as owner_name FROM investments i JOIN users u ON i.owner_id = u.id WHERE i.id = ?', [req.params.id]);
    if (investments.length === 0) return res.status(404).json({ success: false, message: 'Investment not found' });
    res.json({ success: true, data: { investment: investments[0] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== STATISTICS ROUTES ==============

app.get('/api/statistics', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({ success: true, data: { statistics: mockData.statistics } });
    }
    const [statistics] = await pool.execute('SELECT * FROM statistics ORDER BY year DESC, crop_name');
    res.json({ success: true, data: { statistics } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get('/api/statistics/dashboard', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({
        success: true,
        data: {
          stats: {
            total_users: mockData.users.length,
            total_projects: mockData.projects.length,
            total_investments: mockData.investments.length,
            total_news: mockData.news.length,
            pending_comments: 0
          }
        }
      });
    }
    const [[stats]] = await pool.execute('SELECT * FROM dashboard_stats');
    res.json({ success: true, data: { stats } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== GUIDANCE ROUTES ==============

app.get('/api/guidance', async (req, res) => {
  try {
    if (useMockData) {
      return res.json({ success: true, data: { guidance: mockData.guidance } });
    }
    const [guidance] = await pool.execute('SELECT * FROM guidance WHERE is_published = TRUE');
    res.json({ success: true, data: { guidance } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============== HEALTH CHECK ==============

app.get('/api/health', async (req, res) => {
  const dbConnected = await testDB();
  res.json({
    success: true,
    message: 'API is running',
    database: dbConnected ? 'connected' : 'mock mode',
    timestamp: new Date().toISOString()
  });
});

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🌾 Egyptian Agricultural Sector API',
    version: '1.0.0',
    endpoints: [
      'POST   /api/auth/register',
      'POST   /api/auth/login',
      'GET    /api/auth/me',
      'GET    /api/sectors',
      'GET    /api/projects',
      'GET    /api/news',
      'GET    /api/investments',
      'GET    /api/statistics',
      'GET    /api/guidance',
      'GET    /api/health'
    ]
  });
});

// Start Server
const startServer = async () => {
  const dbConnected = await testDB();
  useMockData = !dbConnected;
  
  app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║     🌾 Egyptian Agricultural Sector API 🌾                ║
║                                                            ║
║     Server running on http://localhost:${PORT}              ║
║     Database: ${dbConnected ? '✅ Connected' : '⚠️  Mock Mode'}                       ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
    `);
  });
};

startServer();
