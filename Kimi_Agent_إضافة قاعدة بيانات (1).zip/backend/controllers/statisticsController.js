const { query } = require('../config/database');

// Get all statistics
const getAllStatistics = async (req, res) => {
  try {
    const { year, crop_name } = req.query;
    
    let sql = 'SELECT * FROM statistics WHERE 1=1';
    const params = [];

    if (year) {
      sql += ' AND year = ?';
      params.push(parseInt(year));
    }

    if (crop_name) {
      sql += ' AND crop_name = ?';
      params.push(crop_name);
    }

    sql += ' ORDER BY year DESC, crop_name';

    const statistics = await query(sql, params);

    res.json({
      success: true,
      data: { statistics }
    });
  } catch (error) {
    console.error('Get all statistics error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get statistics by crop
const getStatisticsByCrop = async (req, res) => {
  try {
    const { cropName } = req.params;
    const { start_year, end_year } = req.query;

    let sql = 'SELECT * FROM statistics WHERE crop_name = ?';
    const params = [cropName];

    if (start_year) {
      sql += ' AND year >= ?';
      params.push(parseInt(start_year));
    }

    if (end_year) {
      sql += ' AND year <= ?';
      params.push(parseInt(end_year));
    }

    sql += ' ORDER BY year';

    const statistics = await query(sql, params);

    res.json({
      success: true,
      data: { statistics }
    });
  } catch (error) {
    console.error('Get statistics by crop error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get dashboard stats
const getDashboardStats = async (req, res) => {
  try {
    const [stats] = await query('SELECT * FROM dashboard_stats');

    // Get monthly user growth
    const monthlyGrowth = await query(
      'SELECT * FROM monthly_user_growth LIMIT 12'
    );

    // Get latest crop prices
    const cropPrices = await query(
      'SELECT * FROM crop_prices WHERE price_date = CURDATE() ORDER BY crop_name'
    );

    res.json({
      success: true,
      data: {
        stats,
        monthlyGrowth,
        cropPrices
      }
    });
  } catch (error) {
    console.error('Get dashboard stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Create statistic (admin only)
const createStatistic = async (req, res) => {
  try {
    const {
      year,
      crop_name,
      production_tons,
      area_feddans,
      export_value,
      import_value,
      average_price_per_ton,
      notes
    } = req.body;

    const result = await query(
      `INSERT INTO statistics (year, crop_name, production_tons, area_feddans,
       export_value, import_value, average_price_per_ton, notes) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        year,
        crop_name,
        production_tons,
        area_feddans,
        export_value,
        import_value,
        average_price_per_ton,
        notes
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Statistic created successfully.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Create statistic error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Update statistic (admin only)
const updateStatistic = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      year,
      crop_name,
      production_tons,
      area_feddans,
      export_value,
      import_value,
      average_price_per_ton,
      notes
    } = req.body;

    await query(
      `UPDATE statistics SET year = ?, crop_name = ?, production_tons = ?,
       area_feddans = ?, export_value = ?, import_value = ?,
       average_price_per_ton = ?, notes = ? WHERE id = ?`,
      [
        year,
        crop_name,
        production_tons,
        area_feddans,
        export_value,
        import_value,
        average_price_per_ton,
        notes,
        id
      ]
    );

    res.json({
      success: true,
      message: 'Statistic updated successfully.'
    });
  } catch (error) {
    console.error('Update statistic error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete statistic (admin only)
const deleteStatistic = async (req, res) => {
  try {
    const { id } = req.params;

    await query('DELETE FROM statistics WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Statistic deleted successfully.'
    });
  } catch (error) {
    console.error('Delete statistic error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllStatistics,
  getStatisticsByCrop,
  getDashboardStats,
  createStatistic,
  updateStatistic,
  deleteStatistic
};
