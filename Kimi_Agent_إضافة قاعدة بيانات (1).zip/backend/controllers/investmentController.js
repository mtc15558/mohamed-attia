const { query } = require('../config/database');

// Get all investments
const getAllInvestments = async (req, res) => {
  try {
    const { type, location, min_price, max_price, search, page = 1, limit = 10 } = req.query;
    
    let sql = `
      SELECT i.*, u.name as owner_name, u.phone as owner_phone 
      FROM investments i 
      JOIN users u ON i.owner_id = u.id 
      WHERE i.status = 'available' AND i.is_approved = TRUE
    `;
    const params = [];

    if (type) {
      sql += ' AND i.type = ?';
      params.push(type);
    }

    if (location) {
      sql += ' AND i.location LIKE ?';
      params.push(`%${location}%`);
    }

    if (min_price) {
      sql += ' AND i.price_numeric >= ?';
      params.push(parseFloat(min_price));
    }

    if (max_price) {
      sql += ' AND i.price_numeric <= ?';
      params.push(parseFloat(max_price));
    }

    if (search) {
      sql += ' AND (i.title LIKE ? OR i.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' ORDER BY i.created_at DESC';

    // Add pagination
    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const investments = await query(sql, params);

    // Parse JSON images
    const parsedInvestments = investments.map(inv => ({
      ...inv,
      images: JSON.parse(inv.images || '[]')
    }));

    // Get total count
    let countSql = `
      SELECT COUNT(*) as total 
      FROM investments 
      WHERE status = 'available' AND is_approved = TRUE
    `;
    if (type) countSql += ' AND type = ?';
    if (location) countSql += ' AND location LIKE ?';
    if (min_price) countSql += ' AND price_numeric >= ?';
    if (max_price) countSql += ' AND price_numeric <= ?';
    if (search) countSql += ' AND (title LIKE ? OR description LIKE ?)';
    
    const [countResult] = await query(countSql, params.slice(0, -2));

    res.json({
      success: true,
      data: {
        investments: parsedInvestments,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult.total,
          pages: Math.ceil(countResult.total / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get all investments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get investment by ID
const getInvestmentById = async (req, res) => {
  try {
    const { id } = req.params;

    const investments = await query(
      `SELECT i.*, u.name as owner_name, u.phone as owner_phone 
       FROM investments i 
       JOIN users u ON i.owner_id = u.id 
       WHERE i.id = ?`,
      [id]
    );

    if (investments.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Investment not found.'
      });
    }

    // Increment views
    await query('UPDATE investments SET view_count = view_count + 1 WHERE id = ?', [id]);

    const investment = investments[0];
    investment.images = JSON.parse(investment.images || '[]');
    investment.view_count += 1;

    res.json({
      success: true,
      data: { investment }
    });
  } catch (error) {
    console.error('Get investment by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Create investment (farmer/investor)
const createInvestment = async (req, res) => {
  try {
    const {
      title,
      description,
      type,
      location,
      area,
      price,
      price_numeric,
      contact_info,
      contact_phone,
      images,
      feasibility_study
    } = req.body;

    const result = await query(
      `INSERT INTO investments (title, description, type, location, area, price, 
       price_numeric, contact_info, contact_phone, images, feasibility_study, owner_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        description,
        type,
        location,
        area,
        price,
        price_numeric,
        contact_info,
        contact_phone,
        JSON.stringify(images),
        feasibility_study,
        req.user.id
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Investment created successfully. Waiting for approval.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Create investment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Update investment
const updateInvestment = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const userRole = req.user.role;

    // Check ownership
    const [investment] = await query('SELECT owner_id FROM investments WHERE id = ?', [id]);
    
    if (!investment) {
      return res.status(404).json({
        success: false,
        message: 'Investment not found.'
      });
    }

    if (investment.owner_id !== userId && userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied.'
      });
    }

    const {
      title,
      description,
      type,
      location,
      area,
      price,
      price_numeric,
      contact_info,
      contact_phone,
      images,
      status
    } = req.body;

    await query(
      `UPDATE investments SET title = ?, description = ?, type = ?, location = ?,
       area = ?, price = ?, price_numeric = ?, contact_info = ?, contact_phone = ?,
       images = ?, status = ? WHERE id = ?`,
      [
        title,
        description,
        type,
        location,
        area,
        price,
        price_numeric,
        contact_info,
        contact_phone,
        JSON.stringify(images),
        status,
        id
      ]
    );

    res.json({
      success: true,
      message: 'Investment updated successfully.'
    });
  } catch (error) {
    console.error('Update investment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete investment
const deleteInvestment = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const userRole = req.user.role;

    // Check ownership
    const [investment] = await query('SELECT owner_id FROM investments WHERE id = ?', [id]);
    
    if (!investment) {
      return res.status(404).json({
        success: false,
        message: 'Investment not found.'
      });
    }

    if (investment.owner_id !== userId && userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied.'
      });
    }

    await query('DELETE FROM investments WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Investment deleted successfully.'
    });
  } catch (error) {
    console.error('Delete investment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get my investments (for farmers)
const getMyInvestments = async (req, res) => {
  try {
    const userId = req.user.id;
    const { page = 1, limit = 10 } = req.query;

    let sql = 'SELECT * FROM investments WHERE owner_id = ? ORDER BY created_at DESC';
    const params = [userId];

    // Add pagination
    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const investments = await query(sql, params);

    // Parse JSON images
    const parsedInvestments = investments.map(inv => ({
      ...inv,
      images: JSON.parse(inv.images || '[]')
    }));

    // Get total count
    const [countResult] = await query(
      'SELECT COUNT(*) as total FROM investments WHERE owner_id = ?',
      [userId]
    );

    res.json({
      success: true,
      data: {
        investments: parsedInvestments,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult.total,
          pages: Math.ceil(countResult.total / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get my investments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Approve investment (admin only)
const approveInvestment = async (req, res) => {
  try {
    const { id } = req.params;

    await query('UPDATE investments SET is_approved = TRUE WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Investment approved successfully.'
    });
  } catch (error) {
    console.error('Approve investment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllInvestments,
  getInvestmentById,
  createInvestment,
  updateInvestment,
  deleteInvestment,
  getMyInvestments,
  approveInvestment
};
