const { query } = require('../config/database');

// Get all users (admin only)
const getAllUsers = async (req, res) => {
  try {
    const { role, search, page = 1, limit = 20 } = req.query;
    
    let sql = 'SELECT id, name, email, role, phone, avatar, is_active, created_at FROM users WHERE 1=1';
    const params = [];

    if (role) {
      sql += ' AND role = ?';
      params.push(role);
    }

    if (search) {
      sql += ' AND (name LIKE ? OR email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' ORDER BY created_at DESC';

    // Add pagination
    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const users = await query(sql, params);

    // Get total count
    let countSql = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
    const countParams = [];
    
    if (role) {
      countSql += ' AND role = ?';
      countParams.push(role);
    }
    if (search) {
      countSql += ' AND (name LIKE ? OR email LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }
    
    const [countResult] = await query(countSql, countParams);

    res.json({
      success: true,
      data: {
        users,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult.total,
          pages: Math.ceil(countResult.total / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get all users error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get user by ID
const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    
    const users = await query(
      'SELECT id, name, email, role, phone, avatar, is_active, created_at FROM users WHERE id = ?',
      [id]
    );

    if (users.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    res.json({
      success: true,
      data: { user: users[0] }
    });
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Update user (admin only)
const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, role, phone, is_active } = req.body;

    await query(
      'UPDATE users SET name = ?, email = ?, role = ?, phone = ?, is_active = ? WHERE id = ?',
      [name, email, role, phone, is_active, id]
    );

    const users = await query(
      'SELECT id, name, email, role, phone, avatar, is_active FROM users WHERE id = ?',
      [id]
    );

    res.json({
      success: true,
      message: 'User updated successfully.',
      data: { user: users[0] }
    });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete user (admin only)
const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    await query('DELETE FROM users WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'User deleted successfully.'
    });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get user dashboard stats
const getUserStats = async (req, res) => {
  try {
    const userId = req.user.id;
    const { role } = req.user;

    let stats = {};

    if (role === 'farmer') {
      const [investments] = await query(
        'SELECT COUNT(*) as count FROM investments WHERE owner_id = ?',
        [userId]
      );
      const [messages] = await query(
        'SELECT COUNT(*) as count FROM messages WHERE receiver_id = ? AND is_read = FALSE',
        [userId]
      );
      const [notifications] = await query(
        'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = FALSE',
        [userId]
      );
      
      stats = {
        myInvestments: investments.count,
        unreadMessages: messages.count,
        unreadNotifications: notifications.count
      };
    } else if (role === 'investor') {
      const [favorites] = await query(
        'SELECT COUNT(*) as count FROM favorites WHERE user_id = ?',
        [userId]
      );
      const [messages] = await query(
        'SELECT COUNT(*) as count FROM messages WHERE receiver_id = ? AND is_read = FALSE',
        [userId]
      );
      
      stats = {
        myFavorites: favorites.count,
        unreadMessages: messages.count
      };
    }

    res.json({
      success: true,
      data: { stats }
    });
  } catch (error) {
    console.error('Get user stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getUserStats
};
