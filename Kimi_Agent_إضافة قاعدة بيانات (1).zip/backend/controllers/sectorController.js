const { query } = require('../config/database');

// Get all sectors
const getAllSectors = async (req, res) => {
  try {
    const sectors = await query(
      'SELECT * FROM sectors WHERE is_active = TRUE ORDER BY display_order'
    );

    // Parse JSON fields
    const parsedSectors = sectors.map(sector => ({
      ...sector,
      challenges: JSON.parse(sector.challenges || '[]'),
      investment_opportunities: JSON.parse(sector.investment_opportunities || '[]')
    }));

    res.json({
      success: true,
      data: { sectors: parsedSectors }
    });
  } catch (error) {
    console.error('Get all sectors error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get sector by ID with crop types
const getSectorById = async (req, res) => {
  try {
    const { id } = req.params;

    const sectors = await query(
      'SELECT * FROM sectors WHERE id = ? AND is_active = TRUE',
      [id]
    );

    if (sectors.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Sector not found.'
      });
    }

    const sector = sectors[0];
    sector.challenges = JSON.parse(sector.challenges || '[]');
    sector.investment_opportunities = JSON.parse(sector.investment_opportunities || '[]');

    // Get crop types
    const cropTypes = await query(
      'SELECT * FROM crop_types WHERE sector_id = ? AND is_active = TRUE',
      [id]
    );

    sector.crop_types = cropTypes;

    res.json({
      success: true,
      data: { sector }
    });
  } catch (error) {
    console.error('Get sector by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Create sector (admin only)
const createSector = async (req, res) => {
  try {
    const {
      name,
      name_en,
      description,
      importance,
      challenges,
      investment_opportunities,
      image,
      icon,
      display_order
    } = req.body;

    const result = await query(
      `INSERT INTO sectors (name, name_en, description, importance, challenges, 
       investment_opportunities, image, icon, display_order) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name,
        name_en,
        description,
        importance,
        JSON.stringify(challenges),
        JSON.stringify(investment_opportunities),
        image,
        icon,
        display_order || 0
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Sector created successfully.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Create sector error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Update sector (admin only)
const updateSector = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name,
      name_en,
      description,
      importance,
      challenges,
      investment_opportunities,
      image,
      icon,
      display_order,
      is_active
    } = req.body;

    await query(
      `UPDATE sectors SET name = ?, name_en = ?, description = ?, importance = ?,
       challenges = ?, investment_opportunities = ?, image = ?, icon = ?,
       display_order = ?, is_active = ? WHERE id = ?`,
      [
        name,
        name_en,
        description,
        importance,
        JSON.stringify(challenges),
        JSON.stringify(investment_opportunities),
        image,
        icon,
        display_order,
        is_active,
        id
      ]
    );

    res.json({
      success: true,
      message: 'Sector updated successfully.'
    });
  } catch (error) {
    console.error('Update sector error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete sector (admin only)
const deleteSector = async (req, res) => {
  try {
    const { id } = req.params;

    await query('DELETE FROM sectors WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Sector deleted successfully.'
    });
  } catch (error) {
    console.error('Delete sector error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get all crop types
const getAllCropTypes = async (req, res) => {
  try {
    const { sector_id } = req.query;
    
    let sql = 'SELECT * FROM crop_types WHERE is_active = TRUE';
    const params = [];

    if (sector_id) {
      sql += ' AND sector_id = ?';
      params.push(sector_id);
    }

    sql += ' ORDER BY name';

    const cropTypes = await query(sql, params);

    res.json({
      success: true,
      data: { crop_types: cropTypes }
    });
  } catch (error) {
    console.error('Get all crop types error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllSectors,
  getSectorById,
  createSector,
  updateSector,
  deleteSector,
  getAllCropTypes
};
