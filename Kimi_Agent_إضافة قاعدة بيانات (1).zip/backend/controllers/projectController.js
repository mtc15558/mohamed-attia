const { query } = require('../config/database');

// Get all projects
const getAllProjects = async (req, res) => {
  try {
    const { status, featured, page = 1, limit = 10 } = req.query;
    
    let sql = 'SELECT * FROM projects WHERE 1=1';
    const params = [];

    if (status) {
      sql += ' AND status = ?';
      params.push(status);
    }

    if (featured === 'true') {
      sql += ' AND is_featured = TRUE';
    }

    sql += ' ORDER BY created_at DESC';

    // Add pagination
    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const projects = await query(sql, params);

    // Get total count
    let countSql = 'SELECT COUNT(*) as total FROM projects WHERE 1=1';
    if (status) countSql += ' AND status = ?';
    if (featured === 'true') countSql += ' AND is_featured = TRUE';
    
    const [countResult] = await query(countSql, params.slice(0, -2));

    res.json({
      success: true,
      data: {
        projects,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult.total,
          pages: Math.ceil(countResult.total / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get all projects error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get project by ID
const getProjectById = async (req, res) => {
  try {
    const { id } = req.params;

    const projects = await query('SELECT * FROM projects WHERE id = ?', [id]);

    if (projects.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Project not found.'
      });
    }

    // Get comments
    const comments = await query(
      `SELECT c.*, u.name as user_name, u.avatar as user_avatar 
       FROM comments c 
       JOIN users u ON c.user_id = u.id 
       WHERE c.project_id = ? AND c.is_approved = TRUE 
       ORDER BY c.created_at DESC`,
      [id]
    );

    const project = projects[0];
    project.comments = comments;

    res.json({
      success: true,
      data: { project }
    });
  } catch (error) {
    console.error('Get project by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Create project (admin only)
const createProject = async (req, res) => {
  try {
    const {
      name,
      description,
      goal,
      area,
      expected_production,
      economic_impact,
      image,
      location,
      start_date,
      end_date,
      status,
      investment_cost,
      is_featured
    } = req.body;

    const result = await query(
      `INSERT INTO projects (name, description, goal, area, expected_production,
       economic_impact, image, location, start_date, end_date, status, 
       investment_cost, is_featured) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name,
        description,
        goal,
        area,
        expected_production,
        economic_impact,
        image,
        location,
        start_date,
        end_date,
        status || 'planned',
        investment_cost,
        is_featured || false
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Project created successfully.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Update project (admin only)
const updateProject = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name,
      description,
      goal,
      area,
      expected_production,
      economic_impact,
      image,
      location,
      start_date,
      end_date,
      status,
      investment_cost,
      progress_percentage,
      is_featured
    } = req.body;

    await query(
      `UPDATE projects SET name = ?, description = ?, goal = ?, area = ?,
       expected_production = ?, economic_impact = ?, image = ?, location = ?,
       start_date = ?, end_date = ?, status = ?, investment_cost = ?,
       progress_percentage = ?, is_featured = ? WHERE id = ?`,
      [
        name,
        description,
        goal,
        area,
        expected_production,
        economic_impact,
        image,
        location,
        start_date,
        end_date,
        status,
        investment_cost,
        progress_percentage,
        is_featured,
        id
      ]
    );

    res.json({
      success: true,
      message: 'Project updated successfully.'
    });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete project (admin only)
const deleteProject = async (req, res) => {
  try {
    const { id } = req.params;

    await query('DELETE FROM projects WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Project deleted successfully.'
    });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllProjects,
  getProjectById,
  createProject,
  updateProject,
  deleteProject
};
