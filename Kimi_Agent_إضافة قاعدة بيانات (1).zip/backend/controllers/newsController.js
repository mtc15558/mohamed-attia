const { query } = require('../config/database');

// Get all news
const getAllNews = async (req, res) => {
  try {
    const { category, featured, search, page = 1, limit = 10 } = req.query;
    
    let sql = 'SELECT * FROM news WHERE is_published = TRUE';
    const params = [];

    if (category) {
      sql += ' AND category = ?';
      params.push(category);
    }

    if (featured === 'true') {
      sql += ' AND is_featured = TRUE';
    }

    if (search) {
      sql += ' AND (title LIKE ? OR content LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' ORDER BY published_at DESC';

    // Add pagination
    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const news = await query(sql, params);

    // Get total count
    let countSql = 'SELECT COUNT(*) as total FROM news WHERE is_published = TRUE';
    if (category) countSql += ' AND category = ?';
    if (featured === 'true') countSql += ' AND is_featured = TRUE';
    if (search) countSql += ' AND (title LIKE ? OR content LIKE ?)';
    
    const [countResult] = await query(countSql, params.slice(0, -2));

    res.json({
      success: true,
      data: {
        news,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult.total,
          pages: Math.ceil(countResult.total / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get all news error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get news by ID
const getNewsById = async (req, res) => {
  try {
    const { id } = req.params;

    const news = await query('SELECT * FROM news WHERE id = ? AND is_published = TRUE', [id]);

    if (news.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'News not found.'
      });
    }

    // Increment views
    await query('UPDATE news SET views = views + 1 WHERE id = ?', [id]);

    // Get comments
    const comments = await query(
      `SELECT c.*, u.name as user_name, u.avatar as user_avatar 
       FROM comments c 
       JOIN users u ON c.user_id = u.id 
       WHERE c.news_id = ? AND c.is_approved = TRUE 
       ORDER BY c.created_at DESC`,
      [id]
    );

    const newsItem = news[0];
    newsItem.comments = comments;
    newsItem.views += 1;

    res.json({
      success: true,
      data: { news: newsItem }
    });
  } catch (error) {
    console.error('Get news by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Create news (admin only)
const createNews = async (req, res) => {
  try {
    const {
      title,
      content,
      summary,
      image,
      category,
      author,
      is_featured,
      is_published,
      meta_keywords,
      meta_description
    } = req.body;

    const result = await query(
      `INSERT INTO news (title, content, summary, image, category, author, 
       author_id, is_featured, is_published, meta_keywords, meta_description) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        content,
        summary,
        image,
        category,
        author,
        req.user?.id,
        is_featured || false,
        is_published !== false,
        meta_keywords,
        meta_description
      ]
    );

    res.status(201).json({
      success: true,
      message: 'News created successfully.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Create news error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Update news (admin only)
const updateNews = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      content,
      summary,
      image,
      category,
      author,
      is_featured,
      is_published,
      meta_keywords,
      meta_description
    } = req.body;

    await query(
      `UPDATE news SET title = ?, content = ?, summary = ?, image = ?,
       category = ?, author = ?, is_featured = ?, is_published = ?,
       meta_keywords = ?, meta_description = ? WHERE id = ?`,
      [
        title,
        content,
        summary,
        image,
        category,
        author,
        is_featured,
        is_published,
        meta_keywords,
        meta_description,
        id
      ]
    );

    res.json({
      success: true,
      message: 'News updated successfully.'
    });
  } catch (error) {
    console.error('Update news error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete news (admin only)
const deleteNews = async (req, res) => {
  try {
    const { id } = req.params;

    await query('DELETE FROM news WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'News deleted successfully.'
    });
  } catch (error) {
    console.error('Delete news error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllNews,
  getNewsById,
  createNews,
  updateNews,
  deleteNews
};
