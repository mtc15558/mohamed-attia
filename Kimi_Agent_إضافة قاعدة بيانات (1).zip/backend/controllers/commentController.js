const { query } = require('../config/database');

// Get all comments (admin)
const getAllComments = async (req, res) => {
  try {
    const { is_approved, page = 1, limit = 20 } = req.query;
    
    let sql = `
      SELECT c.*, u.name as user_name, u.avatar as user_avatar,
             p.name as project_name, i.title as investment_title
      FROM comments c
      JOIN users u ON c.user_id = u.id
      LEFT JOIN projects p ON c.project_id = p.id
      LEFT JOIN investments i ON c.investment_id = i.id
      WHERE 1=1
    `;
    const params = [];

    if (is_approved !== undefined) {
      sql += ' AND c.is_approved = ?';
      params.push(is_approved === 'true');
    }

    sql += ' ORDER BY c.created_at DESC';

    // Add pagination
    const offset = (page - 1) * limit;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const comments = await query(sql, params);

    res.json({
      success: true,
      data: { comments }
    });
  } catch (error) {
    console.error('Get all comments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Create comment
const createComment = async (req, res) => {
  try {
    const { project_id, investment_id, news_id, content, rating } = req.body;
    const userId = req.user.id;

    // Check if at least one entity is specified
    if (!project_id && !investment_id && !news_id) {
      return res.status(400).json({
        success: false,
        message: 'Please specify project_id, investment_id, or news_id.'
      });
    }

    const result = await query(
      `INSERT INTO comments (user_id, project_id, investment_id, news_id, content, rating) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [userId, project_id, investment_id, news_id, content, rating]
    );

    res.status(201).json({
      success: true,
      message: 'Comment submitted successfully. Waiting for approval.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Create comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Approve comment (admin only)
const approveComment = async (req, res) => {
  try {
    const { id } = req.params;

    await query('UPDATE comments SET is_approved = TRUE WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Comment approved successfully.'
    });
  } catch (error) {
    console.error('Approve comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete comment
const deleteComment = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const userRole = req.user.role;

    // Check ownership
    const [comment] = await query('SELECT user_id FROM comments WHERE id = ?', [id]);
    
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found.'
      });
    }

    if (comment.user_id !== userId && userRole !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied.'
      });
    }

    await query('DELETE FROM comments WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Comment deleted successfully.'
    });
  } catch (error) {
    console.error('Delete comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getAllComments,
  createComment,
  approveComment,
  deleteComment
};
