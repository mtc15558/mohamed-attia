const { query } = require('../config/database');

// Get my messages
const getMyMessages = async (req, res) => {
  try {
    const userId = req.user.id;
    const { type = 'all' } = req.query;

    let sql = `
      SELECT m.*, 
             s.name as sender_name, s.avatar as sender_avatar,
             r.name as receiver_name, r.avatar as receiver_avatar
      FROM messages m
      JOIN users s ON m.sender_id = s.id
      JOIN users r ON m.receiver_id = r.id
      WHERE m.sender_id = ? OR m.receiver_id = ?
    `;
    const params = [userId, userId];

    if (type === 'sent') {
      sql = `
        SELECT m.*, 
               r.name as receiver_name, r.avatar as receiver_avatar
        FROM messages m
        JOIN users r ON m.receiver_id = r.id
        WHERE m.sender_id = ?
      `;
      params.length = 1;
    } else if (type === 'received') {
      sql = `
        SELECT m.*, 
               s.name as sender_name, s.avatar as sender_avatar
        FROM messages m
        JOIN users s ON m.sender_id = s.id
        WHERE m.receiver_id = ?
      `;
      params.length = 1;
    }

    sql += ' ORDER BY m.created_at DESC';

    const messages = await query(sql, params);

    res.json({
      success: true,
      data: { messages }
    });
  } catch (error) {
    console.error('Get my messages error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Get conversation with user
const getConversation = async (req, res) => {
  try {
    const userId = req.user.id;
    const { otherUserId } = req.params;

    const messages = await query(
      `
      SELECT m.*, 
             s.name as sender_name, s.avatar as sender_avatar,
             r.name as receiver_name, r.avatar as receiver_avatar
      FROM messages m
      JOIN users s ON m.sender_id = s.id
      JOIN users r ON m.receiver_id = r.id
      WHERE (m.sender_id = ? AND m.receiver_id = ?) 
         OR (m.sender_id = ? AND m.receiver_id = ?)
      ORDER BY m.created_at ASC
      `,
      [userId, otherUserId, otherUserId, userId]
    );

    // Mark messages as read
    await query(
      'UPDATE messages SET is_read = TRUE, read_at = NOW() WHERE sender_id = ? AND receiver_id = ? AND is_read = FALSE',
      [otherUserId, userId]
    );

    res.json({
      success: true,
      data: { messages }
    });
  } catch (error) {
    console.error('Get conversation error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Send message
const sendMessage = async (req, res) => {
  try {
    const { receiver_id, content } = req.body;
    const senderId = req.user.id;

    // Check if receiver exists
    const [receiver] = await query('SELECT id FROM users WHERE id = ?', [receiver_id]);
    if (!receiver) {
      return res.status(404).json({
        success: false,
        message: 'Receiver not found.'
      });
    }

    const result = await query(
      'INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)',
      [senderId, receiver_id, content]
    );

    // Create notification for receiver
    await query(
      'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)',
      [receiver_id, 'رسالة جديدة', `لديك رسالة جديدة من ${req.user.name}`, 'info']
    );

    res.status(201).json({
      success: true,
      message: 'Message sent successfully.',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

// Delete message
const deleteMessage = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    // Check ownership
    const [message] = await query(
      'SELECT sender_id FROM messages WHERE id = ?',
      [id]
    );

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found.'
      });
    }

    if (message.sender_id !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied.'
      });
    }

    await query('DELETE FROM messages WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Message deleted successfully.'
    });
  } catch (error) {
    console.error('Delete message error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error.'
    });
  }
};

module.exports = {
  getMyMessages,
  getConversation,
  sendMessage,
  deleteMessage
};
