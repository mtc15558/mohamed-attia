-- ============================================
-- قاعدة بيانات القطاع الزراعي المصري
-- Egyptian Agricultural Sector Database
-- ============================================

CREATE DATABASE IF NOT EXISTS agricultural_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE agricultural_system;

-- ============================================
-- 1. جدول المستخدمين (Users)
-- ============================================
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'farmer', 'investor', 'student') DEFAULT 'student',
    phone VARCHAR(20),
    avatar VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. جدول القطاعات الزراعية (Sectors)
-- ============================================
CREATE TABLE sectors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    description TEXT,
    importance TEXT,
    challenges JSON,
    investment_opportunities JSON,
    image VARCHAR(255),
    icon VARCHAR(50),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. جدول أنواع المحاصيل (Crop Types)
-- ============================================
CREATE TABLE crop_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sector_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    image VARCHAR(255),
    production_area VARCHAR(255),
    season VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sector_id) REFERENCES sectors(id) ON DELETE CASCADE,
    INDEX idx_sector (sector_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. جدول المشروعات القومية (Projects)
-- ============================================
CREATE TABLE projects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    goal TEXT,
    area VARCHAR(100),
    expected_production VARCHAR(200),
    economic_impact TEXT,
    image VARCHAR(255),
    location VARCHAR(200),
    start_date DATE,
    end_date DATE,
    status ENUM('active', 'completed', 'planned', 'on_hold') DEFAULT 'planned',
    investment_cost VARCHAR(100),
    progress_percentage INT DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_featured (is_featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 5. جدول الأخبار (News)
-- ============================================
CREATE TABLE news (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(300) NOT NULL,
    content TEXT NOT NULL,
    summary VARCHAR(500),
    image VARCHAR(255),
    category VARCHAR(50),
    author VARCHAR(100),
    author_id INT,
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    views INT DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    is_published BOOLEAN DEFAULT TRUE,
    meta_keywords VARCHAR(500),
    meta_description VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_category (category),
    INDEX idx_featured (is_featured),
    INDEX idx_published (is_published),
    INDEX idx_published_at (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 6. جدول فرص الاستثمار (Investments)
-- ============================================
CREATE TABLE investments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    type ENUM('land_sale', 'land_rent', 'small_project', 'partnership') NOT NULL,
    location VARCHAR(200),
    area VARCHAR(100),
    price VARCHAR(100),
    price_numeric DECIMAL(15, 2),
    contact_info VARCHAR(200),
    contact_phone VARCHAR(20),
    images JSON,
    feasibility_study VARCHAR(255),
    owner_id INT NOT NULL,
    status ENUM('available', 'sold', 'rented', 'pending') DEFAULT 'available',
    view_count INT DEFAULT 0,
    is_approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_type (type),
    INDEX idx_status (status),
    INDEX idx_owner (owner_id),
    INDEX idx_price (price_numeric)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 7. جدول الإحصائيات (Statistics)
-- ============================================
CREATE TABLE statistics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    year INT NOT NULL,
    crop_name VARCHAR(100) NOT NULL,
    production_tons DECIMAL(15, 2) DEFAULT 0,
    area_feddans DECIMAL(15, 2) DEFAULT 0,
    export_value DECIMAL(15, 2) DEFAULT 0,
    import_value DECIMAL(15, 2) DEFAULT 0,
    average_price_per_ton DECIMAL(10, 2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_year_crop (year, crop_name),
    INDEX idx_year (year),
    INDEX idx_crop (crop_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 8. جدول التعليقات (Comments)
-- ============================================
CREATE TABLE comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    project_id INT,
    investment_id INT,
    news_id INT,
    content TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    is_approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (investment_id) REFERENCES investments(id) ON DELETE CASCADE,
    FOREIGN KEY (news_id) REFERENCES news(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_project (project_id),
    INDEX idx_investment (investment_id),
    INDEX idx_approved (is_approved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 9. جدول الرسائل (Messages)
-- ============================================
CREATE TABLE messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sender (sender_id),
    INDEX idx_receiver (receiver_id),
    INDEX idx_is_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 10. جدول التنبيهات (Notifications)
-- ============================================
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
    link VARCHAR(255),
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 11. جدول الإرشادات الزراعية (Guidance)
-- ============================================
CREATE TABLE guidance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category ENUM('irrigation', 'pest_control', 'fertilization', 'soil', 'harvesting', 'storage') NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    image VARCHAR(255),
    video_url VARCHAR(500),
    pdf_url VARCHAR(500),
    author_id INT,
    view_count INT DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_category (category),
    INDEX idx_published (is_published)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 12. جدول المفضلة (Favorites)
-- ============================================
CREATE TABLE favorites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    investment_id INT,
    project_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (investment_id) REFERENCES investments(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_investment (user_id, investment_id),
    UNIQUE KEY unique_user_project (user_id, project_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 13. جدول أسعار المحاصيل اليومية (Crop Prices)
-- ============================================
CREATE TABLE crop_prices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    crop_name VARCHAR(100) NOT NULL,
    price_per_kg DECIMAL(10, 2) NOT NULL,
    market_name VARCHAR(100),
    market_location VARCHAR(200),
    price_date DATE NOT NULL,
    price_change_percentage DECIMAL(5, 2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_crop (crop_name),
    INDEX idx_date (price_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 14. جدول سجل النشاطات (Activity Log)
-- ============================================
CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    details JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- إدراج البيانات الأولية
-- ============================================

-- المستخدمين
INSERT INTO users (name, email, password, role, phone, avatar, is_active) VALUES
('المدير العام', 'admin@agri.gov.eg', '$2b$10$YourHashedPasswordHere', 'admin', '01001234567', 'https://ui-avatars.com/api/?name=Admin&background=2d5a27&color=fff', TRUE),
('أحمد محمود', 'farmer@example.com', '$2b$10$YourHashedPasswordHere', 'farmer', '01012345678', 'https://ui-avatars.com/api/?name=Ahmed+M&background=4a7c43&color=fff', TRUE),
('محمد علي', 'investor@example.com', '$2b$10$YourHashedPasswordHere', 'investor', '01023456789', 'https://ui-avatars.com/api/?name=Mohamed+A&background=d4a574&color=fff', TRUE),
('سارة أحمد', 'student@example.com', '$2b$10$YourHashedPasswordHere', 'student', '01034567890', 'https://ui-avatars.com/api/?name=Sara+A&background=8b7355&color=fff', TRUE),
('خالد حسن', 'khaled@example.com', '$2b$10$YourHashedPasswordHere', 'farmer', '01045678901', 'https://ui-avatars.com/api/?name=Khaled+H&background=2d5a27&color=fff', TRUE),
('فاطمة محمود', 'fatma@example.com', '$2b$10$YourHashedPasswordHere', 'investor', '01056789012', 'https://ui-avatars.com/api/?name=Fatma+M&background=4a7c43&color=fff', TRUE);

-- القطاعات الزراعية
INSERT INTO sectors (name, name_en, description, importance, challenges, investment_opportunities, image, icon, display_order) VALUES
('الزراعة النباتية', 'Crop Agriculture', 'تشمل زراعة المحاصيل الأساسية مثل القمح والذرة والأرز والخضروات والفاكهة', 'توفر الأمن الغذائي وتدعم الاقتصاد الوطني من خلال الصادرات الزراعية', '["نقص المياه", "التغيرات المناخية", "الآفات الزراعية", "ارتفاع تكاليف الإنتاج"]', '["الصوب الزراعية الحديثة", "الزراعة العضوية", "تصنيع المحاصيل"]', '/images/sectors/crops.jpg', 'Wheat', 1),
('الإنتاج الحيواني', 'Animal Production', 'تربية الماشية وإنتاج اللحوم والألبان', 'توفير البروتين الحيواني ودعم الاقتصاد', '["ارتفاع أسعار الأعلاف", "الأمراض", "نقص الرعاية البيطرية"]', '["مزارع تربية المواشي", "مصانع الألبان", "مجازر حديثة"]', '/images/sectors/animal.jpg', 'Beef', 2),
('الإنتاج الداجني', 'Poultry Production', 'تربية الدواجن لإنتاج اللحوم والبيض', 'أهم مصدر للبروتين الحيواني بأسعار مقبولة', '["أنفلونزا الطيور", "تكاليف التبريد", "المنافسة"]', '["مزارع دواجن متكاملة", "مصانع الأعلاف", "مجازر دواجن"]', '/images/sectors/poultry.jpg', 'Egg', 3),
('الثروة السمكية', 'Fisheries', 'تربية الأسماك في المزارع السمكية والصيد من البحار والبحيرات', 'توفير البروتين السمكي وزيادة الصادرات', '["تلوث المياه", "نقص التفريخ", "الصيد الجائر"]', '["مزارع سمكية", "أقفاص عائمة", "مصانع تعليب"]', '/images/sectors/fish.jpg', 'Fish', 4),
('الزراعة العضوية', 'Organic Agriculture', 'زراعة خالية من الكيماويات والمبيدات', 'صحة الإنسان وحماية البيئة', '["ارتفاع التكاليف", "قلة الوعي", "صعوبة التسويق"]', '["مزارع عضوية", "أسواق متخصصة", "تصدير"]', '/images/sectors/organic.jpg', 'Leaf', 5),
('الصوب الزراعية', 'Greenhouses', 'زراعة محمية داخل صوب زراعية حديثة', 'إنتاج على مدار العام مع جودة عالية', '["التكلفة الأولية", "الطاقة", "التدريب"]', '["صوب ذكية", "طاقة شمسية", "تقنيات IoT"]', '/images/sectors/greenhouse.jpg', 'Warehouse', 6);

-- أنواع المحاصيل
INSERT INTO crop_types (sector_id, name, description, image, production_area, season) VALUES
(1, 'القمح', 'أهم محصول غذائي في مصر', '/images/crops/wheat.jpg', 'الدلتا والوادي', 'الشتاء'),
(1, 'الذرة', 'محصول استراتيجي للأعلاف', '/images/crops/corn.jpg', 'الوجه البحري', 'الصيف'),
(1, 'الأرز', 'المحصول الرئيسي في الدلتا', '/images/crops/rice.jpg', 'محافظات الدلتا', 'الصيف'),
(1, 'الخضروات', 'تنوع كبير في المحاصيل', '/images/crops/vegetables.jpg', 'جميع المحافظات', 'على مدار العام'),
(1, 'الفاكهة', 'من أهم الصادرات الزراعية', '/images/crops/fruits.jpg', 'الوجه البحري والصعيد', 'حسب النوع');

-- المشروعات القومية
INSERT INTO projects (name, description, goal, area, expected_production, economic_impact, image, location, start_date, status, investment_cost, progress_percentage, is_featured) VALUES
('مشروع الدلتا الجديدة', 'أضخم مشروع استصلاح زراعي في مصر بمنطقة غرب الدلتا', 'استصلاح 2 مليون فدان لسد الفجوة الغذائية', '2,000,000 فدان', '15 مليون طن سنوياً', 'إنشاء 5 ملايين فرصة عمل', '/images/projects/delta.jpg', 'غرب الدلتا', '2021-01-01', 'active', '300 مليار جنيه', 65, TRUE),
('مشروع توشكى', 'استصلاح أراضي جنوب الوادي', 'استصلاح 1.5 مليون فدان', '1,500,000 فدان', '10 مليون طن سنوياً', 'تنمية جنوب الوادي', '/images/projects/toshka.jpg', 'جنوب الوادي', '2020-01-01', 'active', '200 مليار جنيه', 70, TRUE),
('مشروع مستقبل مصر', 'استصلاح أراضي غرب غرب النوبارية', 'استصلاح 3 ملايين فدان', '3,000,000 فدان', '25 مليون طن سنوياً', 'أكبر مشروع زراعي في العالم', '/images/projects/future.jpg', 'غرب النوبارية', '2022-01-01', 'active', '500 مليار جنيه', 45, TRUE),
('مشروع 100 ألف صوبة', 'إنشاء صوب زراعية حديثة', 'زيادة الإنتاجية وتحسين الجودة', '100,000 صوبة', '5 مليون طن خضروات', 'توفير احتياجات السوق المحلي', '/images/projects/greenhouses.jpg', 'جميع المحافظات', '2023-01-01', 'active', '100 مليار جنيه', 80, TRUE),
('مشروع استصلاح الأراضي', 'استصلاح الأراضي الصحراوية', 'إضافة 4 ملايين فدان', '4,000,000 فدان', '30 مليون طن سنوياً', 'تعظيم الاستفادة من الموارد', '/images/projects/reclamation.jpg', 'جميع أنحاء مصر', '2019-01-01', 'active', '400 مليار جنيه', 55, FALSE);

-- الأخبار
INSERT INTO news (title, content, summary, image, category, author, views, is_featured) VALUES
('مصر تحقق الاكتفاء الذاتي من القمح بنسبة 60%', 'أعلنت وزارة الزراعة المصرية عن تحقيق نسبة 60% من الاكتفاء الذاتي من القمح هذا العام بفضل المشروعات القومية الكبرى...', 'زيادة إنتاج القمح بنسبة 15% عن العام الماضي', '/images/news/wheat.jpg', 'إنتاج', 'وزارة الزراعة', 15234, TRUE),
('افتتاح أكبر مجمع للإنتاج الحيواني في الشرق الأوسط', 'تم افتتاح مجمع البELLA الزراعي كأكبر مجمع متكامل للإنتاج الحيواني في منطقة الشرق الأوسط...', 'استثمارات تصل إلى 5 مليارات جنيه', '/images/news/animal.jpg', 'مشروعات', 'الهيئة العامة للاستثمار', 12345, TRUE),
('أسعار الخضروات اليوم في سوق العبور', 'شهدت أسعار الخضروات استقراراً نسبياً اليوم في سوق العبور مع انخفاض في أسعار الطماطم والخيار...', 'انخفاض أسعار الطماطم والخيار', '/images/news/vegetables.jpg', 'أسعار', 'سوق العبور', 9876, FALSE),
('مصر تتصدر قائمة الدول المصدرة للحاصلات الزراعية', 'حققت مصر قفزة كبيرة في الصادرات الزراعية خلال النصف الأول من العام الحالي...', '6.5 مليون طن صادرات زراعية', '/images/news/exports.jpg', 'تصدير', 'هيئة التنمية الصادرات', 8765, TRUE),
('قرار وزاري بشأن مكافحة الآفات الزراعية', 'أصدر وزير الزراعة قراراً بشأن تطبيق برامج متكاملة لمكافحة الآفات الزراعية...', 'خطة شاملة لمكافحة الآفات', '/images/news/pests.jpg', 'قرارات', 'وزارة الزراعة', 7654, FALSE),
('معرض القاهرة الدولي للزراعة 2024', 'ينطلق معرض القاهرة الدولي للزراعة بمشاركة أكثر من 500 شركة من 30 دولة...', 'أكبر تجمع زراعي في المنطقة', '/images/news/exhibition.jpg', 'معارض', 'غرفة الزراعة', 6543, FALSE);

-- فرص الاستثمار
INSERT INTO investments (title, description, type, location, area, price, price_numeric, contact_info, contact_phone, images, owner_id, status, is_approved) VALUES
('أرض زراعية للبيع - الوادي الجديد', 'أرض صالحة للزراعة بمساحة 50 فدان مع بئر ماء وكهرباء', 'land_sale', 'الوادي الجديد', '50 فدان', '5,000,000 جنيه', 5000000, 'أحمد محمود', '01001234567', '["/images/investments/land1.jpg"]', 2, 'available', TRUE),
('مزرعة دواجن للإيجار - المنوفية', 'مزرعة دواجن مجهزة بالكامل مع جميع التراخيص', 'land_rent', 'المنوفية', '10 أفدنة', '50,000 جنيه/شهر', 50000, 'محمد علي', '01002345678', '["/images/investments/poultry.jpg"]', 2, 'available', TRUE),
('مشروع صوب زراعية - للشراكة', 'مشروع إنشاء 10 صوب زراعية حديثة', 'small_project', 'البحيرة', NULL, '2,000,000 جنيه', 2000000, 'سارة أحمد', '01003456789', '["/images/investments/greenhouse.jpg"]', 3, 'available', TRUE),
('أرض زراعية - استثمار طويل الأجل', 'أرض مميزة لزراعة المحاصيل الاستراتيجية', 'land_sale', 'كفر الشيخ', '100 فدان', '12,000,000 جنيه', 12000000, 'علي حسن', '01004567890', '["/images/investments/land2.jpg"]', 5, 'available', TRUE),
('مزرعة سمكية للبيع - كفر الشيخ', 'مزرعة سمكية متكاملة مع أحواض ومعدات', 'land_sale', 'كفر الشيخ', '20 فدان', '8,000,000 جنيه', 8000000, 'خالد حسن', '01005678901', '["/images/investments/fish.jpg"]', 5, 'available', TRUE);

-- الإحصائيات
INSERT INTO statistics (year, crop_name, production_tons, area_feddans, export_value, import_value) VALUES
(2020, 'القمح', 9000000, 3200000, 0, 2500000000),
(2021, 'القمح', 9500000, 3300000, 0, 2300000000),
(2022, 'القمح', 10000000, 3400000, 0, 2000000000),
(2023, 'القمح', 11000000, 3600000, 50000000, 1800000000),
(2024, 'القمح', 12000000, 3800000, 100000000, 1500000000),
(2020, 'الأرز', 6000000, 2800000, 200000000, 0),
(2021, 'الأرز', 6200000, 2900000, 250000000, 0),
(2022, 'الأرز', 6500000, 3000000, 300000000, 0),
(2023, 'الأرز', 6800000, 3100000, 350000000, 0),
(2024, 'الأرز', 7000000, 3200000, 400000000, 0),
(2020, 'الذرة', 8000000, 2500000, 100000000, 500000000),
(2021, 'الذرة', 8500000, 2600000, 120000000, 450000000),
(2022, 'الذرة', 9000000, 2700000, 150000000, 400000000),
(2023, 'الذرة', 9500000, 2800000, 180000000, 350000000),
(2024, 'الذرة', 10000000, 2900000, 200000000, 300000000);

-- الإرشادات الزراعية
INSERT INTO guidance (category, title, content, image, author_id) VALUES
('irrigation', 'نظم الري الحديثة', 'تعتبر نظم الري الحديثة من أهم عوامل ترشيد استهلاك المياه في الزراعة. تشمل هذه النظم الري بالتنقيط والري بالرش...', '/images/guidance/irrigation.jpg', 1),
('pest_control', 'مكافحة الآفات المتكاملة', 'تعتمد المكافحة المتكاملة على استخدام عدة طرق معاً للتحكم في الآفات بشكل فعال ومستدام...', '/images/guidance/pests.jpg', 1),
('fertilization', 'التسميد العقلاني', 'التسميد العقلاني يعتمد على تحليل التربة وتحديد الاحتياجات الفعلية للنبات...', '/images/guidance/fertilizer.jpg', 1),
('soil', 'تحسين خصوبة التربة', 'تحسين خصوبة التربة يبدأ بفهم تركيبها وخصائصها الفيزيائية والكيميائية...', '/images/guidance/soil.jpg', 1);

-- أسعار المحاصيل
INSERT INTO crop_prices (crop_name, price_per_kg, market_name, market_location, price_date, price_change_percentage) VALUES
('طماطم', 8.50, 'سوق العبور', 'القاهرة', CURDATE(), -2.5),
('خيار', 6.75, 'سوق العبور', 'القاهرة', CURDATE(), 1.2),
('بطاطس', 12.00, 'سوق العبور', 'القاهرة', CURDATE(), 0.5),
('بصل', 15.50, 'سوق العبور', 'القاهرة', CURDATE(), -1.8),
('فلفل', 18.00, 'سوق العبور', 'القاهرة', CURDATE(), 3.2);

-- ============================================
-- إنشاء Views للتقارير
-- ============================================

CREATE VIEW dashboard_stats AS
SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM projects) as total_projects,
    (SELECT COUNT(*) FROM investments WHERE status = 'available') as total_investments,
    (SELECT COUNT(*) FROM news) as total_news,
    (SELECT COUNT(*) FROM comments WHERE is_approved = FALSE) as pending_comments;

CREATE VIEW monthly_user_growth AS
SELECT 
    DATE_FORMAT(created_at, '%Y-%m') as month,
    COUNT(*) as new_users
FROM users
GROUP BY DATE_FORMAT(created_at, '%Y-%m')
ORDER BY month DESC;

-- ============================================
-- إنشاء Triggers
-- ============================================

DELIMITER //

CREATE TRIGGER after_user_insert 
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details)
    VALUES (NEW.id, 'user_registered', 'user', NEW.id, JSON_OBJECT('email', NEW.email, 'role', NEW.role));
END//

CREATE TRIGGER after_investment_insert 
AFTER INSERT ON investments
FOR EACH ROW
BEGIN
    INSERT INTO notifications (user_id, title, message, type, link)
    VALUES (NEW.owner_id, 'تم إضافة إعلان جديد', CONCAT('تم إضافة إعلانك: ', NEW.title), 'success', CONCAT('/investments/', NEW.id));
END//

DELIMITER ;

-- ============================================
-- إنشاء Stored Procedures
-- ============================================

DELIMITER //

CREATE PROCEDURE GetUserDashboardStats(IN userId INT)
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM investments WHERE owner_id = userId) as my_investments,
        (SELECT COUNT(*) FROM messages WHERE receiver_id = userId AND is_read = FALSE) as unread_messages,
        (SELECT COUNT(*) FROM notifications WHERE user_id = userId AND is_read = FALSE) as unread_notifications,
        (SELECT COUNT(*) FROM favorites WHERE user_id = userId) as my_favorites;
END//

CREATE PROCEDURE GetCropStatistics(IN cropName VARCHAR(100), IN startYear INT, IN endYear INT)
BEGIN
    SELECT * FROM statistics 
    WHERE crop_name = cropName AND year BETWEEN startYear AND endYear
    ORDER BY year;
END//

CREATE PROCEDURE SearchInvestments(IN searchQuery VARCHAR(255), IN investmentType VARCHAR(50), IN maxPrice DECIMAL(15,2))
BEGIN
    SELECT i.*, u.name as owner_name, u.phone as owner_phone 
    FROM investments i
    JOIN users u ON i.owner_id = u.id
    WHERE i.status = 'available' AND i.is_approved = TRUE
    AND (i.title LIKE CONCAT('%', searchQuery, '%') OR i.description LIKE CONCAT('%', searchQuery, '%'))
    AND (investmentType = 'all' OR i.type = investmentType)
    AND (maxPrice IS NULL OR i.price_numeric <= maxPrice)
    ORDER BY i.created_at DESC;
END//

DELIMITER ;

-- ============================================
-- منح الصلاحيات
-- ============================================

-- إنشاء مستخدم للتطبيق
CREATE USER IF NOT EXISTS 'agri_app'@'localhost' IDENTIFIED BY 'AgriApp@2024#';

GRANT SELECT, INSERT, UPDATE, DELETE ON agricultural_system.* TO 'agri_app'@'localhost';
GRANT EXECUTE ON agricultural_system.* TO 'agri_app'@'localhost';

FLUSH PRIVILEGES;
