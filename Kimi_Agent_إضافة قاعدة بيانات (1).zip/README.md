# 🌾 القطاع الزراعي المصري - Egyptian Agricultural Sector

منصة متكاملة للقطاع الزراعي المصري - نظام شامل يشمل Frontend و Backend وقاعدة بيانات MySQL.

## 📁 Project Structure

```
agricultural-system/
├── app/                          # Frontend (React + TypeScript + Vite)
│   ├── src/
│   │   ├── components/          # React components
│   │   ├── sections/            # Page sections
│   │   ├── services/            # API services
│   │   ├── hooks/               # Custom hooks
│   │   ├── types/               # TypeScript types
│   │   └── data/                # Mock data (for development)
│   ├── public/                  # Static assets
│   └── package.json
├── backend/                      # Backend (Node.js + Express)
│   ├── controllers/             # Route controllers
│   ├── routes/                  # API routes
│   ├── middleware/              # Custom middleware
│   ├── config/                  # Configuration files
│   └── package.json
├── database/                     # Database files
│   └── agricultural_system.sql  # MySQL database schema
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- Node.js (v16 or higher)
- MySQL (v8.0 or higher)
- npm or yarn

### 1. Setup Database

```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE agricultural_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Import schema
mysql -u root -p agricultural_system < database/agricultural_system.sql
```

### 2. Setup Backend

```bash
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env
# Edit .env with your database credentials

# Start server
npm run dev
```

Backend will run on `http://localhost:5000`

### 3. Setup Frontend

```bash
cd app

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend will run on `http://localhost:5173`

## 🔑 Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@agri.gov.eg | admin123 |
| Farmer | farmer@example.com | farmer123 |
| Investor | investor@example.com | investor123 |
| Student | student@example.com | student123 |

## 📚 API Documentation

See [backend/README.md](backend/README.md) for detailed API documentation.

## 🛠️ Technologies

### Frontend
- React 18
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui
- Recharts
- Lucide React

### Backend
- Node.js
- Express
- MySQL2
- JWT Authentication
- bcryptjs
- express-validator

### Database
- MySQL 8.0
- UTF-8 Unicode support

## 📋 Features

### ✅ Implemented
- [x] User authentication (Login/Register)
- [x] Role-based access control
- [x] Agricultural sectors management
- [x] National projects showcase
- [x] Investment opportunities
- [x] News & articles system
- [x] Statistics & charts
- [x] Comments & ratings
- [x] Messaging system
- [x] Notifications
- [x] Admin dashboard
- [x] Farmer dashboard
- [x] Investor dashboard

## 🔒 Security

- JWT-based authentication
- Password hashing with bcrypt
- Rate limiting
- CORS protection
- Helmet security headers
- Input validation

## 📄 License

MIT License

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

Made with ❤️ for Egypt's Agricultural Sector
