#!/bin/bash

echo "=========================================="
echo "   🌾 Agricultural System Setup"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org"
    exit 1
fi

echo "✅ Node.js is installed: $(node --version)"

# Setup Backend
echo ""
echo "📦 Setting up Backend..."
cd backend

if [ ! -d "node_modules" ]; then
    echo "Installing backend dependencies..."
    npm install
else
    echo "Backend dependencies already installed"
fi

echo ""
echo "🚀 Starting Backend Server..."
npm start &
BACKEND_PID=$!
cd ..

# Setup Frontend
echo ""
echo "📦 Setting up Frontend..."
cd app

if [ ! -d "node_modules" ]; then
    echo "Installing frontend dependencies..."
    npm install
else
    echo "Frontend dependencies already installed"
fi

echo ""
echo "🚀 Starting Frontend Server..."
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "=========================================="
echo "   ✅ Setup Complete!"
echo "=========================================="
echo ""
echo "Frontend: http://localhost:5173"
echo "Backend:  http://localhost:5000"
echo ""
echo "Default Login:"
echo "   Admin:    admin@agri.gov.eg / admin123"
echo "   Farmer:   farmer@example.com / farmer123"
echo "   Investor: investor@example.com / investor123"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait for both processes
wait $BACKEND_PID
wait $FRONTEND_PID
