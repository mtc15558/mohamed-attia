# 🌾 دليل تشغيل نظام القطاع الزراعي

## ⚡ الطريقة السريعة (بدون قاعدة بيانات)

### 1. تشغيل Backend

```bash
cd backend
npm install
node server-simple.js
```

السيرفر سيعمل على: http://localhost:5000

### 2. تشغيل Frontend

في Terminal جديد:

```bash
cd app
npm install
npm run dev
```

الموقع سيعمل على: http://localhost:5173

---

## 🔑 بيانات الدخول

| الدور | البريد | كلمة المرور |
|-------|--------|-------------|
| Admin | admin@agri.gov.eg | admin123 |
| Farmer | farmer@example.com | farmer123 |
| Investor | investor@example.com | investor123 |
| Student | student@example.com | student123 |

---

## 🗄️ الطريقة الكاملة (مع MySQL)

### 1. تثبيت MySQL

- Windows: حمل XAMPP من https://www.apachefriends.org
- Mac: `brew install mysql`
- Linux: `sudo apt install mysql-server`

### 2. إنشاء قاعدة البيانات

```bash
mysql -u root -p
```

```sql
CREATE DATABASE agricultural_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

```bash
mysql -u root -p agricultural_system < database/agricultural_system.sql
```

### 3. تعديل إعدادات Backend

افتح `backend/.env` وعدل:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=agricultural_system
```

### 4. تشغيل Backend الكامل

```bash
cd backend
npm install
node server.js
```

---

## 🐳 الطريقة الثالثة (Docker)

```bash
docker-compose up -d
```

سيتم تشغيل:
- MySQL على port 3306
- Backend على port 5000
- Frontend على port 3000

---

## 📁 هيكل المشروع

```
agricultural-system/
├── app/                    # Frontend (React)
│   └── npm run dev        # تشغيل
├── backend/               # Backend (Node.js)
│   ├── server-simple.js   # بدون قاعدة بيانات
│   └── server.js          # مع قاعدة بيانات
├── database/              # ملفات SQL
└── docker-compose.yml     # Docker
```

---

## 🆘 حل المشاكل

### مشكلة: `npm install` يأخذ وقت طويل
**الحل:** استخدم `npm install --registry https://registry.npmmirror.com`

### مشكلة: "Cannot find module"
**الحل:**
```bash
rm -rf node_modules package-lock.json
npm install
```

### مشكلة: Port 5000 مشغول
**الحل:** غير PORT في `backend/.env`:
```env
PORT=5001
```

### مشكلة: CORS error
**الحل:** تأكد أن Backend يعمل قبل Frontend

---

## 📞 API Endpoints

| Method | Endpoint | وصف |
|--------|----------|-----|
| POST | /api/auth/login | تسجيل الدخول |
| POST | /api/auth/register | إنشاء حساب |
| GET | /api/sectors | القطاعات الزراعية |
| GET | /api/projects | المشروعات القومية |
| GET | /api/news | الأخبار |
| GET | /api/investments | فرص الاستثمار |
| GET | /api/statistics | الإحصائيات |

---

## ✅ متطلبات النظام

- Node.js 16+
- MySQL 8.0 (اختياري)
- npm أو yarn

---

**بالتوفيق! 🌾**
